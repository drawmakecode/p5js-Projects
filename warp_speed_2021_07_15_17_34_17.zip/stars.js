class Star {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.vx = 0;
    this.vy = 0;
    this.vz = 0;
    this.twave = 0;
    this.waveoff = 0;
    this.cfade = 1;
    this.rfade = 1;
    this.ox = 0;
    this.oy = 0;
    this.oz = 0;
    this.px = 0;
    this.py = 0;
    this.pick = 0;
    this.vxo = 0;
    this.vyo = 0;
    this.rmax = 60;

  }

  make() {
    this.px = this.x;
    this.py = this.y;
    this.x = random(-width, width);
    this.y = random(-height, height);
    this.z = random(width);
    this.big = 1;
  }

  update() {
    this.oz = this.z;
    this.z = this.z - speed;
    if (this.z < 1) {
      this.make();
      this.oz = 0;
    }
    this.vxo = this.vx;
    this.vyo = this.vy;
    this.vx = map(this.x / this.z, 0, 1, 0, width);
    this.vy = map(this.y / this.z, 0, 1, 0, height);
  }

  show() {
    this.cfade = map(speed, 1, 45, 200, 255);
    this.rfade = map(speed, 1, 45, 125, 255);
    this.ox = map(this.x / this.oz, 0, 1, 0, width);
    this.oy = map(this.y / this.oz, 0, 1, 0, height);
    push();
    this.twave += 0.01;
    this.ts = sin(this.twave) * 360;
    this.tc = cos(this.twave) * 360;
    translate(0,
      0);
    stroke(255);
    strokeWeight((width - this.z) * 0.0055);
    //rotate(speed*0.2);
    if (dist(this.vxo, this.vyo,
        this.vx, this.vy) < 75) {
      line(this.vxo, this.vyo,
        this.vx, this.vy);

    }
    pop();
  }


}