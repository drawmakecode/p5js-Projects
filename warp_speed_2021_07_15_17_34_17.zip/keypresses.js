function keyReleased() {
  ship.setRotation(0);
  ship.boosting(false);

}

function keyPressed() {
  if (key == 'a' && !autofire) {
    autofire = true;
  } else if (key == 'a' && autofire) {
    autofire = false;
  }

  if (key == 'p' && gameover == true) {
    newgame();
    gameover = false;
  }

  if (key == 's' && soundon) {
    soundon = false;
  } else if (key == 's' &&
    !soundon) {
    soundon = true;
  }

  if (key == ' ' && lasers.length < 10) {
    for (let i = 0; i < 2; i++) {
      lasers.push(new Laser(ship.pos, ship.heading));
      trackfired += 1;
      if (soundon) {
        tngtorpedo.stop();
        tngtorpedo.playMode('restart');
        tngtorpedo.play();
      }
    }
  }


  if (keyCode == RIGHT_ARROW) {
    ship.setRotation(0.175);
  } else if (keyCode == LEFT_ARROW) {
    ship.setRotation(-0.175);
  } else if (keyCode == UP_ARROW) {
    ship.boosting(true);
  }

  if (key == 'r' && showstars) {
    showstars = false;
  } else if (key == 'r' && !showstars) {
    showstars = true;
  }

}

// function mousePressed() {
//   if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
//     let fs = fullscreen();
//     fullscreen(!fs);
//   }
// }