class Starfield {
  constructor() {
    this.x = [];
    this.y = [];
    this.brite = [];
    this.bigness = [];
    this.rbs = 0;
  }

  make() {
    for (let i = 0; i < 100; i++) {
      this.x[i] = random(-width / 4, width + width / 4);
      this.y[i] = random(-height / 4, height + height / 4);
      this.brite[i] = random(75, 175);
      this.bigness[i] = random(1, 3);
    }
  }

  show() {
    push();
    translate(width / 2, height / 2);
    this.rbs += warp * 0.001;
    rotate(this.rbs);
    for (let i = 0; i < this.x.length; i++) {
      strokeWeight(this.bigness[i]);
      stroke(this.brite[i]);
      point(this.x[i] - width / 2,
        this.y[i] - height / 2);
    }
    pop();
  }

}