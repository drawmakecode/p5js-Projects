//// STAR TREK: WARP SPEED
//// A Fan Game by Ed Cavett
//// January 2021
////
//// Based on Atari Asteroids
//// Clone by Daniel Shiffman
//// Courtesy: The Coding Train - YouTube
////
//// Sounds provided by
//// TrekCore.com
////
//// Theme Graphics &
//// Effects & Game Play
//// (c) 2021 Ed Cavett
////
//// Star Trek TOS, TNG (c) CBS-Viacom
//// Asteroids (c) ATARI

//// Active Keys
//// (for game play)
//// p - Start Game 
//// Space - Fire Torpedos
//// Arrows - Impulse Engines
//// (for testing)
//// s - Firing Sounds On/Off
//// (these affect performance)
//// r - Star Field On/Off
//// a - Auto Fire

let orbships = [];
let ship;
let lasers = [];
let borg;
let protect;
let acc = 0.075;
let backstar;
let autofire = false;
let warp = 6.5;
let stars = [];
let speed = 20;
let borgdead = false;
let endscreen;
let gamestart = 0;
let freesafe = 0; // 5secs of safe time b4 play 
let smallest = 20; // smallest asteroid size
let rockstostart = 5; // start game with this many asteroids


let roff = 0.001;
let level = 0;
let score = 0;
let maxscore = 0;
let gameover = true;
let rockvalue = 75;
let damage = 3;
let shellsfired = 0;

let integrity = 0; //100
let shield = 300; //300
let borglife = 2;
let readout;
let flyup = 650;
let myfont;
let myfont2;

let parts = [];
let explodeborg = false;

let trackfired = 0;
let showstars = false;

let borgphaser;
let tngtorpedo;
let borgexplode;
let tngship;
let shieldhit;
let communicate;
let orbexplode;
let borghail;
let sensors;
let playnow = 0;
let soundon = true;

function preload() {
  myfont = loadFont('trekfont.ttf');
  myfont2 = loadFont('trekfont2.ttf');
  borgphaser = loadSound('sounds/borgphaser.mp3');
  tngtorpedo = loadSound('sounds/tngphaser.mp3');
  borgexplode = loadSound('sounds/explode2.mp3');
  tngship = loadSound('sounds/tngship.mp3');
  shieldhit = loadSound('sounds/shieldhit.mp3');
  communicate = loadSound('sounds/incoming.mp3');
  orbexplode = loadSound('sounds/smallexplosion2.mp3');
  borghail = loadSound('sounds/borghail.mp3');
  sensors = loadSound('sounds/sensor.mp3');
}

function setup() {
  createCanvas(900, 600);
  background(0);
  textFont(myfont);
  playnow = frameCount + 50;
  borg = new borgship();
  endscreen = new endgameScreen();
  protect = new protection();
  ship = new Ship();
  backstar = new Starfield();
  backstar.make();
  for (let i = 0; i < 5; i++) {
    orbships.push(new orbmaker());
  }
  for (let i = 0; i < 100; i++) {
    stars.push(new Star());
  }
  for (let i = 0; i < stars.length; i++) {
    star = stars[i];
    star.make();
    star.show();
  }
  readout = new readings();
  for (let i = 0; i < 55; i++) {
    parts.push(new partsfly(borg.pos.x, borg.pos.y));
  }
}

function draw() {
  textAlign(CENTER, CENTER);
  textSize(15);
  if (showstars) {
    bg = map(speed, 20, 100, 255, 10); // adds warp effect to motion
    background(0, 0, 0, floor(bg));
    backstar.show();
  } else {
    background(0, 0, 0, 255);
  }
  /////////////////////////////
  if (borglife > 0) {
    borg.edges();
    borg.show();
    let borgshoot = random(1);
    if (borgshoot < 0.01 && borglife > 0) {
      if (soundon) {
        borgphaser.play();
      }
      borg.shoot();
      protect.update();
      shield -= 10;
      if (shield < 0) {
        shield = 0;
      }
    }
  }
  /////////////////////////////  


  ////stars print first
  //speed += acc;
  push();
  translate(width / 2, height / 2);
  if (showstars) {
    for (let i = 0; i < stars.length; i++) {
      star = stars[i];
      star.update();
      star.show();
    }
  }
  pop();
  ///////////// end stars 


  if (integrity > 0) {
    if (orbships.length == 0) {
      backstar.make();
      if (integrity < 35) {
        integrity = 35;
      }
      gamestart = frameCount;
      borglife = (level + 1) * 2;
      borg.pos = createVector(random(width),
        random(height));
      level += 1;
      speed += 3;
      sensors.play();
      communicate.play();
      maxscore += shield * (level * 10);
      maxscore += shellsfired;
      ship.pos.x = width / 2;
      ship.pos.y = height - (ship.r * 4);
      ship.vel.mult(0);

      borglife = (level + 1) * 3;

      for (let i = 0; i < rockstostart + level; i++) {
        orbships.push(new orbmaker());
      }
    }
    for (let i = lasers.length - 1; i >= 0; i--) {

      if (lasers[i].borghits(borg)) {

        borglife -= 1;
        score += 1000 * (level + 1);
        lasers.splice(i, 1);
        // break;
      }


    }


    for (let i = orbships.length - 1; i >= 0; i--) {
      if (ship.hits(orbships[i]) &&
        frameCount > gamestart + freesafe) {
        shield -= damage * level + 1;
        shieldhit.playMode('restart');
        shieldhit.stop();
        shieldhit.play();
        if (shield <= 0) {
          shield = 0;
          integrity -= 1;
          playnow = frameCount + 250;

          if (integrity < 0) {
            integrity = 0;
          }
        }
        protect.update();
      }
      orbships[i].update();
      orbships[i].render();
      orbships[i].edges();

      if (autofire) {
        /// auto fire begin
        if (orbships[i].pos.x > width / 2 - 65 &&
          orbships[i].pos.x < width / 2 + 65 &&
          lasers.length < 10) {
          lasers.push(new Laser(ship.pos, ship.heading));
        }
        /// auto fire end
      }
    }
    ship.render();
    ship.turn();
    ship.update();
    ship.edges();

    if (borglife == 0) {
      borgexplode.play();
      borghail.stop();
      for (let i = 0; i < parts.length; i++) {
        parts[i].restart(borg.pos.x, borg.pos.y);
      }

      borglife = -1;
      explodingborg = true;
    }
    if (borglife < 0 && explodingborg) {
      for (let i = 0; i < parts.length; i++) {
        parts[i].update(borg.pos.x, borg.pos.y);
      }
    }


    for (let i = lasers.length - 1; i >= 0; i--) {
      lasers[i].render();
      lasers[i].update();
      for (let j = orbships.length - 1; j >= 0; j--) {


        if (lasers[i].hits(orbships[j])) {
          burst(orbships[j].pos);
          rockvalue = map(orbships[j].r, 15, 50, 12, 4);
          if (integrity > 30) {
            let scoredist = dist(ship.pos.x, ship.pos.y,
               orbships[j].pos.x, orbships[j].pos.y);
            score += floor(scoredist) * 5;
          }
          protect.update();
          shield += 10;

          if (shield > 300) {
            shield = 300;
            integrity += 5;
            if (integrity > 100) {
              integrity = 100;
            }
          }
          if (score > maxscore) {
            maxscore = score;
          }
          orbexplode.playMode('restart');
          orbexplode.stop();
          orbexplode.play();
          orbships.splice(j, 1);
          lasers.splice(i, 1);
          break;
        }
      }
    }

    if (lasers.length > 0) {
      lasers[0].edges();
    }
    readout.update();
  } else if (integrity == 0) {
    readout.update();
    textAlign(CENTER, CENTER);
    textSize(50);
    noStroke();
    fill(255, 200, 0, 255);
    rect(0, 75,
      width / 2 + 180, 65,
      0, 25, 25, 0);
    flyup -= 14;
    let fm = map(flyup, 650, 100,
      -100, width / 2 - 16);
    if (flyup < 100) {
      flyup = 100;
    }
    fill(170, 120, 0, 255);
    text('STATUS: GAME OVER', fm, 103);
    fill(255, 255, 255, 255);
    text('STATUS: GAME OVER', width / 2,
      flyup);
    endscreen.show();
    gameover = true;
    //endgameScreen();
  }

  if (integrity < 30 && integrity != 0) {
    noStroke();
    fill(255, 0, 0, 50);
    rect(0, 0, width, height);
  }
} //end DRAW


function protection() {
  this.r = 0;
  this.rr = 5;

  this.update = function() {
    this.r += this.rr;
    if (this.r > 60 || this.r < 1) {
      this.rr *= -1;
    }
    push();
    noFill();
    strokeWeight(2);
    let m = map(shield, 0, 300, 75, 255);
    stroke(255, m, 255 - m, 255);
    translate(ship.pos.x, ship.pos.y);
    rotate(ship.heading);
    ellipse(-10, 0, this.r, 60);
    ellipse(-10, 0, 60, this.r);
    pop();
  }
}


function burst(pos) {
  push();
  fill(255, 200, 0, 255);
  noStroke();
  strokeWeight(1);
  for (let k = 0; k < 50; k += 5) {
    ellipse(pos.x, pos.y, k);
  }
  pop();

}


function newgame() {
  if (orbships.length > 0) {
    for (let i = orbships.length - 1; i >= 0; i--) {
      orbships.splice(i, 1);
    }
    for (let i = 0; i < 5; i++) {
      orbships.push(new orbmaker());
    }
  }
  speed = 20; // star rotation / star warp affect
  acc = 0.075; // star warp default speed
  gamestart = 0; // ready, set, go-counter
  freesafe = 0; // 5secs of safe time b4 play 
  smallest = 20; // smallest asteroid size
  rockstostart = 5; // start game with this many asteroids
  roff = 0.001; // rotating 
  level = 0; // beginning level 
  score = 0; // beginning score
  maxscore = 0; // beginning score
  gameover = false; // start play default is yes
  rockvalue = 75; // set the scoring value for orbships
  damage = 3; // set the damage level when hit by orb
  shellsfired = 0; // used to activate firing limiter 
  integrity = 100; //100 is the default
  shield = 300; //300 is the default
  borglife = 2; // how many hits to kill borg
  flyup = 650; // when GAME OVER starts moving at
  explodeborg = false; // activate explosing borg animation

  ship.pos.x = width / 2;
  ship.pos.y = height - (ship.r * 4);
  ship.vel.mult(0);
  if (parts.length > 0) {
    for (let i = 0; i < parts.length; i++) {
      parts[i].restart(borg.pos.x, borg.pos.y);
    }
  }

  if (lasers.length > 0) {
    for (let i = lasers.length - 1; i >= 0; i--) {
      lasers.splice(i, 1);
    }
  }

}