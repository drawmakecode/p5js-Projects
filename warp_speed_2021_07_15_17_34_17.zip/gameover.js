function endgameScreen() {
  this.starfly = 0.1;
  this.shipsound = 38;
  this.msg = 0;
  
  this.show = function() {
    this.shipsound += 1;
    if (this.shipsound > 20) {
      tngship.playMode('restart');
      tngship.play();
      this.shipsound = 0;
    }
    speed += this.starfly;
    if (speed > 100 ||
      speed < 20) {
      this.starfly *= -1;
    }
    push();
    //textFont(myfont2);
    noStroke();
    fill(0, 0, 0, 155);
    rect(0, 180, 670, 315);
    strokeWeight(5);
    stroke(255, 200, 0, 255);
    line(260, 180, 670, 180); // top
    line(670, 180, 670, 505); // right-side
    line(0, 505, 670, 505); // bottom
    let line1 = map(readout.sidebar,
      80, height - 30,
      260, 670);
    let line2 = map(readout.sidebar,
      80, height - 30,
      180, 505);
    let line3 = map(readout.sidebar,
      80, height - 30,
      670, 0);
    if (frameCount === playnow) {
      borghail.play();
      playnow = frameCount + 250;
    }
    let d1 = dist(line1, 180,
      670, line2);
    let d2 = float(dist(670, line2,
      line3, 505));
    let d3 = float(dist(line3, 505,
      line1, 180));

    strokeWeight(20);
    stroke(255, 255, 0, 155);
    point(line1, 180);
    point(670, line2);
    point(line3, 505);
    strokeWeight(5);
    stroke(255, 255, 0, 35);
    triangle(line1, 180,
      670, line2,
      line3, 505);
    noStroke();
    textAlign(LEFT, CENTER);
    textSize(15);
    fill(255, 200, 0, 180);
    text('BORG HEADING',690, line2-18);
    text('Mark ] '+int(d1)+'.'+int(d2)+'.'+int(d3), 690, line2 - 3);
    textSize(36);
    let readcolor = map(readout.sidebar,
      80, height - 30,
      255, 0);
    textAlign(LEFT, CENTER);
    textSize(25);
    fill(255, 200, 0, 255);
    text('STAR TREK: WARP SPEED', 50, 175);
    textSize(20);
    text('A FAN-GAME BY ED CAVETT', 50, 210);
    fill(readcolor,
      255 - readcolor,
      255 - readcolor, 255);
    this.msg += 1;
    if (this.msg < 200) {
          fill(255 - readcolor,
      255 - readcolor,
      readcolor,
      255);
      textSize(35);
      text('MISSION OBJECTIVES:', 380, 210);
      fill(readcolor,
      255 - readcolor,
      255 - readcolor, 255);
      textSize(20);
      text('The Borg have released thousands of subspace vacuoles across hundreds', 100, 260);
      text('of sectors that are disrupting hyper-luminal space travel. Your mission', 100, 290);
      text('is to collapse the vacuoles with specially calibrated photon torpedoes.', 100, 320);
      text('Use the energy from collapsing vacuoles to recharge your shields and', 100, 350);
      text('restore structural intregrity fields. Increase your warp-speed capability', 100, 380);
      text('by clearing each sector of subspace vacuoles.  Restore a top speed of', 100, 410);
      text('warp-9.80 to complete your mission. Destroy Borg probe to lower shields', 100, 440);
      text('protecting the subspace vacuoles.  Shoot vacuoles when they turn green.', 100, 470);
    }
    if (this.msg < 400 && this.msg > 200) {
      fill(255 - readcolor,
      255 - readcolor,
      readcolor,
      255);
      textSize(35);
      text('GAME PLAY & CREDITS:', 340, 210);
      fill(readcolor,
      255 - readcolor,
      255 - readcolor, 255);
      textSize(20);
      text('Bank higher scores by shooting distant vacuoles. Maintain 100% structural', 100, 260);
      text('integrity to add points to your score. Evade vacuoles to maintain 100%', 100, 290);
      text('shield strength. When shields fail, structural integrity fields can fail.', 100, 320);
      text('When your structural integrity fields fail, your mission will end.', 100, 350);
      text('', 100, 380);
      text('Star Trek Warp Speed is a fan-made game.  It is not licensed by the', 100, 410);
      text('the copyright and trademark owners of Star Trek or Asteroids.', 100, 440);
      text('For Non-commercial, private use only!  Original content (c) Ed Cavett.', 100, 470);
    }
    if (this.msg >= 400) {
      this.msg = 0;
    }
      pop();

    }
  }