function Laser(spos, angle) {
  this.pos = createVector(spos.x,
    spos.y);
  this.pos.add(random(-10, 10), 8);
  this.vel = p5.Vector.fromAngle(angle);
  this.vel.mult(20);
  this.oldx = this.pos.x;
  this.oldy = this.pos.y;

  //score -= 5;
  shellsfired += 1;
  if (score < 0) {
    score = 0;
  }
  this.update = function() {
    this.pos.add(this.vel);
  }

  this.render = function() {
    push();
    let shotd = dist(ship.pos.x,
      ship.pos.y,
      this.pos.x,
      this.pos.y);
    let shotm = map(shotd, 0, width, 255, 1);
    stroke(200, shotm, 0, shotm);
    strokeWeight(shotm * 0.025);
    line(this.pos.x, this.pos.y,
      this.oldx, this.oldy)
    this.oldx = this.pos.x;
    this.oldy = this.pos.y;
    pop();
  }

  this.hits = function(orbships) {
    let d = dist(this.pos.x,
      this.pos.y,
      orbships.pos.x,
      orbships.pos.y);
    if (d < orbships.r && borglife < 0) {
      shield += 10;
      if (shield > 300) {
        shield = 300;
      }
      shield += 25;
      if (shield > 300 && borglife < 0) {
        shield = 300;
      }
      return true;

    } else {
      return false;
    }
  }

  this.edges = function() {
    this.alloff = 0;

    for (let i = 0; i < lasers.length; i++) {
      if (lasers[i].pos.x < 0 ||
        lasers[i].pos.x > width ||
        lasers[i].pos.y < 0 ||
        lasers[i].pos.y > height) {
        this.alloff += 1;
      }
    }

    if (this.alloff == lasers.length) {
      for (let i = lasers.length - 1; i >= 0; i--) {
        lasers.splice(i, 1);
      }
    }
  }

  this.borghits = function(bships) {
    let d = dist(this.pos.x,
      this.pos.y,
      bships.pos.x,
      bships.pos.y);
    if (d < bships.r && borglife > 0) {
      shield += 10;
      if (shield > 300) {
        shield = 300;
      }
      shield += 10;
      if (shield > 300) {
        shield = 300;
      }
      return true;

    } else {
      return false;
    }
  }
}