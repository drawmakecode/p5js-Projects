function orbmaker() {
  this.pos = createVector(random(width),
    random(height));
  this.vel = p5.Vector.random2D();
  this.waveoff = random(1) * 0.1;
  this.spin = random(2) * 0.1;
  this.r = 10;
  this.rmax = 60;
  this.heading = random(360);
  this.perlin = random(3);
  this.pnoise = 0;
  this.holdmove = 0;
  this.holdlimit = 50;

  this.update = function() {
    this.pos.add(this.vel);
    this.vel.setMag(random(4, 8));
    this.holdmove += 1;

    if (this.holdmove > this.holdlimit) {
      this.holdlimit = random(5, 50);
      this.holdmove = 0;
      this.perlin += 0.01;
      this.pnoise = floor(noise(this.perlin) * 360);
      this.heading = this.pnoise;
      let force = p5.Vector.fromAngle(this.heading);
      this.vel.add(force);
    }

  }

  this.render = function() {
    push();
    let dotfade = map(ship.d, 0, width, 255, 5);
    this.r = map(ship.d, 0, width, this.rmax, 3);
    noFill();
    translate(this.pos.x,
      this.pos.y);
    this.waveoff += this.spin;
    if (this.waveoff > 360) {
      this.spin *= -1;
    }
    let spinwave = floor(sin(this.waveoff) * this.r);
    rotate(spinwave * 0.02);

    //rotate(spinwave);
    if (borglife > 0) {
      stroke(55, 255, 0, 255);
    } else {
      stroke(75,
        75,
        75,
        255);
    }
    strokeWeight(this.r * 0.5);
    point(0, 0);
    stroke(0, 200, 255, dotfade - 50);
    strokeWeight(2);
    ellipse(0,
      0,
      spinwave, this.r);
    ellipse(0,
      0,
      this.r, spinwave);

    pop();

  }

  this.edges = function() {
    if (this.pos.x < this.rmax) {
      this.pos.x = width - this.rmax - 30;
    } else if (this.pos.x > width - this.rmax - 30) {
      this.pos.x = this.rmax;
    }
    if (this.pos.y < this.rmax) {
      this.pos.y = height - this.rmax;
    } else if (this.pos.y > height - this.rmax) {
      this.pos.y = this.rmax;
    }

  }
}

function borgship() {
  this.r = 55;
  this.spin = 0;
  this.pos = createVector(random(width),
    random(height));
  this.vel = p5.Vector.random2D();
  this.vel.mult(random(3 + level, 10 + level));
  this.m = 0;
  this.z = 0;


  this.show = function() {
    this.pos.add(this.vel);
    push();
    rectMode(CENTER);
    translate(this.pos.x, this.pos.y);
    this.spin += 0.007;
    rotate(this.spin);
    strokeWeight(3);
    stroke(0, 75, 0, 200);
    fill(0, 75, 0, 255);
    this.z = dist(width / 2, height / 2,
      this.pos.x, this.pos.y);
    this.m = map(this.z, 0, width, 12, -12);
    rect(this.m, this.m, this.r, this.r, 3);

    stroke(0, 100, 25, 255);
    fill(0, 50, 50, 255);
    rect(0, 0, this.r, this.r, 3);
    noFill();
    line(-this.r / 2, 0, this.r / 2, 0);
    line(-this.r / 4, this.r / 2, -this.r / 2, 0);
    line(0, 0, -this.r / 2, -this.r / 4);
    rect(-this.r / 4, -this.r / 4, this.r / 3, this.r / 5);
    line(this.r / 3, -this.r / 6, this.r / 3, this.r / 3);
    line(-this.r / 8 + 2, this.r / 4, -this.r / 8 + 2, 0);
    line(-this.r / 7 + 4, this.r / 4, -this.r / 7 + 4, 0);
    line(-this.r / 6 + 8, this.r / 4, -this.r / 6 + 8, 0);
    line(-this.r / 5 + 12, this.r / 4, -this.r / 5 + 12, 0);
    line(-this.r / 4 + 12, this.r / 4, this.r / 4 + 10, 0);
    rect(-this.r * 0.09, this.r * 0.09, this.r * 0.7);
    rect(this.r * 0.19, this.r * 0.09, this.r * 0.5);
    strokeWeight(6);
    pop();
  }
  this.shoot = function() {
    push();
    strokeWeight(5);
    stroke(0, random(175,255), 0, 255);
    line(this.pos.x + random(-this.r / 2, this.r / 2),
      this.pos.y + random(-this.r / 2, this.r / 2),
      ship.pos.x, ship.pos.y);
    pop();

  }


  this.edges = function() {
    if (this.pos.x < this.r) {
      this.vel = p5.Vector.random2D();
      this.vel.mult(3);

      this.pos.x = width - 30 - this.r;
    } else if (this.pos.x > width - 30 - this.r) {
      this.pos.x = this.r;
      this.vel = p5.Vector.random2D();
      this.vel.mult(3);

    }
    if (this.pos.y < this.r) {
      this.pos.y = height - this.r;
      this.vel = p5.Vector.random2D();
      this.vel.mult(3);

    } else if (this.pos.y > height - this.r) {
      this.pos.y = this.r;
      this.vel = p5.Vector.random2D();
      this.vel.mult(3);

    }

  }

}

function partsfly(posx, posy) {
  this.r = random(15);
  this.spin = random(5);
  this.spinrate = random(1) * 0.1;
  this.pos = createVector(posx,
    posy);
  this.vel = p5.Vector.random2D();
  this.vel.mult(random(0, 12));
  this.lifespan = 420 + random(0, 120);
  this.sx = posx;
  this.sy = posy;

  this.restart = function(posx, posy) {
    this.r = random(15);
    this.spin = random(5);
    this.spinrate = random(1) * 0.1;
    this.pos = createVector(posx,
      posy);
    this.vel = p5.Vector.random2D();
    this.vel.mult(random(0, 12));
    this.lifespan = 420 + random(0, 120);
    this.sx = posx;
    this.sy = posy;
  }

  this.update = function() {
    this.lifespan -= 3;
    if (this.lifespan < 0) {
      explodingborg = false;
    }
    if (this.lifespan >= 0 &&
      !borgdead) {

      this.pos.add(this.vel);
      push();
      translate(this.pos.x,
        this.pos.y);
      this.spin += this.spinrate;
      rotate(this.spin);
      strokeWeight(3);
      stroke(0, 200, 0, this.lifespan);
      line(-this.r, this.r, this.r, -this.r);
      pop();
    }

  }


}