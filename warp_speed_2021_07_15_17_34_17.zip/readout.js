function readings() {
  this.sidebar = height - 30;
  this.barmover = speed * 0.1;

  this.update = function() {

    push();
    this.sidebar += this.barmover;
    if (this.sidebar < 80 ||
      this.sidebar > height - 30) {
      this.barmover *= -1;
      strokeWeight(5);
      stroke(255, 200, 0, 255);
      noFill();
      circle(10, 65, 15);
    }
    let barmap = map(this.sidebar,
      80, height - 30,
      20, 825);
    strokeWeight(10);
    stroke(255, 200, 0, 75);
    line(0, this.sidebar,
      15, this.sidebar);
    line(barmap, 60,
      barmap, 75);
    strokeWeight(7);
    circle(10, 65, 15);
    line(3, 70, 3, height - 27);
    line(15, 60, 825, 60);
    noStroke();
    fill(255, 200, 0, 255);
    noStroke();
    rect(635, 0, 20, 25,
      20, 0, 0, 20);
    rect(775, 0, 125, 25,
      0, 50, 0, 0);
    rect(830, 25, 80, 183);
    rect(0, height - 20, width, 20,
      10, 0, 10, 0);
    rect(830, 530, 80, 50);
    for (let k = 4; k < 10; k++) {
      fill(25 + 25 * k, -30 + 20 * k, level * 5, 255);
      rect(830, k * 53, 80, 50);
    }
    fill(255, 200, 0, 125);
    rect(655, 0, 120, 25);
    noFill();
    strokeWeight(15);
    stroke(255, 200, 0, 255);
    translate(800, 55);
    rotate(PI);
    arc(0, 0, 75, 75, HALF_PI, PI);
    rotate(PI / 2);
    arc(-495, 0, 75, 75, HALF_PI, PI);

    pop();

    push();
    let borgshields = map(borglife, -1, (level + 1) * 2,
      0, 100);
    let warp = map(speed, 0, 100, 0, 9.8);
    let shieldcolor = map(shield, 0, 300, 0, 255);
    let armedphotons = map(lasers.length,
      0, 9, 0, 255);
    let shippower = map(integrity, 0, 100, 0, 300);
    let enemies = map(orbships.length,
      0, rockstostart + level,
      0, 300);
    rectMode(CORNER);
    textAlign(CENTER, CENTER);
    noFill();
    strokeWeight(1);
    stroke(255 - shieldcolor, shieldcolor,
      0, 255);
    rect(0, 0, 300, 20, 10);
    strokeWeight(9);
    line(1, 10, shield - 9, 10);
    strokeWeight(1);
    stroke(armedphotons, 255 - armedphotons,
      0, 255);
    rect(0, 30, 300, 20, 10);
    strokeWeight(9);
    line(1, 40,
      255 - armedphotons + 35, 40);
    strokeWeight(1);
    stroke(255 - shippower, 255,
      0, 255);
    rect(305, 0, 320, 20, 10);
    strokeWeight(9);
    line(315, 10, shippower + 315, 10);
    strokeWeight(1);
    stroke(0, 200, 255, 255);
    rect(305, 30, 320, 20, 30);
    strokeWeight(9);
    line(315, 40, enemies + 315, 40);
    strokeWeight(1);
    fill(255, 255 - borgshields, 0, 255);
    rect(655, 30, borgshields, 20, 0, 30, 30, 0);


    noStroke();
    textSize(18);
    fill(255, enemies, 0, 255);
    text(orbships.length + ' SUBSPACE VACUOLES',
      455, 38)
    fill(255 - shield,
      255 - shield,
      255 - shield, 255);
    text('SHIELDING POWER  ' + floor(shield * 0.333) + '%',
      150, 8);
    fill(armedphotons, armedphotons,
      armedphotons, 255);
    text((10 - lasers.length) + ' ARMED PHOTON TORPEDOS',
      150, 38);
    fill(255 - shippower, 255 - shippower,
      255 - shippower, 255);
    text('STRUCTURAL INTEGRITY ' + floor(integrity) + '%',
      455, 8);
    textSize(20);
    textAlign(LEFT, CENTER);
    fill(255, 200, 0, 255);
    text('SCORE',
      835, 247);
    text(nfc(score), 835, 223);
    fill(0, 0, 0, 255);
    text('<SENSORS', 835, 65);
    text('VACUOLES', 835, 406);
    text(orbships.length, 835, 383)
    text('SECTOR', 835, 300);
    text(level, 835, 278);
    text(10 - lasers.length, 835, 331);
    text('TORPEDOS', 835, 353);
    text('WARP', 835, 459);
    text(nfc(warp, 2), 835, 437);
    text('BORG PWR', 835, 512);
    if (borglife >= 0){
    text(borglife+' TCS', 835, 489);
    } else if (borglife === -1) {
    text('FAILURE', 835, 489);
    }
    strokeWeight(1);
    textSize(17);
    fill(255, 255, 255, 255);

    text('BORG PROBE SHIELDS',
      660, 10);
    textSize(15);
    fill(0, 0, 0, 255);
    text('STAR TREK REGISTERED (C) CBS STUDIOS INC.  | FAN-MADE ARCADE VERSION (C) 2021 ED CAVETT',
      17, height - 10);
    //text('sound:'+soundon,width-200,height-10);
    if (borglife > 0) {
      noStroke();
      textAlign(LEFT, CENTER);
      fill(255, 255, 255, 155);
      textSize(25);
      text('INCOMING TRANSMISSION:', 30, 80);
      text('> WE ARE THE BORG. YOU WILL BE ASSIMILATED.  RESISTENCE IS FUTILE.',
        30, 110);
      textSize(15);
      pop();
    }
  }


}