

function mover(r,s) {
  this.x = random(size*2,width-size*2);
  this.y = random(size*2,height-size*2);
  this.xl = this.x; // random(width);
  this.yl = this.y; // random(height);
  this.rate = r;
  this.speed = s;
  this.dhold = 0;
  this.dsold = 0;
  this.trigger = 0;
  
 
  this.update = function(){
    if (random(1) < this.rate) {
      this.xl = random(size*2,width-(size*2));
      this.yl = random(size*2,height-(size*2));
    }
    this.x = lerp(this.x,this.xl,this.speed);
    this.y = lerp(this.y,this.yl,this.speed);
  }
  
  /// receives the index value for 
  /// comparing object to the target
  this.interact = function(objt,trgt){
    /// sound processing
    /// within joining distance
    this.dsold = this.dhold;
    this.dhold = dist(pos[objt].x,
                  pos[objt].y,
                  pos[trgt].x,
                  pos[trgt].y);
    if (int(this.dsold) <= size &&
        int(this.dhold) > size) {
      let shp1 = shp[objt].kind;
      let shp2 = shp[trgt].kind;
      if (shp1 === 0 &&
          shp2 === 1) {
        shp[objt].kind = 1;
        colr[objt].r = colr[trgt].r;
        colr[objt].g = colr[trgt].g;
        colr[objt].b = colr[trgt].b;
        /// sound association
        osc1.freq(freq, 0.5,0.75);
        osc1.amp(amp, 0.75);
        osc1.start();
      } else if (shp1 === 1 &&
                 shp2 === 2) {
        shp[objt].kind = 2;
        colr[trgt].r = colr[objt].r;
        colr[trgt].g = colr[objt].g;
        colr[trgt].b = colr[objt].b;
        osc2.freq(freq, 0.5,0.75);
        osc2.amp(amp, 0.75);
        osc2.start();

      } else if (shp1 === 2 &&
                 shp2 === 0) {
        shp[objt].kind = 0;
        colr[objt].r += 25;
        colr[objt].g += 25;
        colr[objt].b += 25;
        colr[trgt].r -= 25;
        colr[trgt].g -= 25;
        colr[trgt].b -= 25;
        this.colrbounds(objt,trgt);
        osc3.freq(freq, 0.5,0.75);
        osc3.amp(amp, 0.75);
        osc3.start();
        
      } else if (shp1 === shp2) {
       shp[objt].rpol *= -1;
       shp[trgt].rpol *= -1;
       shp[objt].kind = floor(random(3));
       colr[objt].r = (colr[objt].r+colr[trgt].r)*0.5;
       colr[objt].g = (colr[objt].g+colr[trgt].g)*0.5;
       colr[objt].b = (colr[objt].b+colr[trgt].b)*0.5;
        
      if (random(1) < 0.05){
        colr[objt].r = random(50,255);
        colr[objt].g = random(50,255);
        colr[objt].b = random(50,255);
      }
     } 
    } 
  }
  
  this.colrbounds = function(objt,trgt){
    if (colr[objt].r < 50) {
     colr[objt].r = 255;
    }
    if (colr[objt].g < 50) {
     colr[objt].g = 255;
    }
    if (colr[objt].b < 50) {
     colr[objt].b = 255;
    }

        if (colr[trgt].r < 50) {
     colr[trgt].r = 255;
    }
    if (colr[trgt].g < 50) {
     colr[trgt].g = 255;
    }
    if (colr[trgt].b < 50) {
     colr[trgt].b = 255;
    }

        if (colr[objt].r > 255) {
     colr[objt].r = 50;
    }
    if (colr[objt].g > 255) {
     colr[objt].g = 50;
    }
    if (colr[objt].b > 255) {
     colr[objt].b = 50;
    }
 
    if (colr[trgt].r > 255) {
     colr[trgt].r = 50;
    }
    if (colr[trgt].g > 255) {
     colr[trgt].g = 50;
    }
    if (colr[trgt].b > 255) {
     colr[trgt].b = 50;
    }
    
  }

  
}


function playOscillator() {
  osc.start();
  playing = true;
}

function mouseReleased() {
  osc.amp(0, 0.5);
  playing = false;
}