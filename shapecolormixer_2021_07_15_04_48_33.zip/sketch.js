/// Shape Mixer w/ Sound
/// by Ed Cavett
/// May, 2021


/// declare new array to hold particles location
let pos = [];
/// declare new array to manage particles shape
let shp = [];
/// declare new array to manage particles color
let colr = [];

/// set the number of objects
let popu = 12;
/// set the max size of an object (radius)
let size = 30;
let ssize = size * 0.25;
/// set the range of interaction
let range = size * 3;
/// declare switches for object type output
let dtype = 0;
let ddetect = 0;

let osc1, osc2, osc3, playing, freq, amp;


function setup() {
  createCanvas(windowWidth, windowHeight);
  rectMode(CENTER);
  for (let i = 0; i < popu; i++) {
    pos.push(new mover(0.005, 0.01));
    shp.push(new shaper());
    colr.push(new colorer());
  }
 osc1 = new p5.Oscillator('sine');
 osc2 = new p5.Oscillator('sine');
 osc3 = new p5.Oscillator('sine');

  background(0, 255);
}

function draw() {

  
  background(0,15,35, 255);
  noFill();
  strokeWeight(2);
  stroke(255,255);
  rect(width/2,height/2,
       width-range*0.5,
       height-range*0.5);

  for (let i = 0; i < pos.length; i++) {
    pos[i].update(); /// get position for particle
    let posx = pos[i].x;
    let posy = pos[i].y;
    ddetect = 0;

    for (let ii = 0; ii < pos.length; ii++) {
      let yf = map(posy,0,height,100,500);
      freq = constrain(map(posx, 0, width,
                           100, yf), 100, yf);
      amp = constrain(map(height/2, height, 0, 0, 1), 0, 0.25);
      let trgtx = pos[ii].x;
      let trgty = pos[ii].y;
      if (ii !== i){
      pos[ii].interact(ii, i);
      }
      /// the return of interact informs
      /// these conditions:
      let d1 = pos[ii].dhold;
      let d2 = pos[i].dhold;
      let sw = map(d1, range, 0, 1, size);

      /// coloring interactions
      let cp1 = colr[i].r;
      let cp2 = colr[i].g;
      let cp3 = colr[i].b;
      let ct1 = colr[ii].r;
      let ct2 = colr[ii].g;
      let ct3 = colr[ii].b;

      /// create line connection
      if (d1 < range && d1 > size) {
        ddetect += 1;
        noFill();
        strokeWeight(sw*0.5);
        stroke((cp1 + ct1) * 0.5, (cp2 + ct2) * 0.5, (cp3 + ct3) * 0.5);
        line(posx, posy, trgtx, trgty);
      }
      
      if (posx < range) {
        strokeWeight(posx*0.25);
        stroke(cp1,
               cp2,
               cp3,
               255);
        line(0,posy,posx,posy);
      }
      if (posx > width-range) {
        strokeWeight((width-posx)*0.25);
        stroke(cp1,
               cp2,
               cp3,
               255);
        line(width,posy,posx,posy);
      }
      if (posy < range) {
        strokeWeight(posy*0.25);
        stroke(cp1,
               cp2,
               cp3,
               255);
        line(posx,0,posx,posy);
      }
      if (posy > height-range) {
        strokeWeight((height-posy)*0.25);
        stroke(cp1,
               cp2,
               cp3,
               255);
        line(posx,height,posx,posy);
      }
      
      /// swap shapes and colors
      /// check if overlapped objects have
      /// moved away from each other 
      /// before activating any changes
      let ran = random(1);
      
      /// objects are close enough to interact
      
      if (d1 < size && i !== ii){
        
        
        if (ran < 0.25) {

        }
      }
   }
    
    /// draw object shape
    if (ddetect > 0) {
      ddetect = 1;
    }
      if (random(1) < 0.005){
      osc1.stop();
      }
      if (random(1) < 0.005){
      osc2.stop();
        
      }
      if (random(1) < 0.005){
      osc3.stop();
      
      }
      
    shp[i].update(ddetect, posx, posy, colr[i].r, colr[i].g, colr[i].b);
  }
}



/// Click to Go Fullscreen 
/// click bottom half of canvas
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}














//// end of sketch
