function colorer(i){
  this.r = random(50,255);
  this.g = random(50,255);
  this.b = random(50,255);
}