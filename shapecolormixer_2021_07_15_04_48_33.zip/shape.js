/// type is the kind of shape being made
/// attrib controls the fill and stroke
/// x,y are the location for this shape
/// c1,c2,c3 are the color values

function shaper() {
  this.roff = 0;
  this.rpol = 0.05;
  this.spin = 0;
  
  this.kind = 0;
  let ran = random(1);
  if (ran > 0.33 && ran < 0.66) {
  this.kind = 1;
  } else if (ran >= 0.66) {
  this.kind = 2;
  }
  
  
  this.update = function (attrib, x, y, c1, c2, c3) {

    push();
    translate(x,y);
    this.roff = size*4;
    // this.roff += this.rpol;
    // rotate(this.roff);
    if (attrib === 0) {
      noFill();
      stroke(c1, c2, c3, 255);
      strokeWeight(size * 0.1);
    } else {
      fill(c1, c2, c3, 255);
      noStroke();
    }

    if (this.kind === 0) {
      ellipse(0, 0, size,size);
    }
    if (this.kind === 1) {
      rect(0, 0, size, size);
    }
    let xyh = size*0.5;
    if (this.kind === 2) {
      triangle(0,0-(size*0.5),
               0-(size*0.5),0+(size*0.5),
               0+(size*0.5),0+(size*0.5));
    }
    pop();
  }
}
