/// Mountain Terrain Generator in p5.js
/// Generative Art by Ed Cavett
/// July 2021
/// ] Last Updated: August 1, 2021
/// ] Fixes Dead Tree output, replaces return
/// ] wave output of trees with an output of grass.

//////////////////////////////////////////////////
//// OBJECTIVE
//////////////////////////////////////////////////
//// Create a program that artistically generates 
//// random landscapes.  Use pseudo-randomness
//// to generate the terrain.  Add flora to the
//// terrain to create a mountain-landscape scene.
//// Coordinate the terrain position with the
//// positions of the flora to generate patches
//// and clusters of plants.
//// For a complete description, refer to the
//// associated README at github/drawmakecode.
//// For a general walk-through, watch the associated
//// video that accompanies this code at
//// youtube.com/drawmakecode.



//////////////////////////////////////////////////
//// PROCEDURES
//////////////////////////////////////////////////
/// Declare variables in the global space to
/// handle the wave-maker object, the global
/// vertical location, and an innumerator for
/// naming/saving output as an image file.
let waver;
let posy;
let whichone = 0;


/// In setup, assign a new instance of the wave-maker
/// object to the associated variable.
/// Clear the background once to start with a blank
/// canvas.
/// Assign a location to start the output at on the
/// canvas.
/// for the output.
/// Call the method that generates the gradiant
/// background.  Output once at start.
function setup() {
  createCanvas(windowWidth,
               windowHeight);
  waver = new waveMaker();
  background(0,200,255,255);
  posy = height*0.25;
  makeback();
}

/// In draw, advance the vertical location to display
/// the output.  This will crawl down the canvas and
/// carry the wave-line output with it.  The wave-line
/// is tied to this global location using translate.
/// Within the test-for-bounds, reset the location
/// to start, assign a cluster-density value for
/// generating different size groups of plants.
/// Call the background-gradient function for a 
/// blank "sky" canvas to start a new landscape.
/// Set the origin to the center at the variable,
/// vertical location.
/// Call the wave-maker function to generate the
/// single-layer of terrain and flora.
/// Repeat draw.

function draw() {
  posy += 0.75;
  if (posy > height*1.2) {
    posy = height*0.25;
    waver.shrubs = random(1);
    makeback();
  }
  translate(width/2,posy);
  waver.update();  
}

/// Generate a gradient background to compliment
/// the terrain and flora output.
/// Use a growing circle (centered in the canvas) to
/// create a radial gradient from center outward.
/// Fine-tune the ranges and modifiers to fit
/// the canvas size.
/// The interpolated range tightens and expands
/// the gradient's color seperation.
/// Inverting the fixed value and variable value
/// will flip the inside/outside colors.
/// For a linear gradient, use a line instead of
/// a circle.
function makeback(){
  background(0,255);
  noFill();
  for (let i = 0; i < width*1.5; i++){
    /// Set the lower interpolation argument to
    /// -325 for a rich gradient.  Use -600 for a
    /// soft gradient.
    let scol = map(i,0,width*1.5,-600,325);
    strokeWeight(1);
    // stroke(0,200-scol,325-scol,255); // Blue Sky
    stroke(325-scol,200-scol,25,255); // Sunset
    circle(width/2,height/2,i);
  }
}

/// Generate a perlin noise wave (wave-line) that
/// travels from left to right, then returns to start.
/// As the wave-line is being described, modify the
/// number of nodes relative to the vertical location
/// of the canvas origin.  This creates perspective.
/// Modify the fixed position of the nodes to offset
/// the columnation and create more randomized output.
/// At the modified position, apply a randomized 
/// cluster of circles of variable range.
/// At the modified position, determine to apply a
/// tree-styled element.  Determine to apply an
/// evergreen or a tree trunk.
/// Determine to position the trunk upright or 
/// laying down.
/// Repeat this procedure inside a reversing loop
/// that returns the second half of the wave-line to
/// the starting position.
/// Output the terrain shape (close wave-line shape)
/// last to wipe the flora in various regions.  This
/// generates a more "patchy" looking output of flora.
/// The modifiers control the stroke size as a means
/// of describing the perspective in the landscape.
/// These are tied to other values that limit the 
/// ranges of flora proportions (random sizes, widths,
/// densities, and the range of clusters).
/// As noise is generated, the same values are used
/// by different modifiers in order to have relative
/// output that more thoughtfully describes the 
/// terrain.
function waveMaker(){
  this.xoff = 0; /// noise parameter value
  this.yoff = 0; /// noise parameter value
  this.yend = 0; /// used as the last vertex
  this.ymod = -height/4; /// y-position modifier
  this.dense = width/15; /// step value for loops
  this.px = 0; /// shrub cluster unit position
  this.py = 0; /// shrub cluster unit postiion
  this.size = 0; /// returns the unit perspective size
  this.shrubs = 1; /// determines to call madrone()
  
  this.update = function() {
    //// First Layer Wave
    push();
    
    //// Isolate the vertex inputs to
    //// describe a shape of the terrain.
    //// Outside of the loop, start the shape
    //// with a fixed left location, and
    //// end with fixed left location.
    
    beginShape();
    vertex(-width/2,map(noise(0,this.yoff),0,1,
                  -height*0.25,height*0.25));
    
    //// Reset the x parameter (x-offset) for
    //// the 2D noise arguments.
    this.xoff = 0;
    
    //// Interpolate the density of the flora clusters
    //// to the vertical canvas position.  This
    //// compliments the perspective and height of the
    //// the terrain.
    this.dense = map(posy,0,height,15,25);
    
    //// Generate one-half of the wave line
    //// left-to-right by the density ratio of segments.
    //// The segment joints are the nodes at which
    //// descriptive elements (flora) are output.
    for (let x = -width/2; x < width/2;
         x += this.dense){
      
      /// Interpolate the x-position modifier
      /// by the perspective value as a measure of
      /// the density value.
      let xmod = map(noise(this.yoff,x),0,1,
                     -this.dense,this.dense);
      
      /// Interpolate the return of noise to
      /// produce the vertical change in the y
      /// position of the wave-line's node.
      /// The range (height) of the wave is
      /// a fraction of the canvas height.
      let y = map(noise(this.xoff,this.yoff),0,1,
                  -height*0.25,height*0.25);
      
      /// Interpolate a value to modify the 
      /// stroke thickness that is relative
      /// to the return of noise used to map
      /// the vertical location of a node.
      let sw = map(noise(this.xoff,this.yoff),0,1,
                   2,12);
      
      
      /// Scale the flora element by the 
      /// interpolation of the vertical canvas
      /// position to the element's relative size.
      /// Apply the current values to the vertex
      /// method.
      this.size = map(posy,0,height,2,25);
      vertex(x+xmod,y);
      
      /// Assign attributes that apply to
      /// an unencapsulated output.
      stroke(0,128,0,128);
      strokeWeight(this.size);
      
      /// Determine to call the shrub-cluster
      /// method to control the density of this
      /// output.
      if (random() < this.shrubs){
        this.madrone(x+xmod,y);
      }
      
      /// Set a local variable to modify
      /// the proportions of a tree trunk.
      let tree = random(this.size*0.05,
                          this.size*0.5);
      
      /// Use the shrubs density value to 
      /// control the density of tree trunks.
      if (random() < this.shrubs*0.02) { /// chance of shrubs
        push();
        
        /// Set the encapsulated origin to
        /// the base of the tree trunk element.
        /// Rotate slightly to generate a lean
        /// in the output shape.
        translate(x+xmod+random(-this.size*2,this.size*2),y);
        rotate(random(-PI*0.02,PI*0.02));
        
        /// Determine to leave the shape upright
        /// or fell the tree trunk into an horizontal
        /// orientation.
        if (random() < 0.5){ /// chance of dead tree
          let qp = HALF_PI; /// upright orientation
          if (random() < 0.75) { /// chance of felling
            qp = -HALF_PI; /// fell orientation
          }
          rotate(qp+random(-PI*0.02,PI*0.02));
        }
        
        /// Set the attributes for a tree trunk.
        /// Draw the tree trunk output.
        stroke(25,random(25,75),15,255);
        strokeWeight(this.size*0.15);
        line(0,0,0,-this.size*2);
        pop();
        
        /// Determine the alternate condition,
        /// that draws an evergreen tree.
        /// Determine to modify the output color
        /// to generate distinct differences in
        /// tree types.
      } else if (random() < 0.2) { /// chance of green trees
        push();
        stroke(0,50+random(0,100),25,255); 
        if (random() < 0.15) { /// chance of brown trees
          stroke(random(75,125),50,10,255); 
        }
        
        /// Set the encapsulated origin to the base
        /// of the pin tree shape.  Draw a randomly
        /// proportioned object in perspective scale.
        translate(x+xmod,y);
        triangle(0,random(-this.size*0.5,0)-tree,
                 -tree,tree,
                 tree,tree);
        pop();
      }

      /// Move the next splice of wave noise returns.
      this.xoff += 0.05;
      
      /// Set the local variable y to the global
      /// function variable to use in other methods.
      this.yend = y;
    }
    
    /// Assign the node coordinate to the shape table
    /// that outputs the wave-line shape.
    vertex(width/2,this.yend);
    
    /// Repeat the wave-line loop in reverse
    /// to describe the second half of the wave shape.
    /// Alter the modifiers to generate different
    /// output from the first half of the wave shape.
    /// When the first and second half crisscross and
    //// change positions relative to the top of the
    //// canvas, the accumulated output varies.  This
    //// creates patches of flora and open spaces that
    //// compliment the noise generating the terrain.
    for (let x = width/2; x > -width/2;
         x -= this.dense){
      let xmod = map(noise(this.yoff,x),0,1,
                     -this.dense,this.dense);
      let y = map(noise(this.xoff,this.yoff),0,1,
                  -height*0.25,height*0.25);
      let sw = map(noise(this.xoff,this.yoff),0,1,
                   2,12);
      let shapesize = map(posy,0,height,2,25);
      stroke(0,255-random(128),0,255);
      strokeWeight(this.size);
      vertex(x+xmod,y);
      
      /// Determine to generate shrub clusters.
      if (random() < this.shrubs*0.5){
        this.madrone(x+xmod,y);
      }
      
      /// Determine to generate evergreen tree shapes.
      let tree = random(this.size*0.1,
                          this.size*0.5);
      if (random() < 0.075) { /// chance of green grass
        push();
        stroke(0,random(175,50),25,255);
        if (random() < 0.02) { /// chance of brown grass
          stroke(125,50,10,255);
        }
        translate(x+xmod,y);
        strokeWeight(1);
        for (let j = 0; j < 50; j++){
          let grassx = random(-this.size,this.size);
          rotate(random(-PI*0.1,PI*0.1));
          line(grassx,-this.size*0.1,
               grassx,
               random(this.size*0.1))
        }
        // triangle(0,random(-this.size*0.5,0)-tree,
        //          -tree,tree,
        //          tree,tree);
        pop();
      }
      
      /// Advance to the next layer in the noise
      /// returns, and set the local y variable to
      /// the global function variable.
      this.xoff += 0.05;
      this.yend = y;
    }
    stroke(0,64,0,128);
    strokeWeight(2);
    
    /// Periodically generate a distinct output
    /// for the terrain stroke weight.  This 
    /// creates the strata-looking layers seen
    /// in moutainous rock formations.
    if (frameCount%32 === 0) {
      strokeWeight(8);
    }
    
    /// Set the attributes that will describe the
    /// wave shape output.  Use a random fill to
    /// create the rock color and appearance of layers.
    let rsub = random(128);
    fill(255-rsub,200-rsub,75-rsub,128);
    vertex(-width/2,this.yend);
    endShape(CLOSE);
    
    /// Advance the y-parameter for the 2D noise.
    this.yoff += 0.01;
    pop();
  }

  /// Generate a cluster of shrub/bush/tree shapes.
  /// Pass into the function the current node position.
  /// Output the objects around this location in a 
  /// range that is proportional to the perspective
  /// value (determined by the density value).
  this.madrone = function(tx,ty){
    push();
    translate(tx,ty);
    for (let q = 0; q < 6; q++){ /// density of cluster
      this.px = random(this.size*0.5); /// range
      rotate(random(TWO_PI)); /// radial location
      strokeWeight(this.size*random(0.1,0.5));
      stroke(random(0,128),random(50,255),0,255);
      this.py = random(-this.size*0.25,this.size*0.25);
      point(this.px,this.py);
    }
    pop();
  }
}

/// Provide a method to view the output as a 
/// screen-saver by clicking the bottom of the
/// canvas to activate fullscreen mode.
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}


/// Provide a method for saving the output as 
/// a png file type.  This method is inactive
/// by default.  Change the comment denotation
/// to activate.  Press DOWN to initiate the save.
function keyPressed(){
  if (keyCode === DOWN_ARROW) {
    whichone += 1;
    console.log('save inactive');
    // console.log('saving...');
    // saveCanvas('mtMaker'+whichone, 'png');
  }
}



