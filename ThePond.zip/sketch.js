/// The Pond
/// by Ed Cavett
/// May 2023

/// fx(hash) NFT


//// UI - Controls
//// --------------------------------------
//// S or s - Save snapshot view.
//// Down Arrow - Save full-size view.
//// D - View full-size scene.
//// d - View snapshot scene.
//// N or n - Take a new snapshot.
//// C or c - View collage snapshot.
//// 1 - Save maximum full-size 5000x2500
//// --------------------------------------

let circles = [];
let gXoff;
let gYoff;
let gNoff;
let crown = [];
let imgLayerA;
let imgLayerB;
let imgLayerC;
let imgLayerD;
let imgLayerE;
let imgLayerF;
let imgInset;
let imgFrames;
let theEnd;
let theEndB;
let theEndC;

let colorSet;
let picker;
let setPick = [];
let fillR;
let fillG;
let fillB;
let strokeR;
let strokeG;
let strokeB;

let minLen;
let maxLen;
let cminLen;
let cmaxLen;
let dockPosX;
let dockBase;

let ptminLen;
let ptmaxLen;

let dtminLen;
let dtmaxLen;
let gX;
let gY;
let gW;
let gT;
let bordR;
let pondView;
let treeLineSet;

function setup() {
  let hashGen = fxrand() * 10000;
  console.log("-----------------------");
  console.log("Random Seed: " + hashGen);
  randomSeed(hashGen);
  noiseSeed(hashGen);
  createCanvas(2048, 1024); /// 16x20 in format
  imgLayerA = createGraphics(width, height * 0.5);
  imgLayerB = createGraphics(width, height * 0.5);
  imgLayerE = createGraphics(width, height);
  imgLayerF = createGraphics(width, height);
  imgFrames = createGraphics(width, height);
  gXoff = random(10000);
  gYoff = random(10000);
  gNoff = random(10000);
  theEnd = 0;
  theEndB = 0;
  picker = floor(random(18));
  let picker2 = floor(random(18));
  console.log("Palette ID: " + picker);
  setPick.push(picker);
  fillR = 0;
  fillG = 0;
  fillB = 0;
  strokeR = 0;
  strokeG = 0;
  strokeB = 0;
  if (picker2 < 17) {
    setPick.push(picker2+1);
    setPick.push(picker2-1);
    if (random() < 0.5) {
      setPick.push(picker2 - 1);
      setPick.push(picker2 + 1);
    }
  }
  colorSet = new colSet();
  colSelect();
  let cloudDense = floor(random(5000, 10000));
  for (let i = 0; i < cloudDense; i++) {
    let rSet = random(height * 0.05, height * 0.1);
    let circle = {
      r: floor(rSet),
      x: random(rSet, width - rSet),
      y: random(rSet * 2, height - rSet),
    };
    let overlapping = false;
    for (let j = 0; j < circles.length; j++) {
      let other = circles[j];
      let d = dist(circle.x, circle.y, other.x, other.y);
      if (d < circle.r + other.r + 10) {
        overlapping = true;
        break;
      }
    }

    if (!overlapping) {
      circles.push(circle);
    }
  }
  for (let i = 0; i < circles.length; i++) {
    crown.push(new blobMaker(i + 1, circles[i].r));
  }
  imageMode(CENTER);
  rectMode(CENTER);
  maxLen = height * 0.08;
  minLen = maxLen * 0.1;
  cmaxLen = height * 0.12;
  cminLen = maxLen * 0.1;
  ptmaxLen = height * 0.07;
  ptminLen = ptmaxLen * 0.1;
  dtmaxLen = height * 0.05;
  dtminLen = dtmaxLen * 0.1;
  bordR = 1;
  pondView = random();
  treeLineSet = 0;
}

function draw() {
  background(fillR*1.2, fillG*1.2, fillB*1.2, 8);
  counter = frameCount;
  for (let i = 0; i < circles.length; i++) {
    imgLayerA.push();
    imgLayerA.translate(circles[i].x, circles[i].y);
    imgLayerA.rotate(noise(frameCount * 0.05) * TAU);
    crown[i].update();
    imgLayerA.pop();
  }
  if (theEnd) {
    let treeLine = 1;
    if (treeLineSet) {
      treeLine = 2;
    }
    for (let TLn = 0; TLn < treeLine; TLn++) {
      let PD = floor(random(2, 5));
      for (let pineDense = 0; pineDense < PD; pineDense++) {
        imgLayerA.push();
        imgLayerA.translate(random(width), height * 0.5);
        for (let i = 0; i < 3; i++) {
          pineTreeMaker(ptmaxLen * random(0.4, 1.2));
        }
        imgLayerA.pop();
      }
      let DD = floor(random(5, 15));
      for (let dtDense = 0; dtDense < DD; dtDense++) {
        imgLayerA.push();
        imgLayerA.translate(random(width), height * 0.5);
        colSelect();
        let KD = floor(random(1, 4));
        for (let k = 0; k < KD; k++) {
          dTreeMaker(dtmaxLen * random(0.4, 1.2));
        }
        imgLayerA.pop();
      }
      PD = floor(random(2, 5));
      for (let pineDense = 0; pineDense < PD; pineDense++) {
        imgLayerA.push();
        imgLayerA.translate(random(width), height * 0.5);
        for (let i = 0; i < 3; i++) {
          pineTreeMaker(ptmaxLen * random(0.4, 1.2));
        }
        imgLayerA.pop();
      }
    }
    imgLayerA.push();
    for (let bankLine = 0; bankLine < 1500; bankLine ++) {
      let bankV = random(0,10);
      let swFarside = random(1,2);
      imgLayerA.strokeWeight(swFarside);
      imgLayerA.stroke(fillR * random(0.2,0.5),
             fillG * random(0.2,0.5),
             fillB * random(0.2,0.5), 125);
      imgLayerA.push();
      let bankNoise = map(noise(bankLine*0.02),0,1,-width*0.5,width*1.5);
      imgLayerA.translate(bankNoise,imgLayerA.height-(bankV*0.5));
      imgLayerA.line(-bankV,random(2),bankV,random(2));
      imgLayerA.rotate(random(-PI*0.1,PI*0.1));
      let rndFarside = random(8,25);
      imgLayerA.line(0,0,0,-rndFarside);
      imgLayerA.rotate(random(-PI*0.1,PI*0.1));
      imgLayerA.line(0,0,0,-rndFarside*0.3);
      imgLayerA.rotate(random(-PI*0.1,PI*0.1));
      imgLayerA.line(0,0,0,-rndFarside*0.3);
      imgLayerA.strokeWeight(swFarside*1.5);
      imgLayerA.stroke(255-fillR * random(0.8,1.2),
             fillG * random(0.8,1.2),
             fillB * random(0.8,1.2), 125);
      imgLayerA.line(0,-rndFarside*1.1,0,-rndFarside*1.3);
      imgLayerA.pop();
    }
    imgLayerA.pop();
    
    birdMaker();
  }
  image(imgLayerA, width * 0.5, height * 0.25);
  imgLayerB = imgLayerA.get();
  push();
  translate(width * 0.5, height * 0.5);
  rotate(PI);
  let sFactor = map(counter, 0, 45, 0.01, 2);
  scale(-1, sFactor);
  image(imgLayerB, 0, -height * 0.25);
  noStroke();
  fill(255 - fillR, 255 - fillG, 255 - fillB, 8);
  rect(0, -height * 0.25, width, height * 0.5);
  pop();
  if (theEnd) {
    theEndB = 1;
    for (let j = 0; j < 600; j++) {
      push();
      stroke(fillR * 2.5, fillG * 2.5, fillB * 2.5, 75);
      let rlx = random(width);
      let rly = random(25, height * 0.5) + height * 0.5;
      let lMod = map(rly, 0, height, width * 0.001, width * 0.01);
      let sw = map(rly, 0, height, 1, 2);
      strokeWeight(sw);
      line(rlx, rly, rlx + lMod, rly);
      pop();
    }
    if (pondView < 0.5) {
      theEndB = 0;
      theEnd = 0;
      console.log("---------------------------");
      console.log("View: End of Dock");
      fixOutput();
      pondView = 1;
      noLoop();
    }
  }
  if (theEndB) {
    fill(255 - fillR, 255 - fillG, 255 - fillB, 32);
    rect(width * 0.5, height * 0.5, width, height);

    dockPosX = random(width * 0.5);
    if (random() < 0.5) {
      dockPosX = random(width * 0.5, width);
    }
    if (random() < 0.5) {
      dockMaker();
    }
    for (let bankN = 0; bankN < 5; bankN++) {
      imgLayerE.push();
      let rockLocX = random(dockPosX);
      if (random() < 0.5) {
        rockLocX = random(dockPosX, width);
      }
      imgLayerE.translate(rockLocX, height * 0.95 + maxLen);
      rockMaker(maxLen * random(0.25, 1) * random(0.8, 1.2));
      imgLayerE.pop();
    }
    console.log("View: From Onshore");
    image(imgLayerE, width * 0.5, height * 0.5);
    stroke(255, 255);
    strokeWeight(10);
    imgLayerD = get();
    let viewPick = floor(random(3));
    imgLayerC = get();
    imgLayerC.resize(1000,500);
    bordR = 1.1;
    createCanvas(imgLayerC.width * bordR, imgLayerC.height * bordR);
    background(strokeR * 0.5, strokeG * 0.5, strokeB * 0.5, 255);
    push();
    image(imgLayerC, width * 0.5, height * 0.5);
    pop();
    console.log(
      "Snapshot Size:" + int(imgLayerC.width) + "x" + int(imgLayerC.height)
    );
    console.log("---------------------------");
    console.log("Breathful Pond");
    console.log("by Ed Cavett");
    console.log("May 2023 on fxhash");
    console.log("Copyright © 2023");
    console.log("-----------------------");
    fxpreview();
    noLoop();
  }
}
//// Grab a new snapshot
function snapShot() {
    push();
    let viewPick = floor(random(3));
    if (viewPick === 0) {
      
      imgLayerC = imgLayerD.get(random(imgLayerD.width*0.25),
                                random(imgLayerD.height*0.5),
                               imgLayerD.width*0.75,imgLayerD.height*0.5);
    }
    if (viewPick === 1) {
      imgLayerC = imgLayerD.get(random(imgLayerD.width*0.5),
                                random(imgLayerD.height*0.25),
                               imgLayerD.width*0.5,imgLayerD.height*0.75);
    }
    if (viewPick === 2) {
      imgLayerC = imgLayerD.get(random(imgLayerD.width*0.25),
                                random(imgLayerD.height*0.25),
                               imgLayerD.width*0.75,imgLayerD.height*0.75);
    }
    //// Display the captured output with the set canvas size.
    bordR = 1.1;
    createCanvas(imgLayerC.width * bordR, imgLayerC.height * bordR);
    background(strokeR * 0.5, strokeG * 0.5, strokeB * 0.5, 255);
    image(imgLayerC, width * 0.5, height * 0.5);
    pop();
}
///// Generate a collage layout
function squareSplitter(len){
  push();
  imageMode(CORNER);
  let d1 = random();
  let d2 = random();
  let d3 = random();
  let bordRThick = random(10,16);
  if (d1 < 0.5) {
    
    if (d2 < 0.5) {
      imgInset = imgLayerD.get(0,random(imgLayerD.height*0.5),
                               imgLayerD.width,
                               imgLayerD.height*0.5);
      imgLayerF.image(imgInset,0,imgLayerD.height*0.5);
      
      if (d3 < 0.5) {
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,0,0);
        
        //// smallest
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.25);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,0);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.25);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,imgLayerD.height*0.25);
        //// < < <
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(0,imgLayerF.height*0.5,imgLayerF.width,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,imgLayerF.width*0.5,0);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.25,imgLayerF.width,imgLayerF.height*0.25);
        imgFrames.pop();
      } else { /// d3 >
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,0);
        /// smallest
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.25);
        imgLayerF.image(imgInset,0,0);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.25);
        imgLayerF.image(imgInset,0,imgLayerD.height*0.25);
        //// < < >
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(0,imgLayerF.height*0.5,imgLayerF.width,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,imgLayerF.width*0.5,0);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.25,0,imgLayerF.height*0.25);
        imgFrames.pop();
      }
    } else { /// d2 >
      /// largest
      imgInset = imgLayerD.get(0,random(imgLayerD.height*0.5),
                                   imgLayerD.width,imgLayerD.height*0.5);
      imgLayerF.image(imgInset,0,0);
      if (d3 < 0.5) {
        /// mid
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                   imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,0,imgLayerD.height*0.5);
        ///smallest        
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,imgLayerD.height*0.5);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.75);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,imgLayerD.height*0.75);
        //// < > <
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(0,imgLayerF.height*0.5,imgLayerF.width,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,imgLayerF.width*0.5,imgLayerF.height);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.75,imgLayerF.width,imgLayerF.height*0.75);
        imgFrames.pop();
      } else { /// d3 >
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                   imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,imgLayerD.height*0.5);
        
        ///smallest        
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.25);
        imgLayerF.image(imgInset,0,imgLayerD.height*0.5);
        
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.75),
                                imgLayerD.width*0.5,
                                 imgLayerD.height*0.25);
        imgLayerF.image(imgInset,0,imgLayerD.height*0.75);
        //// < > >
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(0,imgLayerF.height*0.5,imgLayerF.width,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,imgLayerF.width*0.5,imgLayerF.height);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.75,0,imgLayerF.height*0.75);
        imgFrames.pop();
      }
    }
  } else { /// d1 > 
    line(len*0.5,0,len*0.5,len);
    if (d2 < 0.5) {
      imgInset = imgLayerD.get(random(imgLayerD.width*0.5),0,
                               imgLayerD.width*0.5,imgLayerD.height);
      imgLayerF.image(imgInset,imgLayerD.width*0.5,0);
      if (d3 < 0.5) {
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,0,imgLayerD.height*0.5);
        //// smallest
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,0,0);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.25,0);
        //// > < <
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(imgLayerF.width*0.5,0,imgLayerF.width*0.5,imgLayerF.height);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,0,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.25,imgLayerF.height*0.5,imgLayerF.width*0.25,0);
        imgFrames.pop();
      } else { /// d3 >
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,0,0);
         //// smallest
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,0,imgLayerD.height*0.5);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.25,imgLayerD.height*0.5);
        //// > < >
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(imgLayerF.width*0.5,0,imgLayerF.width*0.5,imgLayerF.height);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,0,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.25,imgLayerF.height*0.5,imgLayerF.width*0.25,imgLayerF.height);
        imgFrames.pop();
      } 
   } else {  /// d2 >
      imgInset = imgLayerD.get(random(imgLayerD.width*0.5),0,
                                 imgLayerD.width*0.5,imgLayerD.height);
      imgLayerF.image(imgInset,0,0);
      if (d3 < 0.5) {
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,imgLayerD.height*0.5);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,0);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.75,0);
        //// > > < 
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(imgLayerF.width*0.5,0,imgLayerF.width*0.5,imgLayerF.height);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,imgLayerF.width,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.75,imgLayerF.height*0.5,imgLayerF.width*0.75,0);
        imgFrames.pop();
      } else { /// d3 > 
        imgInset = imgLayerD.get(random(imgLayerD.width*0.5),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.5,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,0);
        ///smallest
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.5,imgLayerD.height*0.5);
        imgInset = imgLayerD.get(random(imgLayerD.width*0.75),
                                 random(imgLayerD.height*0.5),
                                 imgLayerD.width*0.25,
                                 imgLayerD.height*0.5);
        imgLayerF.image(imgInset,imgLayerD.width*0.75,imgLayerD.height*0.5);
        //// > > < 
        imgFrames.push();
        imgFrames.stroke(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
        imgFrames.strokeWeight(bordRThick);
        imgFrames.line(imgLayerF.width*0.5,0,imgLayerF.width*0.5,imgLayerF.height);
        imgFrames.line(imgLayerF.width*0.5,imgLayerF.height*0.5,imgLayerF.width,imgLayerF.height*0.5);
        imgFrames.line(imgLayerF.width*0.75,imgLayerF.height*0.5,imgLayerF.width*0.75,imgLayerF.height);
        imgFrames.pop();
      }
    } 
  }
  pop();
}
//// Portion Full-Size for snap-shot
function fixOutput() {
  imgLayerD = get();
  let viewPick = 2;
  imgLayerC = get();
  imgLayerC.resize(1000,500);

  bordR = 1.1;
  createCanvas(imgLayerC.width * bordR, imgLayerC.height * bordR);
  background(strokeR * 0.5, strokeG * 0.5, strokeB * 0.5, 255);
  push();
  image(imgLayerC, width * 0.5, height * 0.5);
  pop();
    console.log(
      "Snapshot Size:" + int(imgLayerC.width) + "x" + int(imgLayerC.height)
    );
  console.log("---------------------------");
  console.log("Breathful Pond");
  console.log("by Ed Cavett");
  console.log("May 2023 on fxhash");
  console.log("Copyright © 2023");
  console.log("-----------------------");
  fxpreview();
}
//// Background - LayerA
//// Reflection - LayerB
//// Snap-shot Capture - LayerC (canvas portion)
//// Full-size Capture - LayerD (canvas full)
function birdMaker() {
  this.size = height * 0.1;
  this.birdDense = floor(random(2, 24));
  let facingX = random();
  for (let n = 0; n < birdDense; n++) {
    imgLayerA.push();
    let pos = createVector(random(width), random(height * 0.4, height * 0.6));
    imgLayerA.stroke(fillR * 1.2, fillG * 1.2, fillB * 1.2, 255);
    let sw = random(5, 8);
    imgLayerA.strokeWeight(sw);
    imgLayerA.point(pos.x, pos.y);
    imgLayerA.point(pos.x, height - pos.y);
    imgLayerA.strokeWeight(sw * 0.2);
    let facingY = random();
    let wingPosX = sw;
    let wingPosY = sw;
    if (facingX < 0.5) {
      wingPosX = sw * -1;
    }
    if (facingY < 0.5) {
      wingPosY = sw * -1;
    }
    wingPosY *= random(-1, 1);
    imgLayerA.beginShape();
    imgLayerA.vertex(pos.x, pos.y - sw * 0.4);
    imgLayerA.vertex(pos.x + wingPosX * random(1, 2), pos.y + wingPosY);
    imgLayerA.vertex(pos.x, pos.y + sw * 0.4);
    imgLayerA.noStroke();
    imgLayerA.fill(fillR * 1.2, fillG * 1.2, fillB * 1.2, 255);
    imgLayerA.endShape(CLOSE);
    facingY = random();
    wingPosX = sw;
    wingPosY = sw;
    if (facingX < 0.5) {
      wingPosX = sw * -1;
    }
    if (facingY < 0.5) {
      wingPosY = sw * -1;
    }
    wingPosY *= random(-1, 1);
    imgLayerA.beginShape();
    imgLayerA.vertex(pos.x, height - pos.y - sw * 0.4);
    imgLayerA.vertex(
      pos.x + wingPosX * random(1, 2),
      height - pos.y + wingPosY
    );
    imgLayerA.vertex(pos.x, height - pos.y + sw * 0.4);
    imgLayerA.noStroke();
    imgLayerA.fill(fillR * 1.2, fillG * 1.2, fillB * 1.2, 255);
    imgLayerA.endShape();
    imgLayerA.stroke(fillR * 1.2, fillG * 1.2, fillB * 1.2, 255);
    imgLayerA.strokeWeight(sw * 0.75);
    imgLayerA.point(pos.x + sw * 1.1, pos.y);
    imgLayerA.point(pos.x + sw * 1.1, height - pos.y);
    imgLayerA.strokeWeight(sw * 0.4);
    imgLayerA.line(pos.x + sw * 1.1, pos.y, pos.x, pos.y);
    imgLayerA.line(pos.x + sw * 1.1, height - pos.y, pos.x, height - pos.y);
    imgLayerA.strokeWeight(sw * 0.2);
    imgLayerA.line(pos.x + sw * 1.1, pos.y, pos.x + sw * 1.7, pos.y);
    imgLayerA.line(
      pos.x + sw * 1.1,
      height - pos.y,
      pos.x + sw * 1.7,
      height - pos.y
    );
    imgLayerA.pop();
  }
}
function dTreeMaker(len) {
  imgLayerA.push();
  imgLayerA.strokeCap(SQUARE);
  imgLayerA.translate(0, 0);
  imgLayerA.rotate(random(-PI * 0.05, PI * 0.05));
  let sw = map(len, dtminLen, dtmaxLen, 2, 15);
  imgLayerA.strokeWeight(2);
  let shorten = random(0.7, 0.9);
  for (let dy = 0; dy < len; dy += 2) {
    let dsw = map(dy, 0, len, sw, sw * shorten);
    let dcol = map(dsw, 1.5, 11.6, 1, 0.2);
    if (random() < 0.001) {
    }
    imgLayerA.stroke(fillR * dcol, fillG * dcol, fillB * dcol, 255);
    imgLayerA.line(-dsw * 0.5, -dy, dsw * 0.5, -dy);
  }
  imgLayerA.translate(0, -len);
  if (len > dtminLen) {
    dTreeMaker(len * shorten);
  }
  if (len > dtminLen && len < dtmaxLen * 0.4) {
    imgLayerA.push();
    imgLayerA.translate(0, 0);
    leafMaker(len);
    imgLayerA.pop();
  }
  imgLayerA.pop();
  if (random() < 0.2) {
    imgLayerA.push();
    imgLayerA.strokeCap(SQUARE);
    imgLayerA.translate(0, 0);
    imgLayerA.rotate(random(-PI * 0.2, PI * 0.2));
    imgLayerA.stroke(fillR, fillG, fillB, 255);
    sw = map(len, dtminLen, dtmaxLen, 2, 15);
    imgLayerA.strokeWeight(2);
    let shorten = random(0.8, 0.9);
    for (let dy = 0; dy < len; dy += 2) {
      let dsw = map(dy, 0, len, sw, sw * shorten);
      let dcol = map(dsw, 1.5, 11.6, 1, 0.2);
      imgLayerA.stroke(fillR * dcol, fillG * dcol, fillB * dcol, 255);
      imgLayerA.line(-dsw * 0.5, -dy, dsw * 0.5, -dy);
    }
    imgLayerA.translate(0, -len);
    if (len > dtminLen) {
      dTreeMaker(len * shorten);
    }
    if (len > dtminLen && len < dtmaxLen * 0.4) {
      imgLayerA.push();
      imgLayerA.translate(0, 0);
      leafMaker(len);
      imgLayerA.pop();
    }
    imgLayerA.pop();
  }
  if (random() < 0.25) {
    imgLayerA.push();
    imgLayerA.strokeCap(SQUARE);
    imgLayerA.translate(0, 0);
    imgLayerA.rotate(random(-PI * 0.2, PI * 0.2));
    imgLayerA.stroke(fillR, fillG, fillB, 255);
    sw = map(len, dtminLen, dtmaxLen, 2, 15);
    imgLayerA.strokeWeight(2);
    let shorten = random(0.8, 0.9);
    for (let dy = 0; dy < len; dy += 2) {
      let dsw = map(dy, 0, len, sw, sw * shorten);
      let dcol = map(dsw, 1.5, 11.6, 1, 0.2);
      imgLayerA.stroke(fillR * dcol, fillG * dcol, fillB * dcol, 255);
      imgLayerA.line(-dsw * 0.5, -dy, dsw * 0.5, -dy);
    }
    imgLayerA.translate(0, -len);
    if (len > dtminLen) {
      dTreeMaker(len * shorten);
    }
    if (len > dtminLen && len < dtmaxLen * 0.4) {
      imgLayerA.push();
      imgLayerA.translate(0, 0);
      leafMaker(len);
      imgLayerA.pop();
    }
    imgLayerA.pop();
  }
}
function leafMaker(len) {
  let lDense = 25;//floor(random(10, 25));
  for (let n = 0; n < lDense; n++) {
    let pos = createVector(random(-2, 2), random(-1, 1));
    let lenMod = dtmaxLen-len;
    pos.mult(len);
    imgLayerA.push();
    let colMod = random(0.1, 0.5);
    imgLayerA.fill(strokeR * colMod, strokeG * colMod, strokeB * colMod,
                   180);
    colMod = random(0.5, 1.1);
    if (pos.y > 0) {
      imgLayerA.fill(
        strokeR * colMod,
        strokeG * colMod,
        strokeB * colMod,
        180
      );
    }
    imgLayerA.noStroke();
    imgLayerA.ellipse(pos.x, pos.y,random(2, 8),random(2, 8));
    imgLayerA.pop();
  }
}
function pineTreeMaker(len) {
  imgLayerA.push();
  imgLayerA.translate(0, 0);
  imgLayerA.rotate(random(-PI * 0.01, PI * 0.01));
  let sw = map(len, ptminLen, ptmaxLen, 1, 3);
  imgLayerA.strokeWeight(sw * 1.1);
  imgLayerA.stroke(strokeR*0.2,
                   strokeG*0.2,
                   strokeB*0.2, 255);
  imgLayerA.line(0, 0, 0, -len);
  imgLayerA.push();
  for (let y = 0; y < len; y++) {
    let dense = floor(random(5, 10));
    let lenMod = len * random(0.25, 1);
    if (random() < 0.5 && random() < 0.3) {
      for (let x = 0; x < lenMod; x++) {
        let ymod = map(noise(y * 0.1, x * 0.05), 0, 1, -len * 0.1, len * 0.1);
        imgLayerA.strokeWeight(sw * ((len - x) * 0.01));
        imgLayerA.stroke(strokeR, strokeG, strokeB, 255);
        imgLayerA.point(-x, -y + ymod);
        if (random() < 0.1) {
          for (let n = 0; n < dense; n++) {
            imgLayerA.push();
            imgLayerA.translate(-x, -y + ymod);
            imgLayerA.rotate(QUARTER_PI + random(-PI * 1.2, -PI * 0.8));
            imgLayerA.strokeWeight(1);
            colSelect();
            imgLayerA.stroke(fillR*random(0.8,1),
                             fillG*random(0.8,1),
                             fillB*random(0.8,1), 255);
            imgLayerA.line(2, 2, 2, -ptmaxLen * 0.1);
            colSelect();
            imgLayerA.stroke(fillR*random(0.3,0.5),
                             fillG*random(0.3,0.5),
                             fillB*random(0.3,0.5), 255);
            imgLayerA.line(0, 0, 0, -ptmaxLen * 0.1 + 1);
            imgLayerA.pop();
          }
        }
      }
    }
    if (random() < 0.5 && random() < 0.3) {
      let lenMod = len * random(0.25, 0.6);
      for (let x = 0; x < lenMod; x++) {
        let ymod = map(noise(y * 0.1, x * 0.05), 0, 1, -len * 0.1, len * 0.1);
        imgLayerA.strokeWeight(sw * ((len - x) * 0.01));
        imgLayerA.stroke(strokeR, strokeG, strokeB, 255);
        imgLayerA.point(x, -y + ymod);
        if (random() < 0.1) {
          for (let n = 0; n < dense; n++) {
            imgLayerA.push();
            imgLayerA.translate(x, -y + ymod);
            imgLayerA.rotate(-QUARTER_PI + random(-PI * 0.2, PI * 0.2));
            imgLayerA.strokeWeight(1);
            colSelect();
            imgLayerA.stroke(fillR*random(0.8,1),
                             fillG*random(0.8,1),
                             fillB*random(0.8,1),
                             255);
            imgLayerA.line(0, 0, 0, ptmaxLen * 0.1);
            colSelect();
            imgLayerA.stroke(fillR*random(0.3,0.5),
                             fillG*random(0.3,0.5),
                             fillB*random(0.3,0.5), 255);
            imgLayerA.line(2, 2, 2, ptmaxLen * 0.1 + 2);
            imgLayerA.pop();
          }
        }
      }
    }
  }
  imgLayerA.pop();
  imgLayerA.translate(0, -len);
  if (len > ptminLen) {
    pineTreeMaker(len * 0.8);
  }
  imgLayerA.pop();
}
function blobMaker(n, rSet) {
  this.rad = rSet;
  this.item = n;
  this.diam = this.rad * 3;
  this.gap = TAU * 0.2;
  this.quant = 75;
  this.life = [];
  this.age = [];
  this.pos = [];
  this.vel = [];
  this.theta = [];
  this.offset = [];
  this.r = [];

  for (let n = 0; n < this.quant; n++) {
    this.pos.push(createVector(0, 0));
    this.vel.push(createVector(random(-1, 1), random(-1, 1)));
    this.life.push(this.rad * 8);
    this.age.push(0);
    this.theta.push(random(-TAU, TAU));
    this.r.push(random(-TAU, TAU));
    this.offset.push(createVector(random(10000), random(10000)));
  }
  for (let n = 0; n < 5; n++) {
    this.age[n] = 1;
  }
  this.update = function () {
    let someAlive = 0;
    colSelect();
    for (let i = 0; i < this.pos.length; i++) {
      if (this.age[i] < this.life[i] && this.age[i] > 0) {
        someAlive += 1;
        this.age[i] += 1;
        let x = this.pos[i].x;
        let y = this.pos[i].y;

        this.r[i] =
          this.theta[i] +
          map(
            noise(
              (this.offset[i].x + frameCount) * 0.01,
              this.pos[i].x * 0.1,
              this.pos[i].y * 0.1
            ),
            0,
            1,
            -TAU * 0.75,
            TAU * 0.75
          );
        this.vel[i] = p5.Vector.fromAngle(this.r[i]);
        this.vel[i].mult(10);
        this.pos[i].add(this.vel[i]);

        let d = dist(0, 0, this.pos[i].x, this.pos[i].y);
        let radModD = 4;
        if (d > this.rad * radModD) {
          this.age[i] = this.life[i] + 1;
        }
        imgLayerA.push();
        imgLayerA.translate(this.pos[i].x, this.pos[i].y);
        let sw = map(d, 0, this.rad * radModD, this.rad * 1.1, this.rad * 0.01);
        let col = map(this.age[i], 1, this.life[i], 255, 0);
        imgLayerA.noStroke();
        imgLayerA.fill(fillR, fillG, fillB, random(4,10));
        imgLayerA.circle(0, 0, sw);
        imgLayerA.fill(fillR * 0.8, fillG * 0.8, fillB * 0.8, random(14,18));
        imgLayerA.circle(0, this.pos[i].y, sw);
        imgLayerA.stroke(255, random(4,6));
        imgLayerA.strokeWeight(sw * 0.8);
        imgLayerA.point(0, 0);
        imgLayerA.stroke(0, 0, strokeB, random(14,18));
        imgLayerA.point(sw * 0.1, sw * 0.1);
        imgLayerA.strokeWeight(sw * 0.1);
        imgLayerA.stroke(fillR, fillG, fillB, random(4,10));
        imgLayerA.noFill();
        imgLayerA.circle(0, 0, sw * 0.5);
        imgLayerA.pop();
      } else {
        let thres = map(this.age[0], 0, this.life[0], 0.0001, 0.1);
        if (random() < thres && this.age[i] === 0) {
          let picked = floor(random(3, this.pos.length));
          if (this.age[picked] === 0) {
            picked = floor(random(10));
          }
          this.pos[i] = this.pos[picked].copy();
          this.age[i] = this.age[picked];
          this.theta[i] = this.theta[picked];
        }
      }
    }
    if (!someAlive) {
      theEnd = 1;
      if (pondView < 0.5) {
        treeLineSet = 1;
      }
    }
  };
}
//// Foreground - LayerE
function rockMaker(len) {
  len *= 2;
  let xoff = random(1000);
  let yoff = random(1000);
  imgLayerE.push();
  imgLayerE.translate(0, 0);
  for (let z = len; z > len * 0.005; z -= len * 0.1) {
    imgLayerE.beginShape();
    for (let r = -PI; r < 0; r += PI * 0.01) {
      let lenModx = map(noise(xoff, r), 0, 1, z * 0.6, z * 1, 5);
      let lenMody = map(noise(yoff, r), 0, 1, z * 0.3, z * 1, 8);
      let x = cos(r) * lenModx * 8;
      let y = sin(r) * lenMody * random(1.8, 2.8);
      for (let dotn = 0; dotn < 10; dotn++) {
        let xdot = x * random(0.8, 1);
        let ydot = y * random(0.8, 1);
        imgLayerE.push();
        imgLayerE.fill(strokeR, strokeB, strokeG, 255);
        imgLayerE.ellipse(xdot, ydot, random(3, 15), random(3, 15));
        imgLayerE.pop();
        imgLayerE.curveVertex(xdot, ydot);
      }
      imgLayerE.vertex(x, y);
    }
    imgLayerE.strokeWeight(1);
    imgLayerE.stroke(strokeR, strokeG, strokeB, 255);
    imgLayerE.fill(strokeR * 0.6, strokeG * 0.6, strokeB * 0.6, 225);
    imgLayerE.endShape();
  }
  imgLayerE.pop();
  for (let grassN = 0; grassN < 25; grassN++) {
    imgLayerE.push();
    imgLayerE.translate(random(-len, len), random(-len * 0.2));
    let rS = random(-PI * 0.05, PI * 0.05);
    colSelect();
    imgLayerE.stroke(strokeR, strokeG, strokeB, 255);
    grassMaker(maxLen * random(0.8, 1), rS);
    if (random() < 0.3) {
      let cheight = random(6, 8);
      for (let yBlade = 0; yBlade < maxLen * cheight; yBlade++) {
        let gw = map(
          yBlade,
          0,
          maxLen * cheight,
          maxLen * 0.05,
          maxLen * 0.012
        );
        let bladeCol = map(yBlade, 0, maxLen * cheight, -3, 1);
        imgLayerE.stroke(
          strokeR * bladeCol,
          strokeG * bladeCol,
          strokeB * bladeCol,
          255
        );
        let cxMod = sin(yBlade * 0.05) * gw;
        imgLayerE.line(-gw + cxMod, -yBlade, gw + cxMod, -yBlade);
      }
      imgLayerE.push();
      imgLayerE.translate(0, -maxLen * cheight - maxLen * (cheight * 0.1));
      imgLayerE.noFill();
      for (let cwide = 1; cwide < maxLen * 0.25; cwide++) {
        let catCol = map(cwide, 1, maxLen * 0.25, 0.25, 0.75);
        imgLayerE.strokeWeight(2);
        imgLayerE.stroke(
          strokeR * catCol,
          strokeG * catCol,
          strokeB * catCol,
          75
        );
        imgLayerE.arc(
          0,
          0,
          cwide,
          maxLen * (cheight * 0.2),
          -PI * 0.5,
          PI * 0.5
        );
        imgLayerE.arc(
          0,
          0,
          cwide,
          -maxLen * (cheight * 0.2),
          PI * 0.5,
          PI * 1.5
        );
      }
      imgLayerE.pop();
      cattailMaker(cmaxLen * random(0.85, 1.1), random(-PI * 0.01, PI * 0.01));
    }
    imgLayerE.pop();
  }
}
function cattailMaker(len, rSet) {
  imgLayerE.push();
  imgLayerE.translate(0, 0);
  imgLayerE.rotate(rSet);
  imgLayerE.strokeWeight(2);
  for (let ySet = 0; ySet < len; ySet++) {
    let gstart = len * 0.1;
    let gend = gstart * 0.8;
    let gw = map(ySet, 0, len, gstart, gend);
    let colFix = map(gw * 1.2, cmaxLen, cminLen, -3, 1);
    imgLayerE.stroke(
      strokeR * colFix * 0.75,
      strokeG * colFix * 0.75,
      strokeB * colFix * 0.75,
      255
    );
    imgLayerE.line(-gw * 0.5, -ySet, gw * 0.5, -ySet);
  }
  imgLayerE.translate(0, -len);
  if (len > cminLen * 1.01) {
    cattailMaker(len * 0.8, rSet * 1.0001);
  }
  imgLayerE.pop();
}
function grassMaker(len, rSet) {
  imgLayerE.push();
  imgLayerE.translate(0, 0);
  imgLayerE.rotate(rSet);
  imgLayerE.strokeWeight(2);
  for (let ySet = 0; ySet < len; ySet++) {
    let gstart = len * 0.25;
    let gend = gstart * 0.8;
    let gw = map(ySet, 0, len, gstart, gend);
    let colFix = map(gw, maxLen, minLen, -5, 1);
    imgLayerE.stroke(strokeR * colFix, strokeG * colFix, strokeB * colFix, 255);
    let gwSet = gw*0.5;
    imgLayerE.line(-gwSet+random(-gwSet*0.32,gwSet*0.32), -ySet,
                   gwSet+random(-gwSet*0.32,gwSet*0.32), -ySet);
  }
  imgLayerE.translate(0, -len);
  if (len > minLen) {
    grassMaker(len * 0.8, rSet * 1.005);
  }
  imgLayerE.pop();
}
function dockMaker() {
  this.topY = 0.6;
  this.base = width * 0.5;
  this.end = this.base * 0.2;
  this.xbase = random(width - this.base * 0.25);
  this.xend = this.xbase + random(-this.base * 0.5, this.base * 0.5);
  dockPosX = this.xend;
  dockBase = this.base;
  imgLayerE.push();
  imgLayerE.strokeCap(SQUARE);
  imgLayerE.strokeWeight(15);
  imgLayerE.stroke(strokeR * 0.25, strokeG * 0.25, strokeB * 0.25, 225);
  imgLayerE.line(
    this.xend + 7.5,
    height * (this.topY * 0.94),
    this.xend + 7.5,
    height * 0.8
  );
  imgLayerE.line(
    this.xend + this.end - 7.5,
    height * (this.topY * 0.94),
    this.xend + this.end - 7.5,
    height * 0.8
  );
  imgLayerE.pop();
  let thick = floor(height * 0.16);
  for (let ymod = thick; ymod > 0; ymod--) {
    if (ymod > thick - 20 || ymod < 20) {
      colSelect();
      imgLayerE.push();
      imgLayerE.beginShape();
      imgLayerE.vertex(this.xbase, height + ymod);
      imgLayerE.vertex(this.xend, height * this.topY + ymod);
      imgLayerE.vertex(this.xend + this.end, height * this.topY + ymod);
      imgLayerE.vertex(this.xbase + this.base, height + ymod);
      imgLayerE.strokeWeight(5);
      if (ymod === 1 || ymod === thick + 20) {
        imgLayerE.fill(fillR, fillG, fillB, 255);
        imgLayerE.stroke(strokeR * 0.5, strokeG * 0.2, strokeB * 0.05, 128);
        if (ymod === thick + 20) {
          imgLayerE.fill(fillR * 0.75, fillG * 0.75, fillB * 0.75, 255);
          imgLayerE.stroke(strokeR * 0.5, strokeG * 0.2, strokeB * 0.05, 128);
        }
      } else {
        imgLayerE.fill(fillR * 0.45, fillG * 0.45, fillB * 0.45, 255);
        imgLayerE.stroke(strokeR * 0.25, strokeG * 0.5, strokeB * 0.5, 128);
      }
      imgLayerE.endShape(CLOSE);

      if (ymod === thick - 19) {
        for (let j = 0; j < 300; j++) {
          imgLayerE.push();
          imgLayerE.strokeWeight(random(1, 2));
          imgLayerE.stroke(fillR * 2.5, fillG * 2.5, fillB * 2.5, 75);
          let rlx = random(width);
          let rly = random(0, height * 0.5) + height * 0.5;
          let lMod = map(rly, 0, height * 0.5, width * 0.001, width * 0.01);
          imgLayerE.line(rlx, rly, rlx + lMod, rly);
          imgLayerE.pop();
        }
      }
      imgLayerE.push();
      imgLayerE.strokeCap(SQUARE);
      let boardy = height;
      let boardNexty = height;
      colSelect();
      imgLayerE.stroke(strokeR, strokeG, strokeB, 128);
      for (let h = 0; h < height * 0.65; h++) {
        boardy = lerp(boardy, height * this.topY, 0.25);
        boardNexty = boardy * 2;

        let boardx = map(
          boardy,
          height,
          height * this.topY,
          this.xbase,
          this.xend
        );
        let wide = map(boardy, height, height * this.topY, this.base, this.end);
        let swMin = 1;
        let swMax = 10;
        let sw = map(boardy, height, height * this.topY, swMax, swMin);
        let spotY = random(boardy, boardNexty);
        let spotsw = map(spotY, height, height * this.topY, 20, 5);
        let spotW = map(spotY, height, height * this.topY, this.base, this.end);
        let spotX = map(
          spotY,
          height,
          height * this.topY,
          this.xbase,
          this.xend
        );
        if (ymod === 1) {
          for (let spotDense = 0; spotDense < swMax + 1 - sw; spotDense++) {
            let spotXwide = random(spotX + spotsw, spotX + spotW - spotsw);
            imgLayerE.push();
            imgLayerE.strokeWeight(spotsw * 0.1);
            imgLayerE.stroke(fillR * 0.5, fillG * 0.5, fillB * 0.5, 200);
            imgLayerE.line(
              spotXwide - spotsw * 0.5,
              spotY,
              spotXwide + spotsw * 0.5,
              spotY
            );
            imgLayerE.pop();
          }
        }
        imgLayerE.strokeWeight(sw);
        if (ymod === 1) {
          imgLayerE.line(boardx, boardy, boardx + wide, boardy); /// top lines
        } else {
          imgLayerE.stroke(strokeR * 0.5, strokeG * 0.4, strokeB * 0.1, 128);
          imgLayerE.line(boardx, boardy, boardx, boardy + 20); /// side lines
        }
      }
      imgLayerE.pop();
    }
  }
  imgLayerE.pop();
}
//// Palette System
function colSelect() {
  let bR1 = random(0,96);
  let bR2 = random(96,156);
  let rA = random(bR1,bR2);
  bR1 = random(156,188);
  bR2 = random(188,255);
  let rB = random(bR1,bR2);
  let pick = floor(random(-1, 1));
  if (picker >= 18) {
    pick = floor(random(2));
  }
  if (picker <= 0) {
    picker = 0;
    pick = floor(random(17, 18));
  }
  colorSet.update(rA * 1.1, rB * 1.1);
  fillR = floor(colorSet.setCol[picker][0]);
  fillG = floor(colorSet.setCol[picker][1]);
  fillB = floor(colorSet.setCol[picker][2]);
  strokeR = floor(colorSet.setCol[picker + pick][0]);
  strokeG = floor(colorSet.setCol[picker + pick][1]);
  strokeB = floor(colorSet.setCol[picker + pick][2]);
}
function colSet() {
  this.setCol = [];
  this.update = function (r1, r2) {
    let col = random(r1, r2);
    let whiteR = random(0, 225);
    this.setCol[0] = [128, 128, 128]; //black
    this.setCol[1] = [col, col * 0.05, col * random(0.05, 0.1)]; // red
    this.setCol[2] = [col, col * random(0.2), col * random(0.2)];
    this.setCol[3] = [col, col * random(0.05, 0.1), col * 0.32]; // pink - more red
    this.setCol[4] = [
      col * random(0.64, 1.2),
      col * random(0.05, 0.1),
      col * random(0.67),
    ];
    this.setCol[5] = [col * random(0.05, 0.1), col * random(0.05, 0.1), col]; // blue
    this.setCol[6] = [
      col * random(0.25, 0.1),
      col * random(0.25, 0.1),
      col * random(0.5, 1.5),
    ];
    this.setCol[7] = [col * random(0.05, 0.1), col, col * random(0.05, 0.1)]; // green
    this.setCol[8] = [
      col * random(0.05, 0.1),
      col * random(0.25, 1),
      col * random(0.05, 0.1),
    ];
    this.setCol[9] = [col, col, 0]; // yellow
    this.setCol[10] = [
      col * random(0.9, 1),
      col * random(0.7, 0.9),
      col * random(0.05, 0.1),
    ];
    this.setCol[11] = [col, col * 0.6, col * random(0.05, 0.1)]; // orange
    this.setCol[12] = [
      col * random(0.6, 1.1),
      col * 0.6,
      col * random(0.05, 0.1),
    ];
    this.setCol[13] = [col, col * 0.8, col * 0.3]; // brown
    this.setCol[14] = [col * random(0.9, 1.2), col * 0.8, col * 0.3];
    this.setCol[15] = [col * 0.64, col * 0.1, col]; // violet - more blue
    this.setCol[16] = [
      col * random(0.7, 0.8),
      col * random(0.7, 0.8),
      col * random(0.7, 0.8),
    ];
    this.setCol[17] = [col*0.5, col * 0.5, col * 0.5]; //white
    this.setCol[18] = [random(255), random(255), random(255)]; //white
    this.setCol[19] = [random(255), random(255), random(255)]; //dk gray
  };
}
//// UI - Local Storage
function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}
function keyPressed() {
  if (keyCode === DOWN_ARROW) {
    console.log("Full-sized image saved.");
    createCanvas(imgLayerD.width * bordR, imgLayerD.height * bordR);
    background(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
    push();
    image(imgLayerD, width * 0.5, height * 0.5);
    pop();
    saveCanvas("ed_cavett_FishingSpot", "png");
  }
  if (keyCode === UP_ARROW) {
    console.log("Full-sized image saved.");
    createCanvas(imgLayerF.width * bordR, imgLayerD.height * bordR);
    background(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
    push();
    image(imgLayerF, width * 0.5, height * 0.5);
    pop();
    saveCanvas("ed_cavett_FishingSpot", "png");
  }

  if (key === "s" || key === "S") {
    console.log("Snapshot image saved.");
    createCanvas(imgLayerC.width * bordR, imgLayerC.height * bordR);
    background(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
    push();
    image(imgLayerC, width * 0.5, height * 0.5);
    pop();
    saveCanvas("ed_cavett_FishingSpot", "png");
  }

  if (key === "d") {
    createCanvas(imgLayerC.width * bordR, imgLayerC.height * bordR);
    background(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
    push();
    image(imgLayerC, width * 0.5, height * 0.5);
    pop();
  }
  if (key === "D") {
    createCanvas(imgLayerD.width * bordR, imgLayerD.height * bordR);
    background(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
    push();
    image(imgLayerD, width * 0.5, height * 0.5);
    pop();
  }
  if (key === "n" || key === "N") {
    imgLayerC = imgLayerD.get();
    snapShot();
  }
  if (key === "C" || key === "c") {
    imgFrames = createGraphics(imgLayerF.width,imgLayerF.height);
    imgLayerF = createGraphics(imgLayerD.width,imgLayerD.height);
    squareSplitter(imgLayerD.width);
    imgLayerF.image(imgFrames,0,0);
    createCanvas(imgLayerD.width*bordR,imgLayerD.height*bordR);
    background(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
    image(imgLayerF,width*0.5,height*0.5);
  }
  if (key === "1") {
    imgLayerD.resize(5000,2500);
    createCanvas(imgLayerD.width * bordR, imgLayerD.height * bordR);
    background(255-strokeR * 0.5, 255-strokeG * 0.5, 255-strokeB * 0.5, 255);
    push();
    image(imgLayerD, width * 0.5, height * 0.5);
    pop();
    saveCanvas("ed_cavett_ThePond", "png");
  }
}
