//// DNA Helix Art
//// in p5.js WEBGL
//// by Ed Cavett
//// June, 2021


//// Create an object that makes
//// and outputs a "helix" structure
//// that extends into the depth of
//// the canvas.
//// Use rotations and sine waves to
//// move the "camera" for a variety
//// of perspectives.  Use noise and
//// location to color the parts.

//////////////////////////////////////
/// Reabability notes:
/// Three foreslashes (///) denote an
/// annotation for the code that
/// immediately follows the note lines.
/// Optional code will have two
/// foreslashes (//) to quickly
/// remove or add code using ctrl-/.
/// "Choose..." in the notes usually
/// means there is optional code to
/// follow.  Typically, a change to the
/// option involves "commentting-out" (//)
/// one line and "adding-in" the other
/// option or options.  
/// Some options can work together,
/// such as rotations x,y and z.


/// Declare a variable to hold the 
/// helix-making object.
let helix;

function setup() {
  /// Tell p5.js that the WEBGL
  /// methods will be used.
  createCanvas(windowWidth,
               windowHeight,
              WEBGL);
  /// Assign to the declared variable
  /// a new instance of the helix-maker
  /// object.
  helix = new helixMaker();

  /// Start the draw-function with
  /// a clean canvas of a desired
  /// color.
  background(0);
}

/// In draw, set up the background
/// appearance (or cummulative output);
/// fix or modify the canvas origin;
/// adjust the camera view of the volume;
/// call the function that performs the
/// object's method and output.
function draw() {
  
  /// Choose the style of output
  /// associated with the background.
  /// Comment-out the background to
  /// show cumulative output.
  /// Create a color-changing background
  /// using a local variable assigned to
  /// perlin noise.
  let bn = map(noise(frameCount*0.005),0,1,
               -25,175);
  // background(0); /// Clean, black background.
  background(bn,bn,155-bn); /// Color-changing background.
  
  /// Assign a local variable to a
  /// sinusoidal wave that will
  /// "push in" and "pull out" the
  /// camera view.
  let camin = map(sin(frameCount*0.005),-1,1,
    -height*0.75,height*0.75);
  
  /// Translate the canvas volume
  /// view to the center x,y and
  /// the push-pull the origin to
  /// the viewer position.
  translate(0,0,camin);
  
  /// Choose to hold the camera
  /// fixed in the z position.
  // translate(0,0,height/2);
  
  /// Spin the canvas volume to view
  /// different angles of the system ouput.
  /// Choose to fix the view to x and/or y
  /// modifications or use constant rotations.
  // rotateX(-PI*0.5); /// Fix view to angle-vertical.
  // rotateY(-PI*0.25); /// Fix view to angle-horizontal.
  rotateX(frameCount*0.01); /// Constant rotation
  rotateY(frameCount*0.01); /// Constant rotation
  rotateZ(frameCount*0.025); /// Constant rotation
  
  /// Perform the method of the helix-maker
  /// function to generates new values and
  /// fresh output.
  helix.update();
}


/// This function creates an array of 
/// particles that describe circles (sin/cos)
/// as points while stepping into the depth.
/// The result is a 3D helicoidal structure.
function helixMaker(){
  
  /// Declare empty arrays to hold
  /// each particle's x,y and z location.
  this.x = [];
  this.y = [];
  this.z = [];
  
  /// Declare and assign the ratio
  /// of particles to volume.
  this.dense = 120;
  
  /// Declare and assign the radius
  /// of the described circulation.
  this.size = 25;
  
  /// Declare and assign the factor of
  /// layers in the depth of the canvas
  /// volume by simplifying the
  /// volume:density ratio.
  this.layer = floor(height*2/this.dense);

  /// Declare and assign a value to
  /// adjust the twisting output of
  /// the structure.
  this.twist = 0;
  
  /// Declare and assign a value to
  /// adjust the distance of the
  /// complimentary point system from
  /// the fixed point system.
  this.orbit = 15;
  
  /// Loop through the depth by the
  /// layer step value (volume:density).
  /// Fill the arrays with their positional
  /// values.  X and Y will have unit
  /// values that will be scaled up with
  /// the radius size variable.
  for (let i = -height/2;
       i < height/2;
       i += this.layer) {

    /// Generate a scale to step
    /// through the circle points.
    /// This will decribe the twisting
    /// style of the output.
    /// Choose to make a fixed line
    /// of points or a wave of a
    /// choosen frequency.
    this.twist = 0; /// Fixed line of points.
    // this.twist += 0.5; /// Choose a frequency.
    
    /// Get unit values to describe
    /// the location of points for an 
    /// extruded circular geometry.
    this.x.push(sin(this.twist)); /// x-graph of sine n
    this.y.push(cos(this.twist)); /// y-graph of sine n
    this.z.push(i); /// linear step of z.
  }
  
  /// Perform the calculations
  /// and generate output for this
  /// system of points.
  this.update = function(){
    
    /// Loop through the array of 
    /// point positions to output
    /// the structure.  Perform
    /// deltas inside the loop to
    /// alter output parameters.
    for (let i = 0;
         i < this.z.length;
         i++) {

      /// Isolate the translate and
      /// rotate changes to the particle's
      /// location and orientation.
      push();
      
      /// Set the origin to the location
      /// of this particle. X and Y describe
      /// a circle, while the z moves that
      /// circulation into the depth plane.
      translate(this.x[i]*this.size,
                this.y[i]*this.size,
                this.z[i]);
      
      /// Assign a local variable to output
      /// perlin noise color values.
      let sc = map(noise(frameCount*0.05+(this.z[i]*0.01)),
                         0,1,25,255);
      
      /// Implement changes to the color
      /// attribute and/or point size.
      /// Particles are output
      /// as stroke points.
      /// Use a local variable to
      /// interpolate the z-plane to
      /// the scale of the points.
      let sw = map( this.z[i],-height/2,height/2,
                   this.size,this.size*2);
      stroke(sc,sc-55,sc);
      strokeWeight(sw);
      
      /// Two points are output.  One is
      /// static and remains fixed at the 
      /// instantiated position.
      /// The other point obits the fixed
      /// one.
      /// Output the fixed points.
      /// Choose to display the fixed system.
      point(0,0);

      /// Isolate complimentary point to orbit
      /// the fixed point's position.
      push();

      /// Rotate the volume to "orbit"
      /// the complimentary point around
      /// the fixed point.
      /// Use the coefficient of the i
      /// modifier to adjust the number
      /// of twists in the complimentary
      /// point system.
      
      /// Set the i-coefficient value.
      /// Choose to set with a fixed value
      /// or use the mouse's Y location.
      // let ci = 0.5;
      let ci = mouseY*0.001;
      
      /// Choose to affect the desired
      /// rotation along the specified axis.
      // rotateX(frameCount*0.1+(i*ci));
      // rotateY(frameCount*0.1+(i*ci));
      rotateZ(frameCount*0.1+(i*ci));
      
      /// Choose to redefine the color
      /// and scale of the complimentary
      /// point.
      strokeWeight(sw);
      stroke(0,sc,sc-55);
      
      /// Choose to adjust the orbital
      /// distance of the complimentary
      /// particles using the mouse's x.
      this.orbit = floor(mouseX*0.05);
      
      /// Output the complimentary points.
      point(this.orbit,this.orbit);
      
      /// Choose to output a line to
      /// connect the fixed-complimentary
      /// points. Set the weight to a
      /// desired stroke thickness.
      // strokeWeight(5);
      // line(0,0,25,25);
      pop(); /// Close complimentary
             /// particle volume.
      
      pop(); /// Close fixed particle volume.
    }
  }
}
