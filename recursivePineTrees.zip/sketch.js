/// Recursive Pine Tree (Advanced)
/// in p5.js
/// by Ed Cavett
/// March 2023

//////////////////////////////////////

let minLen;
let maxLen;
let xloc;
let quant;
let bchance; 
let tiltY; 

function setup() {
  createCanvas(1080, 1080);
  maxLen = height * 0.15;
  minLen = maxLen * 0.1;
  xloc = maxLen * 0.3;
  quant = floor(random(5,9));
  background(255,245,245, 255);
}

function draw() {
  background(255,245,245, 10);
  translate(random(width), height * 0.95);
  bchance = random(0.2,0.5);
  tiltY = random(0.1,0.5);
  for (let i = 0; i < 3; i++) {
    pineTreeMaker(maxLen * random(0.25, 1.5));
  }
  if (frameCount === quant) {
    noLoop();
  }
}

function pineTreeMaker(len) {
  let colr = 50;
  let colg = 40;
  let colb = 30;
  let bdense = len*random(0.02,0.08);
  let ndense = 0.3;
  
  push();
  translate(0, 0);
  rotate(random(-PI * 0.01, PI * 0.01));
  let sw = map(len, minLen, maxLen, minLen*0.5, minLen);
  strokeWeight(sw * 1.1);
  stroke(50, 40, 30, 255);
  line(0, 0, 0, -len);

  push();
  for (let y = 0; y < len; y+=bdense) {
    let waveY = random(0.05,0.1);
    let dense = floor(random(5, 10));
    let lenMod = len * random(0.5, 1.1);
    
    // if (len < maxLen * 0.7) { /// no branches at bottom of trunk
    /// left pointing branch
      if (random() < 0.5 && random() < bchance) {
        for (let x = 0; x < lenMod; x++) {
          let nSet = floor(random(2));
          let ymod = map(noise(y * 0.01, x * 0.05), 0, 1,
                         -len * waveY, len * waveY);
          strokeWeight(sw * ((len - x) * 0.005));
          stroke(25+random(colr),
                 20+random(colg),
                 15+random(colb), 255);
          point(-x, -y + ymod-(x*tiltY));
          if (random() < ndense) {
            for (let n = 0; n < dense; n++) {
              push();
              translate(-x, -y + ymod-(x*tiltY));
              if (nSet) {
                rotate(random(-PI * 0.3,-PI * 0.1));
              } else {
                rotate(random(-PI * 0.6, -PI * 0.8));
              }
              strokeWeight(1);
              stroke(random(50, 175), 255);
              line(0, 2, 0, -maxLen * 0.1);
              stroke(0, random(50, 125), random(0, 25), 200);
              line(0, 0, 0, -maxLen * 0.1 + 1);
              pop();
            }
          }
        }
      }
      /// right pointing branch
      if (random() < 0.5 && random() < bchance) {
        let lenMod = len * random(0.5, 1.1);
        for (let x = 0; x < lenMod; x++) {
          let nSet = floor(random(2));
          let ymod = map(noise(y * 0.01, x * 0.05), 0, 1,
                         -len * waveY, len * waveY);
          strokeWeight(sw * ((len - x) * 0.005));
          stroke(25+random(colr),
                 20+random(colg),
                 15+random(colb), 255);
          point(x, -y + ymod-(x*tiltY));
          if (random() < ndense) {
            for (let n = 0; n < dense; n++) {
              push();
              translate(x, -y + ymod-(x*tiltY));
              if (nSet) {
                rotate(random(PI * 1.1,PI * 1.4));
              } else {
                rotate(random(PI * 1.6, PI * 1.8));
              }
              stroke(random(50, 175), 255);
              strokeWeight(1);
              line(0, 1, 0, maxLen * 0.1 + 1);
              stroke(0, random(50, 125), random(0, 25), 200);
              line(0, 0, 0, maxLen * 0.1);
              pop();
            }
          }
        }
      }
      /// middle located branch
      if (random() < 0.5 && random() < bchance) {
        let lenMod = len * random(0.5, 1.1);
        for (let x = -lenMod*0.5; x < lenMod*0.5; x++) {
          let ymod = map(noise(y * 0.01, x * 0.05), 0, 1,
                         -len * waveY, len * waveY);
          let msw = sw*0.25;
          if (x < 0) {
            msw = map(x,-lenMod*0.5,0,1,sw*0.5);
          } else {
            msw = map(x,0,lenMod*0.5,sw*0.5,1);
          }
          strokeWeight(msw);
          stroke(25+random(colr),
                 20+random(colg),
                 15+random(colb), 255);
          point(x, -y + ymod);
          if (random() < ndense) {
            for (let n = 0; n < dense; n++) {
              push();
              translate(x, -y + ymod);
              rotate(-QUARTER_PI + random(-PI * 0.2, PI * 0.2));
              strokeWeight(1);
              stroke(random(50, 75), 255);
              line(0, 1, 0, maxLen * 0.1 + 1);
              stroke(0, random(50, 125), random(0, 25), 200);
              line(0, 0, 0, maxLen * 0.1);
              pop();
            }
          }
        }
      }      
      
    // }
  }
  pop();
  translate(0, -len);
  if (len > minLen) {
    pineTreeMaker(len * 0.8);
  }
  pop();
}


function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

function keyPressed() {
  if (keyCode === DOWN_ARROW) {
    saveCanvas("ed_cavett_realisticPines", "png");
  }
}