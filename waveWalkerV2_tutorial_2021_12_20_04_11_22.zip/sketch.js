/// WaveWalkerV2
/// Tutorial Version
/// by Ed Cavett
/// December 2021

/// Generate geometries that roll 
/// along a waveform based on the slope
/// and size of the objects.
/// Move the wave and allow the objects
/// to wrap around the left and right 
/// sides.

/// Provide for simplex noise waves and
/// sinusoidal waveforms.


let roller = [];
let popu = 18;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  for (let i = 0; i < popu; i++) {
    roller.push(new rollerMaker(i));
  }
  background(0,200,255,255);
  rectMode(CENTER);
}

function draw() {
  let colr = abs(sin(frameCount*0.01)*255);
  let colr2 = abs(cos(frameCount*0.01)*255);
  background(colr,
             colr2,
             255-colr,255);
  // background(255,255);
  translate(width/2,height/2);
  for (let i = 0; i < roller.length; i++) {
    roller[i].update(i);
  }
}


function rollerMaker(i){
  this.pos = [];
  this.xoff = 0;
  this.yoff = 0;
  this.len = 5;
  this.vel = 0.1;
  this.spot = [];
  this.size = [];
  this.acc = 0.0001;
  this.spin = 0;
  
  for (let x = -width/2-width*0.05;
       x < width/2+width*0.05;
       x+=this.len) {
    this.pos.push(createVector(x,0));
    /// Distribute location on the waveform.
    this.spot.push((i+1)*(25));
    /// Factor size based on order in array.
    this.size.push((i+1)*4);
  }
  
  /// Set local variables to function's global scope.
  let accFactor = 0;
  let slopeDiff = 0;
  let veltop = 0;
  let rollerSize = 0;
  
  
  this.update = function(n) {
    this.xoff = 0;
    push();
    beginShape();
    for (let i = 0; i < this.pos.length; i ++) {
      
      /// Simplex Noise Wave Terrain
      this.pos[i].y = map(noise(this.xoff,this.yoff,
                               frameCount*0.0025),0,1,
                          -height*0.5,height*0.5);
      
      /// Sinusoidal Wave Terrain
      // this.pos[i].y = map(sin(i*(i*0.00018)+
      // (frameCount*0.175)),-1,1,
      //                     -height*0.025-(i*0.15),
      //                     height*0.025+(i*0.15));
      
      /// Apply this location to current waveform.
      vertex(this.pos[i].x,this.pos[i].y+n);
      
      /// Advance noise return to next set in the x range.
      this.xoff += 0.005;
    }
    
    /// Advance noise return to next set in the y range.
    this.yoff += 0.005;
    
    /// Interpolate color based on the roller's 
    /// order in array.
    let colr = map(noise(this.xoff,
                         this.yoff,
                         frameCount*0.01),0,1,
                   50,255);
    stroke(0,128);
    strokeWeight(1);
    noFill();
    
    /// Output the waveform.
    endShape(); 
   
    /// Advance the index value that holds the 
    /// x location on the waveform.
    this.spot[n] += this.vel;
    
    /// Assign an easy variable to hold the
    /// integer of the index incrementation.
    let s = floor(this.spot[n]);

    /// Check for valid array indices.
    if (s > this.pos.length-1) {
      this.spot[n] = 0;
      s = 0;
    }
    if (s < 0) {
      this.spot[n] = this.pos.length-1;
      s = this.pos.length-1;
    }
    
    /// Factor the size of each roller.
    rollerSize = this.size[n]+16;
  
    /// Generate output for the roller geometry.
    /// Offset the origin by the radius of the roller.
    /// This will make it appear to rest on the waveform.
    /// Translate the origin to the roller's center, then
    /// rotate.  Plot the geometries at 0,0 with the
    /// respective sizes and colors.
    
    push();
    if (n%2 === 0) {
      translate(this.pos[s].x,
                this.pos[s].y+(rollerSize/2)+(popu-n));
    } else {
      translate(this.pos[s].x,
                this.pos[s].y-(rollerSize/2));
    }
    /// Modify the spin value to get a slower rotational
    /// velocity.
    rotate(this.spin*0.25);
    strokeWeight(4);
    stroke(colr,
         255);
    fill(0,colr-75,colr,175);
    
    /// Alternate geometries.
    if (n%2 === 0) {
      ellipse(0,0,
              rollerSize*0.75);
    } else {
      rect(0,0,
              rollerSize*0.75);
    }
    pop();

    /// Send valid index numbers into method.
    /// Adjust for edge-cases.
    if (s > 0 && s < this.pos.length-1) {
      this.calcRoller(this.pos[s-1],
                      this.pos[s+1],rollerSize,n);
    }
    if (s === 0) {
      this.calcRoller(this.pos[0],
                     this.pos[s+1],rollerSize,n);
    }
    if (s === this.pos.length-1) {
      this.calcRoller(this.pos[s-1],
                     this.pos[s],rollerSize,n);
    }
    pop();
  }
  
  this.calcRoller = function(pos1,pos2,size,n){
    /// Find the difference in height between
    /// the left and right sides of the roller.
    slopeDiff = dist(0,pos1.y,0,pos2.y);
    
    /// Hold the current position if not enough slope.
    /// Move slower on shallow grade, faster on
    /// steeper grade.
    if (slopeDiff < 0.05) {
      slopeDiff = 0;
    }
      
      /// Interpolate acceleration factor based on slope.
      accFactor = map(slopeDiff,0,15,0.01,0.1);
      
      /// Scale acceleration factor.
      /// This could be done inside the parameters of the
      /// interpolation, but I like having an outside
      /// modifier.
      accFactor *= size/2;
      
      /// Apply accelaration factor determined by
      /// which side of the roller is lower in position,
      /// (higher in y value).
      
      /// Determine to place on top or below
      /// the waveform.
      
      if (n%2 === 0) {
        if (pos1.y > pos2.y) {
          this.acc = accFactor;
        }
        if (pos2.y > pos1.y) {
          this.acc = -accFactor;
        }
      } else {
        if (pos1.y > pos2.y) {
          this.acc = -accFactor;
        }
        if (pos2.y > pos1.y) {
          this.acc = accFactor;
        }
      }
    
    /// Apply acceleration.
    this.vel += this.acc;
    
    /// Apply friction.
    /// Formula removes a portion of
    /// velocity.  Smaller number
    /// means more friction.
    if (n%2 === 0) {
      this.vel *= 0.75;
    } else {
      this.vel *= 0.95;
    }
    /// Factor terminal velocity.
    veltop = size*0.1;
    
    /// Apply terminal velocity.
    if (this.vel < -veltop) {
      this.vel = -veltop;
    }
    if (this.vel > veltop) {
      this.vel = veltop;
    }
    
    /// Factor and apply rotational velocity.
    this.spin += this.vel*0.5;
  }
}



/// Provide a way to view the output in full screen
/// mode.  Click the canvas to switch modes.
function mousePressed() {
  if (mouseX > 0 && mouseX < width &&
    mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

