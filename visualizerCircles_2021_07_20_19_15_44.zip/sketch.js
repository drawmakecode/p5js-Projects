/// Eyeland - Music Visualization
/// set to the instrumental,
/// Lost at Sea by TribalTrack
/// Code by Ed Cavett
/// July 2021


let song;
let fft;
let button;
let w;
let spectrum;
let jump = 0; 
let ts = 0; 
let mp = 10;
function preload() {
  
  // song = loadSound('')
  // song = loadSound('Dave_Depper_-_Sportsreel.mp3')
  // song = loadSound('David_Szesztay_-_Burlesque.mp3')
  // song = loadSound('David_Szesztay_-_Traveller.mp3')
  // song = loadSound('Dave_Depper_-_Sportsreel.mp3')
  // song = loadSound('Dave_Depper_-_Up.mp3')
  // song = loadSound('I Drank Alone - TrackTribe.mp3')
  song = loadSound('Lost At Sea - TrackTribe.mp3')
}
function toggleSong() {
  if (song.isPlaying()) {
    song.pause();
  } else {
    song.play();
  }
}

let visual;


function setup() {
  createCanvas(windowWidth,
               windowHeight);
  w = (width*0.75)/64;
  button = createButton('Song');
  button.mousePressed(toggleSong);
  song.play();
  fft = new p5.FFT(0.025, 64);
  visual = new visualizer();
  background(0,255);
}

function draw() {
  background(0,25);
  translate(width/2,height/2);
  spectrum = fft.analyze();
  for (let i = 0; i < spectrum.length; i++) {
    let amp = spectrum[i];
    if (i%3 === 0) {
    visual.update(i,amp);
    }
  }
}


function visualizer(){

  this.update = function(_i,_amp){
    push();
    let mamp = map(_amp,0,255,25,50);
    let rcol = map(noise(frameCount*0.005),0,1,
                   0,255);
    let gcol = map(cos(frameCount*0.001),-1,1,
                   0,255);
    let bcol = 255; //map(_i,0,spectrum.length,
                   //128,255);
    let salph = map(_amp,0,255,15,75);
    stroke(0,0,255,10);
    let sw = map(_amp,0,255,5,15);
    strokeWeight(sw);
    noFill();
    // fill(rcol,gcol-75,bcol,2);
    let xn = map(noise(frameCount*0.005+(_i*0.025)),
               -1,1,-width/4,width/4);
    let yn = map(noise(frameCount*0.01+(_i*0.01)),
               -1,1,-height/4,height/4);
    translate(xn,yn);
    rotate(frameCount*(_i*0.00025));
    beginShape();
    let shapemod = map(_amp,0,255,0.0001,0.001);
    let shape = map(sin(frameCount*shapemod),-1,1,
                    3,12);
    let scalmod = map(_amp,0,255,8,18);
    for (let s = TWO_PI; s > 0; s-= TWO_PI/shape){
      let x = cos(s)*(_i*scalmod);
      let y = sin(s)*(_i*scalmod);
      vertex(x,y);
    }
    endShape(CLOSE);
    pop();
    
    
    
  }
  
}


 /// go fullscreen for screen saver
function mousePressed() {
  if (mouseX > 0 && mouseX < width &&
    mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}








/// end of sketch
