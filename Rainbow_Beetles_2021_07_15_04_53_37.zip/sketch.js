//// Vector Mover
//// "Rainbow Beetles"
//// in p5.js
//// by Ed Cavett
//// Based on the code
//// Follow1 by Keith Peters
//// from the p5.js Examples

let mover = [];
let population = 7;
let bugtrail = [];
let pg;
let r = 100;
let g = 10;
let b = 50;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  pg = createGraphics(width,height);
  pg.background(r,g,b,255);
  for (let i = 0; i < population; i++){
  mover.push(new vectorMover(i));
  }
  bugtrail[0] = [255,0,0,100];
  bugtrail[1] = [255,125,0,100];
  bugtrail[2] = [255,255,0,100];
  bugtrail[3] = [0,255,0,100];
  bugtrail[4] = [0,0,255,100];
  bugtrail[5] = [125,0,255,100];
  bugtrail[6] = [255,0,255,100];
  
}

function draw() {
  background(126,255);
  let s = second();
  if (s/59 === int(s/59)){
      r = random(50,175);
      g = random(50,175);
      b = random(50,175);
      pg.background(r,g,b,255);
      }
  if (s/59 != int(s/59)){
   pg.background(r,
                 g,
                 b,
                 5);
   image(pg,0,0);
  }
  for (let i = 0; i < population; i++){
  mover[i].update(i);
  }
}



function vectorMover(i) {
  this.pos = createVector(width / 2, height / 2);
  this.vel = createVector(0, 0);
  this.noff = (i+1)*5;
  this.angle = 0;
  this.speed = 0;
  this.seglen = 20;
  this.antenna = 0;
  this.antoff = 0;
  this.gcolor = 255/(i+1);
  this.trailwave = 0;
  this.wingwave = 0;
  this.wingoff = (i+2)*5;
  
  this.update = function(i) {
    this.trailwave += 0.001;
    tw = abs(sin(this.trailwave)*0.005);
    this.noff += tw; //0.005;
    this.antoff += 0.1;
    this.antenna = map(noise(this.antoff),0,1,0,HALF_PI);
    this.angle = map(noise(this.noff), 0, 1, 0, TWO_PI * 2);
    this.speed = map(noise(-this.noff),0,1,0,4);
    if (this.speed <=1.25) {
      this.speed = 0;
    }
    this.vel = p5.Vector.fromAngle(this.angle);
    this.vel.mult(this.speed);
    this.pos.add(this.vel);
    /// call bounds function
    this.bounds(this.pos.x,this.pos.y);
    /// call segment function
    this.segment(this.pos.x,
      this.pos.y,
      this.angle,i);
    
  }
  
  this.bounds = function(x,y){
    if (x < 0) {
      this.pos.x = width;
    }
    if (x > width){
      this.pos.x = 0;
    }
    if (y < 0) {
      this.pos.y = height;
    }
    if (y > height){
      this.pos.y = 0;
    }
  }
  
  this.segment = function(x, y, a, i) {
    push();
    let trail = bugtrail[i];
    /// body - under wings
    translate(x, y);
    strokeWeight(37);
    stroke(trail[0]*0.45,
           trail[1]*0.45,
           trail[2]*0.45,
           125);
    point(0,0);
    rotate(a);
    
    /// head 
    strokeWeight(15);
    stroke(0,255);
    point(this.seglen,0); // head
    /// tail spot
    strokeWeight(6);
    point(-15,0); /// small rear dot
    /// white neck spot
    stroke(175,255);
    strokeWeight(6);
    point(15,0);
    fill(trail[0],
           trail[1],
           trail[2],
           75); /// bug body

    
    /// Wings & Spots
    this.wingoff += 0.01;
    this.wingwave = map(noise(this.wingoff),0,1,-1,2);
    
    if (this.wingwave <= 0){
      this.wingwave = 0;
    }
    if (abs(this.wingwave) > 1) {
     this.wingwave = 1;
    }
    push();
    rectMode(CORNERS);
    translate(this.seglen,0);
    rotate(-this.wingwave);
    strokeWeight(1);
    arc(-this.seglen,0,36,36,0,PI); /// right wing
    stroke(0,255);
    strokeWeight(8);
    point(2-this.seglen,3); /// center dot R
    point(9-this.seglen,8); /// shoulder dot R 
    point(-2-this.seglen,12); /// mid dot R
    point(-10-this.seglen,8); /// hind dot R
    pop();
    
    push();
    rectMode(CORNERS);
    translate(this.seglen,0);
    rotate(this.wingwave);
    strokeWeight(1);
    arc(-this.seglen,0,36,36,PI,TWO_PI); /// left wing
    stroke(0,255);
    strokeWeight(8);
    point(9-this.seglen,-8); /// center dot L
    point(2-this.seglen,-3); /// shoulder dot L
    point(-2-this.seglen,-12); /// mid dot L
    point(-10-this.seglen,-8); /// hind dot L
    pop();
    
    strokeWeight(2);
    stroke(0,255);
    push();
    translate(this.seglen,0);
    rotate(this.antenna-QUARTER_PI);
    line(0,0,10,10);
    pop();

    push();
    translate(this.seglen,0);
    rotate(-this.antenna+QUARTER_PI);
    line(0,0,10,-10);
    pop();
    
    /// wing split line
    strokeWeight(2);
    line(-17,0,this.seglen,0);

    /// close first rotation/tranlation
    pop();
    pg.push();
    this.trailwave += this.antenna;
    let tw = abs(sin(this.trailwave)*35);
    pg.translate(this.pos.x,this.pos.y);
    pg.strokeWeight(this.antenna*35);
    pg.stroke(trail[0],
             trail[1],
             trail[2],
             100); /// trails
    pg.point(0,0);
    pg.pop();    
  }
}





/// Click to Go Fullscreen /bottom click
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}





///// end of sketch