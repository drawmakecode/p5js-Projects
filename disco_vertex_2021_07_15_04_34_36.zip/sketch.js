//// Circle Lines
//// coded by Ed Cavett

let particle;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  particle = new particles();

}

function draw() {
  background(255,1);
  translate(width/2,height/2);
  particle.update();
  
  // if (frameCount%200 === 0){
  textAlign(CENTER);
  let t = textWidth('draw make code');
  push();
  noStroke();
  fill(0,25);
  textSize(50);
  text('draw make code',-t-6,height*0.4+6);
  fill(255,25);
  textSize(50);
  text('draw make code',-t,height*0.4);
  pop();
  // }
}


function particles(){
  this.x = [];
  this.y = [];
  // this.xoff = [];
  this.xoff = 0;
  this.yoff = [];
  this.size = [];
  for (let i = 0; i < 360; i++){
    this.x.push(0);
    this.y.push(0);
    // this.xoff.push(0);
    this.yoff.push(0);
    this.size.push(100);
  }
 
  
  
  this.update = function(){
    for (let i = 0; i < 45; i++) {
      this.xoff += 0.0001;
      let rnoise = map( noise(this.xoff),
                       0,1,-TWO_PI,TWO_PI);
      let snoise = map(noise(this.xoff),0,1,
                       1,this.size[i]*3);
      
      this.x[i] = sin(i);
      this.y[i] = cos(i);
      push();
      translate(this.x[i]*snoise,
                this.y[i]*snoise);
      
      // stroke(0);
      // strokeWeight(3);
      // point(0,0);
      
      let scr = map(noise(frameCount*0.01),0,1,
                   50,355);
      let scg = map(noise(frameCount*0.025),0,1,
                   50,355);
      let scb = map(noise(frameCount*0.05),0,1,
                   50,355);
      
      // rotate((frameCount*0.01)+i);
      rotate(rnoise+i);
      stroke(0,0,0,15);
      strokeWeight(4);
      line(0,0,0,height/4);
      stroke(255,255,255,5);
      strokeWeight(1);
      line(0,0,-width/4,height/4);
      stroke(scr,scg,scb,5);
      strokeWeight(4);
      line(0,0,0,height/4);
      stroke(255-scr,255-scg,255-scb,10);
      line(0,0,width/4,-height/4);
      pop();
    }
  }
  
  
}













/// Click to Go Fullscreen /bottom click
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

