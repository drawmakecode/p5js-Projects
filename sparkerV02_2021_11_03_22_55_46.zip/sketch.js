//// Sparks Particle System
//// by Ed Cavett
//// Novemeber 2021

//// This system contains a set of particle movers
//// that release other particles that vector
//// away from their origin.
//// The particles have a lifespan and fade over
//// time.


//// Declare an array to hold our mover particles.
let sparks = [];


function setup() {
  createCanvas(windowWidth,
               windowHeight);
  //// Assign to the elements of the array,
  //// a sparks particle system.
  for (let i = 0; i < 4; i ++) {
    sparks.push(new sparkMaker());
  }
  
  //// Set the global graphics parameters.
  rectMode(CENTER);
  //// Clear the substrate.
  background(0,255);
}


function draw() {
  // background(0,4);
  /// Loop through each element in the mover
  /// system and execute the sparks update
  /// function to calculate and animate output.
  for (let i = 0; i < sparks.length; i++) {
    sparks[i].update(i);
  }
  if (frameCount%500 === 0) {
    background(0,150);
  }
}


//// This function generates sparks that are
//// set to the location of a mover.  The sparks
//// move from that origin and fade over time.
function sparkMaker() {
  
  //// Declare arrays to hold the properties
  //// of each spark.
  this.pos = [];
  this.vel = [];
  this.life = [];
  //// Assign a term to define how long 
  //// a spark lives.
  this.maxlife = 75;
  
  //// Declare and assign the properties
  //// of the mover particle.
  /// Its current location.
  this.x = width/2;
  this.y = height/2;
  /// Its target location.
  this.xt = width/2;
  this.yt = height/2;
  /// Move along the sparks array
  /// to activate new ones.  Start
  /// over at the begin after running out
  /// of sparks in the array.
  this.alive = 0;
  /// Assign a term to determine how many
  /// sparks are alive at one time.
  this.popu = 100;
  
  /// Loop through the population of sparks
  /// and give to the element in the array
  /// their starting conditions.
  for (let i = 0; i < this.popu; i++) {
    this.pos.push(createVector(0,0));
    this.vel.push(p5.Vector.random2D());
    //// By maxing out the life of each spark
    //// at start, the sparks will not be
    //// active until the random condition 
    //// turns them on.
    this.life.push(this.maxlife);
  }
  
  this.update = function(n){
    
    //// Execute the move function to animate
    //// the mover particle.  This will give
    //// each spark that is created a starting
    //// location to vector away from that 
    //// starts on the path of the mover.
    this.move();  
    
    /// Determine to bring a spark to life.
    /// Advance to the next available spark,
    /// and give it a life of 0.
    /// Any life under maxlife gets animated.
    if (random() < 0.2 && this.xt != this.x && 
       this.yt != this.y) {
      
      //// Advance to the next spark in the 
      //// array.  If at the end of the array,
      //// then start over at the beginning.
      //// This ensures that we always have
      //// a spark particle to animate in a 
      //// bin of sparks.
      this.alive += 1;
      if (this.alive > this.popu) {
        this.alive = 0;
      }
      
      //// A spark particle is born.
      //// Give it a starting location.
      //// Set its life to zero and give
      //// the spark a direction to move.
      //// Give the random vector a random
      //// magnitude or (multiple of unit speed).
      this.pos[this.alive] = createVector(this.x,this.y);
      this.life[this.alive] = 0;
      this.vel[this.alive] = p5.Vector.random2D();
      this.vel[this.alive].mult(random(0.1,2.5));
    }
    
    /// Loop through the array of all sparks.
    /// Animate the ones with a life of < maxlife.
    /// All sparks age every cycle.  When
    /// activated, that lifespan goes to 0.
    for (let i = 0; i < this.popu; i++) {
      
      /// Add to the lifespan of each spark,
      /// even if it is not being animated.
      this.life[i] += 0.5;
      
      /// Determine to move spark when alive.
      if (this.life[i] < this.maxlife) {
        
        /// Add the movement vector to the 
        /// spark's position.
        this.pos[i].add(this.vel[i]);
        
        /// Output the current spark.
        push();
        
        /// Color the spark according to its
        /// age.
        let colr = map(this.life[i],0,this.maxlife,255,25);
        stroke(colr,colr-55,(n+1)*75,128);
        
        /// Scale the spark by its age.
        let sw = map(this.life[i],0,this.maxlife,
                     10,1);
        strokeWeight(sw);

        /// We can choose to animate just the 
        /// spark or draw a line between the
        /// sparks that are alive.
        /// We'll draw a line from last spark
        /// to the current one.  We can do this
        /// only when the current spark is NOT
        /// on element #0 or #1.
        /// It will work if set to i > 0, but
        /// a line will go to 0,0 until the 
        /// that particle is alive once.
        /// Randomly determine to output
        /// a line or just a point.
        if (random() < 0.02) {
          if (i > 1) {
            line(this.pos[i-1].x,
                 this.pos[i-1].y,
                 this.pos[i].x,
                 this.pos[i].y);
          }
        }
        point(this.pos[i].x,
              this.pos[i].y);
        pop();
      }
    }
  }
  
  /// This method locates the mover particle
  /// by chasing a target location through
  //// linear interpolation.  
  this.move = function(){
    
    /// Determine to change the target position.
    if (random() < 0.015) {
      this.xt = random(width);
      this.yt = random(height);
    }
    
    /// Move the current mover particle to the
    /// target position.
    this.x = lerp(this.x,this.xt,0.025);
    this.y = lerp(this.y,this.yt,0.025);
    
    /// We can choose to animate this location.
    push();
    stroke(255,64);
    strokeWeight(10);
    point(this.x,this.y);
    
    /// We can choose to animate the target.
    // point(this.xt,this.yt);
    pop();
  }  
}

function mousePressed() {
  if (mouseX > 0 && mouseX < width &&
    mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

