//// Demolition Troopers
//// by Ed Cavett
//// July 2023

//// An fx(hash) NFT Video Game

///// Controls
///// Use mouse to aim.
///// Press f to fire.
///// Press p for computer-targeting.
///// Press i for instructions.
let img;
let img2;
let imgAssets;
let asset = [];
let transUnit;

let building;
let bTarget;

let jumper;

let worldFloor;
let fc;
let demolish;
let fallingOver;
let levelSet;

let tmaxLen;
let tminLen;

let mx;
let my;

let hitCount;
let hitLevel;
let ammoCount;
let nextLevel;

let gameCount;
let levelCount;
let pscore;
let ammoDifficulty;
let aimDifficulty;
let hitWorth;
let flyPoint;
let flyPointZ;
let zTBonus;
let bulletTarg;
let zTBonusAmnt;

let gunNestPos;
let pcPlayer;
let titleAsset;
let hitRange;

let howTo;
let howToOn;

function preload() {
  asset.push(loadImage("asset01.png")); // right-facing paratrooper
  asset.push(loadImage("asset02.png")); // left-facing paratrooper
  asset.push(loadImage("asset03.png")); // right-facing demolition
  asset.push(loadImage("asset04.png")); // left-facing demolition
  asset.push(loadImage("asset05.png")); // right-facing transport
  asset.push(loadImage("asset06.png")); // left-facing transport
  asset.push(loadImage("asset07.png")); // falling trooper 1
  asset.push(loadImage("asset08.png")); // falling trooper 2
  asset.push(loadImage("asset09.png")); // falling trooper 3
  asset.push(loadImage("asset10.png")); // small cloud 1
  asset.push(loadImage("asset11.png")); // small cloud 2
  asset.push(loadImage("asset12.png")); // large cloud 1
  asset.push(loadImage("asset13.png")); // large cloud 2
  titleAsset = loadImage("titleAsset.png"); // intro graphic
  let hashGen = fxrand() * 10000;
  console.log("random seed: " + hashGen);
  randomSeed(hashGen);
  noiseSeed(hashGen);
  console.log('---------------------');
  console.log('Demolition Troopers');
  console.log('by Ed Cavett (c) 2023');
  console.log('---------------------');
}

function setup() {
  createCanvas(1600, 800);
  img = createGraphics(width, height);
  img2 = createGraphics(width, height);
  img.rectMode(CENTER);
  img2.rectMode(CENTER);
  imageMode(CENTER);
  rectMode(CENTER);
  background(0, 200, 255, 255);
  fc = 0;
  demolish = 0;
  hitCount = 0;
  hitLevel = 10;
  ammoDifficulty = 0.5;
  aimDifficulty = 25; // less = stable / more = unstable
  ammoCount = hitLevel + floor(hitLevel * ammoDifficulty);
  nextLevel = 0;
  gameCount = 0;
  levelCount = 1;
  pscore = 0;
  hitWorth = 0;
  flyPoint = createVector(0, 0);
  flyPointZ = 30;
  zTBonus = 0;
  bulletTarg = createVector(0, 0);
  bulletFade = 0;
  zTBonusAmnt = 0;
  gunNestPos = createVector(0, 0);
  pcPlayer = 0;
  hitRange = 25;
  howTo = new instruct();
  howToOn = 0;
  for (let y = 0; y < height; y++) {
    let alph = map(y, 0, height, 0, 255);
    push();
    stroke(0, 150, 255, alph);
    strokeWeight(2);
    line(0, y, width, y);
    pop();
  }
}

function generatrix() {
  tmaxLen = height * 0.05;
  tminLen = tmaxLen * 0.3;
  worldFloor = height * 0.99 - 25;
  levelSet = 1;
  bTarget = -1;
  building = new buildings();
  buildWorld();
  building.update();
  let assetWideA = asset[0].width;
  let assetWideB = asset[2].width;
  asset[0].resize(assetWideA * 0.65, 0);
  asset[1].resize(assetWideA * 0.65, 0);
  asset[2].resize(assetWideB * 0.65, 0);
  asset[3].resize(assetWideB * 0.65, 0);
  asset[6].resize(assetWideB * 0.65, 0);
  asset[7].resize(assetWideB * 0.65, 0);
  asset[8].resize(assetWideB * 0.65, 0);
  transUnit = new planeMover();
  jumper = new troopJumpers();
  fallingOver = 0; /// toggles state at end of collapse
}

function draw() {
  let gameTime = 5;
  gameCount += 1;
  let flyPx = flyPoint.x;
  let flyPy = flyPoint.y;
  let flyPz = flyPointZ;
  let flyTargx = width * 0.93;
  let flyTargy = height * 0.125;
  let flyTargz = 30;
  flyPx = lerp(flyPx, flyTargx, 0.2);
  flyPy = lerp(flyPy, flyTargy, 0.2);
  flyPz = lerp(flyPz, flyTargz, 0.1);
  flyPoint = createVector(flyPx, flyPy);
  flyPointZ = flyPz;
  if (gameCount < gameTime && levelCount === 1) {
    introDisplay();
    fxpreview();
  }
  if (gameCount < gameTime && levelCount > 1) {
    levelUpDisplay();
  }
  if (gameCount === gameTime && levelCount === 1) {
    generatrix();
  }

  if (gameCount > gameTime) {
    if (bTarget < building.buildNum) {
      image(img, width * 0.5, height * 0.5);
      readOuts();
      if (transUnit.moveOn) {
        transUnit.update();
      }
      image(img2, width * 0.5, height * 0.5);
      userPointer();
      if (transUnit.troopOn) {
        jumper.update();
      }
    }

    if (demolish) {
      frameRate(10);
      fc -= 1;
      if (fc === 0) {
        frameRate(60);
        demolish = 0;
        transUnit.troopOn = 0;
        transUnit.moveOn = 1;
        fallingOver = 1;
      }
      jumper.update();
      building.btall[bTarget] = fc;
      building.update();
      image(img2, width * 0.5 + random(-5, 5), height * 0.5 + random(-5, 5));
      jumper.update();
    }

    if (bTarget === building.buildNum - 1 && fallingOver) {
      bTarget = 0;
      img2.push();
      img.filter(GRAY);
      img2.filter(GRAY);
      img2.strokeWeight(2);
      img2.stroke(0, 255);
      img2.fill(255, 255,0,255);
      img2.textSize(45);
      img2.textAlign(CENTER, CENTER);
      img2.text("Your city has been destroyed!", width * 0.5, height * 0.5);
      img2.textSize(45);
      img2.text("GAME OVER", width * 0.5, height * 0.575);
      img2.text("SCORE " + nfc(pscore), width * 0.5, height * 0.35);
      img2.pop();
      image(img, width * 0.5, height * 0.5);
      image(img2, width * 0.5, height * 0.5);
      noLoop();
    }
  }
  let ammoNeeded = hitLevel - hitCount - 1;
  if (ammoCount === ammoNeeded && hitCount != hitLevel) {
    readOuts();
    bTarget = 0;
    img2.push();
    img.filter(GRAY);
    img2.filter(GRAY);
    img2.strokeWeight(2);
    img2.stroke(0, 255);
    img2.fill(255, 255);
    img2.textSize(45);
    img2.textAlign(CENTER, CENTER);
    img2.text("Without enough ammunition,", width * 0.5, height * 0.5);
    img2.text("Your city has been overun!", width * 0.5, height * 0.56);
    img2.text("SCORE " + nfc(pscore), width * 0.5, height * 0.35);
    img2.textSize(45);
    img2.text("GAME OVER", width * 0.5, height * 0.75);
    img2.pop();
    image(img, width * 0.5, height * 0.5);
    image(img2, width * 0.5, height * 0.5);
    noLoop();
  }
  
  if (levelCount === 25) {
    img2.push();
    img.filter(GRAY);
    img2.filter(GRAY);
    img2.strokeWeight(2);
    img2.stroke(0, 255);
    img2.fill(255, 255);
    img2.textSize(45);
    img2.textAlign(CENTER, CENTER);
    img2.text("You've DEFEATED the enemy!", width * 0.5, height * 0.5);
    img2.text("Congratulation! You've won the war!", width * 0.5, height * 0.56);
    img2.text("SCORE " + nfc(pscore), width * 0.5, height * 0.35);
    img2.textSize(45);
    img2.text("GAME FINISHED!", width * 0.5, height * 0.75);
    img2.pop();
    image(img, width * 0.5, height * 0.5);
    image(img2, width * 0.5, height * 0.5);
    noLoop();

  }
  
  
}

function introDisplay() {
  push();
  stroke(0,255);
  strokeWeight(10);
  fill(0, 255);
  textAlign(CENTER, CENTER);
  image(titleAsset, width * 0.5, height * 0.5);
  textSize(45);
  text("One moment while game loads.",
       width * 0.53,
       height * 0.83);
  text("Press H for Play Guide.",
       width * 0.53,
       height * 0.91);
  noStroke();
  fill(0,255,0, 255);
  textAlign(CENTER, CENTER);
  text("One moment while game loads.", width * 0.53, height * 0.83);
  fill(200,255,200, 255);
  text("Press H for Play Guide.", width * 0.53, height * 0.91);
  pop();
}

function levelUpDisplay() {
  background(255, 255);
  tint(125, 125, 125, 255);
  image(img, width * 0.5, height * 0.5);
  image(img2, width * 0.5, height * 0.5);
  noTint();
  bulletFade = 0;
  push();
  textAlign(CENTER, CENTER);
  noStroke();
  fill(0, 255);
  textSize(50);
  text("Mission Accomplished!", width * 0.5 + 2, height * 0.5 + 2);
  text(
      "Power Level Upgraded.",
      width * 0.5 + 2,
      height * 0.7 + 2
    );
  if (zTBonus) {
    textSize(60);
    text(
      "Bonus Achieved! Defenses Upgraded.",
      width * 0.5 + 2,
      height * 0.6 + 2
    );
    
    text(nfc(zTBonusAmnt), width * 0.5 + 2, height * 0.35 + 2);
  }
  fill(255, 255);
  textSize(50);
  text("Mission Accomplished!", width * 0.5, height * 0.5);
  text(
      "Power Level Upgraded.",
      width * 0.5,
      height * 0.7
    );
  if (zTBonus) {
    textSize(60);
    text("Bonus Achieved! Defenses Upgraded.", width * 0.5, height * 0.6);
    text(nfc(zTBonusAmnt), width * 0.5, height * 0.35);
  }
  pop();
}

function readOuts() {
  let ammoNeeded = hitLevel - hitCount;
  push();
  textSize(30);
  textAlign(LEFT, CENTER);
  fill(0, 255);
  strokeWeight(2);
  stroke(0, 255);
  textAlign(LEFT, CENTER);
  text(building.buildNum - bTarget - 1, width * 0.11 + 2, height * 0.025 + 2);
  text(
    jumper.gunOnGround + "/" + levelSet,
    width * 0.11 + 2,
    height * 0.075 + 2
  );
  text(hitCount + "/" + hitLevel, width * 0.11 + 2, height * 0.125 + 2);
  text(ammoCount + "/" + ammoNeeded, width * 0.11 + 2, height * 0.175 + 2);
  textAlign(RIGHT, CENTER);
  text(levelCount, width * 0.93 + 2, height * 0.025 + 2);
  text(nfc(pscore), width * 0.93 + 2, height * 0.075 + 2);
  text(hitRange, width * 0.93 + 2, height * 0.175 + 2);
  textSize(flyPointZ);
  text(nfc(hitWorth), flyPoint.x + 2, flyPoint.y + 2);

  textSize(30);
  noStroke();
  fill(255, 255);
  textAlign(LEFT, CENTER);
  text(building.buildNum - bTarget - 1, width * 0.11, height * 0.025);
  text(jumper.gunOnGround + "/" + levelSet, width * 0.11, height * 0.075);
  text(hitCount + "/" + hitLevel, width * 0.11, height * 0.125);
  text(ammoCount + "/" + ammoNeeded, width * 0.11, height * 0.175);
  textAlign(RIGHT, CENTER);
  text(levelCount, width * 0.93, height * 0.025);
  text(nfc(pscore), width * 0.93, height * 0.075);
  text(hitRange, width * 0.93, height * 0.175);
  textSize(flyPointZ);
  text(nfc(hitWorth), flyPoint.x, flyPoint.y);
  pop();
  if (howToOn) {
    howTo.update();
  }
}

function troopJumpers() {
  this.tpos = [];
  this.tvel = [];
  this.trate = [];
  this.tlife = [];
  this.facing = [];
  this.twide = asset[0].width;
  this.ttall = asset[0].height;
  this.gunner = [];
  this.gunOnGround = 0;
  this.wander = [];
  this.off = [];
  this.xSet = [];
  this.prevxSet = [];
  this.waveSpeed = [];
  for (let n = 0; n < 25; n++) {
    this.tpos.push(
      createVector(
        random(this.twide, width - this.twide),
        random(-height, -height * 0.75)
      )
    );
    let rateBase = map(levelCount, 1, 25, 4, 16);
    this.trate.push(random(rateBase * 0.5, rateBase));
    this.tvel.push(createVector(0, this.trate[n]));
    this.tlife.push(0);
    this.facing.push(floor(random(2)));
    this.gunner.push(0);
    this.off.push(random(10000));
    this.wander.push(0);
    this.xSet.push(random(1000));
    this.waveSpeed.push(0.001);
    this.prevxSet.push(0);
  }

  this.update = function () {
    for (let i = 0; i < this.tpos.length; i++) {
      this.prevxSet[i] = this.xSet[i];

      if (!this.tlife[i]) {
        if (random() < 0.00045 && !this.gunner[i]) {
          this.tlife[i] = 1;
        }
      }

      if (this.tlife[i]) {
        this.prevxSet[i] = this.tpos[i].x;
        this.tpos[i].add(this.tvel[i]);
        this.waveSpeed[i] = levelCount * 0.0025;
        let moveWave =
          sin((this.xSet[i] + frameCount) * this.waveSpeed[i]) * levelCount;
        this.tpos[i].x += moveWave;
        if (this.tpos[i].y > worldFloor - this.ttall * 0.5) {
          this.tlife[i] = 0;
          this.gunner[i] = 1;
          this.gunOnGround += 1;
          this.tpos[i].y = worldFloor + this.ttall * 1.6;
        }

        if (this.tpos[i].x > width - this.twide) {
          this.tpos[i].x = width - this.twide;
        }
        if (this.tpos[i].x < this.twide) {
          this.tpos[i].x = this.twide;
        }

        // match body position with movement direction
        if (this.tpos[i].x > this.prevxSet[i]) {
          this.facing[i] = 0;
        }
        if (this.tpos[i].x < this.prevxSet[i]) {
          this.facing[i] = 1;
        }

        push();
        translate(this.tpos[i].x, this.tpos[i].y);
        rotate(map(noise(i + 1, frameCount * 0.01), 0, 1, -PI * 0.2, PI * 0.2));
        image(asset[this.facing[i]], 0, 0);
        pop();

        push();
        translate(this.tpos[i].x, this.tpos[i].y + this.ttall * 0.25);
        if (worldFloor-this.tpos[i].y < height*0.32) {
          push();
          let targetCol = abs(sin(frameCount*0.1)*255);
          stroke(255, targetCol, 0, 175);
          strokeWeight(abs(sin(frameCount * 0.1) * 16));
          noFill();
          circle(0, 0, 60);
          pop();
        }
        pop();
      }

      if (this.gunner[i]) {
        push();
        if (this.tpos[i].x + this.wander[i] < building.bpos[bTarget + 1].x) {
          this.wander[i] += 2;
        } else {
          this.wander[i] -= 2;
        }
        let wander = map(noise(this.off[i], frameCount * 0.05), 0, 1, -20, 20);
        translate(
          this.tpos[i].x + this.wander[i] + wander,
          this.tpos[i].y - this.ttall * 1.5
        );
        image(asset[this.facing[i] + 2], 0, -asset[2].height * 0.5);
        pop();
      }
    }

    if (this.gunOnGround === levelSet) {
      fallingOver = 0;
      this.gunOnGround = 0;
      building.bGone[bTarget] = 1;
      building.update();
      bTarget += 1;
      demolish = 1;
      fc = building.btall[bTarget];
      for (let reSet = 0; reSet < this.tpos.length; reSet++) {
        this.tpos[reSet] = createVector(
          random(this.twide, width - this.twide),
          -this.ttall
        );
        let rateBase = map(levelCount, 1, 10, 4, 16);
        this.trate[reSet] = random(rateBase * 0.5, rateBase);
        this.tvel[reSet] = createVector(0, this.trate[reSet]);
        this.tlife[reSet] = 0;
        this.facing[reSet] = floor(random(2));
        this.gunner[reSet] = 0;
        this.wander[reSet] = 0;
      }
    }

    if (nextLevel) {
      gameCount = 0;
      hitCount = 0;
      hitLevel += 5;
      transUnit.troopOn = 1;
      transUnit.moveOn = 0;
      nextLevel = 0;
      ammoCount = hitLevel + floor(hitLevel * ammoDifficulty);
      levelCount += 1;
      ammoDifficulty *= 0.9;
      aimDifficulty += 2;
      transUnit.moveOn = 1;
      transUnit.troopOn = 0;
      if (aimDifficulty > 75) {
        aimDifficulty = 75;
      }
      if (ammoDifficulty < 0.1) {
        ammoDifficulty = 0.1;
      }

      this.gunOnGround = 0;
      for (let reSet = 0; reSet < this.tpos.length; reSet++) {
        this.tpos[reSet] = createVector(
          random(this.twide, width - this.twide),
          -this.ttall
        );
        let rateBase = map(levelCount, 1, 25, 4, 16);
        this.trate[reSet] = random(rateBase * 0.5, rateBase);
        this.tvel[reSet] = createVector(0, this.trate[reSet]);
        this.tlife[reSet] = 0;
        this.facing[reSet] = floor(random(2));
        this.gunner[reSet] = 0;
        this.wander[reSet] = 0;
      }
    }
  };
}

function planeMover() {
  let transMax = 15;
  let transMin = transMax * 0.8;
  this.moveOn = 1;
  this.troopOn = 0;
  this.way = floor(random(2));
  this.pos = createVector(-asset[4].width, random(height * 0.1, height * 0.3));
  let speedSet = floor(random(transMin, transMax));
  if (this.way) {
    speedSet *= -1;
    this.pos = createVector(
      width + asset[4].width,
      random(height * 0.1, height * 0.5)
    );
  }
  this.vel = createVector(speedSet, 0);
  this.waveH = speedSet * 0.005;

  this.update = function () {
    this.pos.add(this.vel);
    if (this.pos.x > width + asset[4].width || this.pos.x < -asset[5].width) {
      this.moveOn = 0;
      this.troopOn = 1;
      this.way = floor(random(2));
      this.pos.set(
        createVector(-asset[4].width, random(height * 0.1, height * 0.3))
      );
      speedSet = floor(random(transMin, transMax));
      if (this.way) {
        this.pos.set(
          createVector(
            width + asset[4].width,
            random(height * 0.1, height * 0.3)
          )
        );
        speedSet *= -1;
      }
      this.waveH = speedSet * 0.001;
      this.vel = createVector(speedSet, 0);
    }
    let ymod = sin(frameCount * this.waveH) * (height * 0.1);
    push();
    translate(this.pos.x, this.pos.y);
    if (this.way) {
      image(asset[5], 0, ymod);
    } else {
      image(asset[4], 0, ymod);
    }

    pop();
  };
}

function buildWorld() {
  img.background(0, 200, 255, 255);
  for (let y = 0; y < height; y++) {
    let alph = map(y, 0, height, -128, 255);
    img.push();
    img.stroke(0, 150, 255, alph);
    img.strokeWeight(2);
    img.line(0, y, width, y);
    img.pop();
  }
  let clnDense = floor(random(-5, 50));
  if (clnDense < 0) {
    clnDense = 0;
  }
  for (let cln = 0; cln < clnDense; cln++) {
    let rndCloud = floor(random(4));
    img.push();
    img.translate(random(width), random(height * 0.5));
    img.image(asset[9 + rndCloud], 0, 0);
    img.pop();
  }
  // Mountains
  let yset = height * 0.2;
  let xoff = random(1000);
  let yoff = random(1000);
  let tall = height * 0.05;
  for (let n = 0; n < 8; n++) {
    let gap = random(width * 0.05, width * 0.1);
    yset += height * 0.01 * n;
    ysetMod = (n + 1) * height * 0.05;
    img.push();
    img.beginShape();
    img.vertex(-width * 0.1, height * 1.1 + yset + ysetMod);
    for (let x = -width * 0.1; x < width * 1.1 + gap; x += gap) {
      let y = map(
        noise(n + 1, (xoff + x) * 0.1, yoff),
        0,
        1,
        -tall + height * 0.1 * (6 - n),
        tall + height * 0.01 * (6 - n)
      );
      if (random() < 0.5) {
        img.curveVertex(x, y + yset + ysetMod);
      } else {
        img.vertex(x, y + yset + ysetMod);
      }
    }
    yoff += 0.01;
    img.vertex(width * 1.1, height * 1.1 + yset + ysetMod);
    img.vertex(-width * 0.1, height * 1.1 + yset + ysetMod);
    let col = map(n, 0, 10, 255, 50);
    img.fill(col * 0.2, col * 0.8, col * 0.2, 255);
    img.stroke(col * 0.1, col * 0.7, col * 0.1, 255);
    if (random() < 0) {
      img.fill(col * 0.2, col * 0.4, col * 0.2, 255);
      img.stroke(col * 0.1, col * 0.3, col * 0.1, 255);
    }
    img.strokeWeight(1);
    img.endShape(CLOSE);
    img.pop();
  }

  /// Ground
  for (let x = -width * 0.1; x < width * 1.1; x += 10) {
    img.push();
    img.translate(random(-10, 10) + x, height * 0.99);
    for (let n = 0; n < 50; n++) {
      let col = random(196, 255);
      let rockPos = createVector(random(-1, 1), random(-1, 1));
      let rockMag = random(1, 25);
      rockPos.mult(rockMag);
      let rockZ = random(3, 10);
      let pc = random(0.2, 1.1);
      img.strokeWeight(rockZ);
      img.stroke(col * pc, col * pc * 0.7, col * pc * 0.1, 255);
      img.point(rockPos.x, rockPos.y);
    }
    img.pop();
    img.strokeWeight(25);
    img.stroke(100, 255);
    img.line(-width * 0.1, worldFloor + 7, width * 1.1, worldFloor + 7);
  }
  img.filter(BLUR,2);
  img.push();
  img.noStroke();
  img.fill(100, 0, 0, 100);
  img.rect(0, height * 0.025, width * 0.35, 25);
  img.rect(0, height * 0.075, width * 0.35, 25);
  img.rect(0, height * 0.125, width * 0.35, 25);
  img.rect(0, height * 0.175, width * 0.35, 25);
  img.rect(width, height * 0.025, width * 0.35, 25);
  img.rect(width, height * 0.075, width * 0.35, 25);
  img.rect(width, height * 0.125, width * 0.35, 25);
  img.rect(width, height * 0.175, width * 0.35, 25);
  img.textSize(25);
  img.textAlign(LEFT, CENTER);
  img.fill(0, 255);
  img.strokeWeight(2);
  img.stroke(0, 255);
  img.text("Buildings", width * 0.01 + 2, height * 0.025 + 2);
  img.text("Landings", width * 0.01 + 2, height * 0.075 + 2);
  img.text("Troopers Hit", width * 0.01 + 2, height * 0.125 + 2);
  img.text("Ammunition", width * 0.01 + 2, height * 0.175 + 2);

  img.noStroke();
  img.fill(255, 255);
  img.text("Buildings ", width * 0.01, height * 0.025);
  img.text("Landings  ", width * 0.01, height * 0.075);
  img.text("Troopers Hit", width * 0.01, height * 0.125);
  img.text("Ammunition", width * 0.01, height * 0.175);

  img.textAlign(RIGHT, CENTER);
  img.fill(0, 255);
  img.text("Level", width * 0.99 + 2, height * 0.025 + 2);
  img.text("Score", width * 0.99 + 2, height * 0.075 + 2);
  img.text("Award", width * 0.99 + 2, height * 0.125 + 2);
  img.text("Power", width * 0.99 + 2, height * 0.175 + 2);

  img.fill(255, 255);
  img.text("Level", width * 0.99, height * 0.025);
  img.text("Score", width * 0.99, height * 0.075);
  img.text("Award", width * 0.99, height * 0.125);
  img.text("Power", width * 0.99, height * 0.175);

  img.pop();

  //// Background trees
  for (let tn = width * 0.05; tn < width * 1.05; tn += width * 0.05) {
    if (random() < 0.7) {
      img.push();
      img.translate(tn, worldFloor - 10);
      for (let sr = 1; sr < width * 0.15; sr += 5) {
        let salph = map(sr, 1, width * 0.15, 8, 0);
        img.push();
        img.noStroke();
        img.fill(0, salph);
        let srY = map(sr, 1, width * 0.15, 1, 40);
        img.ellipse(20, -5, sr, srY);
        img.pop();
      }
      for (let nt = 0; nt < 3; nt++) {
        let fixSize = map(nt, 0, 3, 1, 0.75);
        treeMaker(tmaxLen * fixSize);
      }
      img.pop();
    }
  }
}

function treeMaker(len) {
  let swMax = 10;
  img.push();
  img.strokeCap(SQUARE);
  img.translate(0, 0);
  if (len < tmaxLen) {
    img.rotate(random(-PI * 0.12, PI * 0.12));
  }
  let sw = map(len, tminLen, tmaxLen, 1, swMax);
  img.strokeWeight(sw);
  img.stroke(125, 75, 25, 255);
  img.line(0, 0, 0, -len * 1.05);
  for (let tx = 0; tx < 10; tx++) {
    img.strokeWeight(sw * 0.3);
    img.stroke(random(75, 100), random(25, 50), random(12), 255);
    img.point(random(-sw * 0.2, sw * 0.2), random(-len, 0));
  }
  img.stroke(75, 25, 5, 255);
  img.strokeWeight(1);
  img.line(sw * 0.5, 0, sw * 0.5, -len);

  if (random() < 0.2) {
    img.push();
    img.strokeCap(SQUARE);
    img.translate(0, random(-len));
    if (len < tmaxLen) {
      img.rotate(random(-PI * 0.12, PI * 0.12));
    }
    let sw = map(len, tminLen, tmaxLen, 1, swMax);
    img.strokeWeight(sw);
    img.stroke(125, 75, 25, 255);
    img.line(0, 0, 0, -len * 1.05);
    for (let tx = 0; tx < 10; tx++) {
      img.strokeWeight(sw * 0.3);
      img.stroke(random(75, 100), random(25, 50), random(12), 255);
      img.point(random(-sw * 0.2, sw * 0.2), random(-len, 0));
    }
    img.stroke(75, 25, 5, 255);
    img.strokeWeight(1);
    img.line(sw * 0.5, 0, sw * 0.5, -len);
    img.translate(0, -len);
    if (len > tminLen) {
      treeMaker(len * 0.85);
    }
    if (len < tmaxLen * 0.65) {
      leafMaker(len);
    }
    img.pop();
  }
  if (random() < 0.3) {
    img.push();
    img.strokeCap(SQUARE);
    img.translate(0, random(-len));
    if (len < tmaxLen) {
      img.rotate(random(-PI * 0.12, PI * 0.12));
    }
    let sw = map(len, tminLen, tmaxLen, 1, swMax);
    img.strokeWeight(sw);
    img.stroke(125, 75, 25, 255);
    img.line(0, 0, 0, -len * 1.05);
    for (let tx = 0; tx < 10; tx++) {
      img.strokeWeight(sw * 0.3);
      img.stroke(random(75, 100), random(25, 50), random(12), 255);
      img.point(random(-sw * 0.2, sw * 0.2), random(-len, 0));
    }
    img.stroke(75, 25, 5, 255);
    img.strokeWeight(1);
    img.line(sw * 0.5, 0, sw * 0.5, -len);
    img.translate(0, -len);
    if (len > tminLen) {
      treeMaker(len * 0.85);
    }
    if (len < tmaxLen * 0.65) {
      leafMaker(len);
    }
    img.pop();
  }

  img.translate(0, -len);
  if (len > tminLen) {
    treeMaker(len * 0.8);
  }
  if (len < tmaxLen * 0.65) {
    leafMaker(len);
  }
  img.pop();
}

function leafMaker(len) {
  for (let n = 0; n < 15; n++) {
    pos = createVector(random(-1, 1), random(-1, 1));
    pos.mult(len * 0.75);
    img.push();
    img.translate(pos.x, pos.y);
    img.strokeWeight(random(2, 12));
    let col = map(len, tminLen, tmaxLen, 100, 10);
    img.stroke(25, col * random(0.8, 1.1), col * 0.5, 255);
    if (random() < 0.1) {
      img.stroke(col * random(0.8, 1.1), col * 0.5, col * 0.1, 255);
    }
    img.point(0, 0);
    img.pop();
  }
}

function buildings() {
  /// Buildings
  this.bpos = [];
  this.btall = [];
  this.col = [];
  this.bGone = [];
  this.wLightOn = [];
  this.wLightCol = [];
  this.wDense = [];

  this.bwide = floor(width * 0.1);
  this.fhigh = floor(this.bwide * 0.4);
  this.buildNum = 5;

  /// Set Locations / Size Attributes
  for (let n = 0; n < this.buildNum; n++) {
    this.bGone.push(0);
    this.bpos.push(
      createVector(
        (n + 1) * (this.bwide * 1.2) +
          random(-this.bwide * 0.1, this.bwide * 0.1),
        0
      )
    );
    let tallness = floor(random(3, 10));
    if (n === this.buildNum - 1) {
      tallness = 6;
    }
    this.btall.push(tallness);
    this.col.push(random(128));
    gunNestPos = createVector(
      (n + 1) * (this.bwide * 1.2) +
        random(-this.bwide * 0.1, this.bwide * 0.1),
      worldFloor - tallness * this.fhigh
    );
  }

  /// Set Windows Density / Appearance
  let ni = -1;
  for (let n = 0; n < this.bpos.length; n++) {
    for (let fl = 0; fl < this.btall[n]; fl++) {
      let wDenseSet = random(0.2, 0.5); /// chance of a window

      for (
        let wn = -this.bwide * 0.5 + this.fhigh * 0.5;
        wn < this.bwide * 0.5;
        wn += this.fhigh * 0.5
      ) {
        ni += 1;
        this.wDense.push(wDenseSet);
        this.wLightOn.push(random()); /// chance a light is on at this window
        let wLightOn = this.wLightOn[ni];
        let wDense = this.wDense[ni];
        if (wLightOn < wDense) {
          /// yes = a window is there
          this.wLightCol.push(1); /// okay, so color it this way...
        } else {
          this.wLightCol.push(random()); /// ... or that way.
        }
      }
    }
  }

  this.update = function () {
    img2 = createGraphics(width, height);
    img2.rectMode(CENTER);
    let i = -1;
    for (let n = 0; n < this.bpos.length; n++) {
      img2.push();
      img2.translate(this.bpos[n].x, worldFloor + this.fhigh * 0.5);
      for (let fl = 0; fl < this.btall[n]; fl++) {
        let col = map(fl, 0, this.btall[n], 25, 150);
        img2.push();
        img2.translate(0, -fl * this.fhigh - this.fhigh);
        img2.strokeWeight(1);
        img2.stroke(random(175, 255), 255);
        img2.fill(col + random(-10, 10), col * 0.2, this.col[n] * 0.25, 255);
        if (!this.bGone[n]) {
          img2.rect(0, 0, this.bwide, this.fhigh);
        }
        for (
          let wn = -this.bwide * 0.5 + this.fhigh * 0.5;
          wn < this.bwide * 0.5;
          wn += this.fhigh * 0.5
        ) {
          i += 1;
          img2.fill(random(25, 75), 255);
          img2.rect(wn, 0, this.fhigh * 0.35, this.fhigh * 0.6);
          if (this.wLightOn[i] < this.wDense[i]) {
            img2.push();
            img2.noStroke();
            img2.fill(255 - col, 255 - col * 0.7, 255 - this.col[n], 255);
            if (this.wLightCol[i] < 0.33) {
              img2.fill(150, 255);
            }
            if (demolish && random() < 0.5) {
              img2.noFill();
            }
            if (!this.bGone[n]) {
              img2.rect(wn, 0, this.fhigh * 0.35, this.fhigh * 0.6);
            }
            img2.pop();
          }
          img2.strokeWeight(2);
          img2.stroke(0, 255);
          img2.line(wn, -this.fhigh * 0.3, wn, this.fhigh * 0.3);
          img2.line(-this.fhigh * 0.175 + wn, 0, this.fhigh * 0.175 + wn, 0);
        }
        img2.pop();
      }
      img2.pop();
    }
  };
}

function userPointer() {
  this.x = mouseX;
  this.y = mouseY;
  if (pcPlayer) {
    this.x = gunNestPos.x;
    this.y = gunNestPos.y - 25;
  }
  let pcHit = 0;
  if (pcPlayer) {
    for (let i = 0; i < jumper.tpos.length; i++) {
      if (
        jumper.tpos[i].y > height * random(0.2, 0.9) + jumper.ttall * 0.25 &&
        jumper.tpos[i].y < worldFloor
      ) {
        if (random() < 0.3) {
          this.x = jumper.tpos[i].x;
          this.y = jumper.tpos[i].y + jumper.ttall * 0.25;
          bulletTarg = createVector(this.x, this.y);
          bulletFade = 255;
          pcHit = 1;
        }
      }
    }
  }

  let modx = 0; //map(noise(frameCount*0.05,this.x*0.05),0,1,
  // -aimDifficulty,aimDifficulty);
  let mody = 0; //map(noise(frameCount*0.05,this.y*0.05),0,1,
  // -aimDifficulty,aimDifficulty);
  mx = this.x + modx;
  my = this.y + mody;

  let pntsize = hitRange;
  push();

  if (!pcPlayer) {
    rectMode(CENTER);
    strokeWeight(5);
    stroke(255,0,0, 255);
    noFill();
    ellipse(mx, my, pntsize);
    stroke(255,255);
    strokeWeight(3);
    line(mx - pntsize*1.25, my, mx + pntsize*1.25, my);
    line(mx, my - pntsize*1.25, mx, my + pntsize*1.25);
  }

  push();
  translate(gunNestPos.x, gunNestPos.y - 12.5);
  let rget = createVector(
    mx - gunNestPos.x,
    my - gunNestPos.y - 12.5
  ).heading();
  rotate(rget);
  stroke(255, 255);
  strokeWeight(12);
  line(0, 0, 50, 0);
  strokeWeight(4);
  line(45, -10, 45, 10);
  line(35, -10, 35, 10);
  line(25, -10, 25, 10);
  stroke(125, 255);
  strokeWeight(10);
  line(0, 0, 50, 0);
  strokeWeight(2);
  line(45, -10, 45, 10);
  line(35, -10, 35, 10);
  line(25, -10, 25, 10);
  pop();
  bulletFade -= 32; /// laser pulse duration lower# = longer duration
  stroke(255, bulletFade * 0.5, bulletFade * 0.5, bulletFade);
  let bsw = map(bulletFade, 255, 0, 15, 1); /// laser thickness
  strokeWeight(bsw);
  line(gunNestPos.x, gunNestPos.y - 12.5, bulletTarg.x, bulletTarg.y);
  fill(125, 255);
  strokeWeight(2);
  stroke(255, 255);
  rect(gunNestPos.x, gunNestPos.y - 12.5, 50, 25); /// gunner's nest
  arc(gunNestPos.x, gunNestPos.y - 12.5, 50, 50, -PI, 0, CHORD);
  pop();

  if (pcPlayer && pcHit) {
    push();
    for (let i = 0; i < jumper.tpos.length; i++) {
      let d = dist(
        mx,
        my,
        jumper.tpos[i].x,
        jumper.tpos[i].y + jumper.ttall * 0.25
      );
      bulletTarg = createVector(mx, my);
      bulletFade = 255;
      if (d < 25) {
        let hitValue = floor((worldFloor - jumper.tpos[i].y) * 0.1);
        let fallBonus = jumper.trate[i] * levelCount;
        let zeroTroopBonus = 0;
        hitWorth = floor(levelCount * hitValue + fallBonus);
        hitWorth += zeroTroopBonus;
        pscore += hitWorth;
        flyPoint = jumper.tpos[i].copy();
        jumper.tpos[i].x = random(jumper.twide, width - jumper.twide);
        jumper.tpos[i].y = -height * random(0.5, 0.75);
        hitCount += 1;
        if (hitCount === hitLevel) {
          zTBonus = 0;
          if (jumper.gunOnGround === 0) {
            levelSet = levelCount + 1;
            if (levelSet > 10) {
              levelSet = 10;
            }
            zeroTroopBonus = floor((hitValue + fallBonus) * levelCount) * 25;
            zTBonusAmnt = zeroTroopBonus;
            zTBonus = 1;
            hitWorth += zeroTroopBonus;
            pscore += hitWorth;
          }
          nextLevel = 1;
          flyPoint = createVector(width * 0.93, height * 0.125);
          flyPointZ = 30;
        }
      }
    }
    ammoCount -= 1;

    pop();
  }
}

function keyPressed() {
  let ammoNeeded = hitLevel - hitCount - 1;
  if (key === "f" && ammoCount > ammoNeeded) {
    push();
    for (let i = 0; i < jumper.tpos.length; i++) {
      let d = dist(
        mx,
        my,
        jumper.tpos[i].x,
        jumper.tpos[i].y + jumper.ttall * 0.25
      );
      bulletTarg = createVector(mx, my);
      bulletFade = 255;
      if (d < hitRange) {
        let hitValue = floor((worldFloor - jumper.tpos[i].y) * 0.1);
        let fallBonus = jumper.trate[i] * levelCount;
        let zeroTroopBonus = 0;
        hitWorth = floor(levelCount * hitValue + fallBonus);
        hitWorth += zeroTroopBonus;
        pscore += hitWorth;
        flyPoint = jumper.tpos[i].copy();
        flyPointZ = 75;
        jumper.tpos[i].x = random(jumper.twide, width - jumper.twide);
        jumper.tpos[i].y = -height * random(0.5, 0.75);
        hitCount += 1;
        if (hitCount === hitLevel) {
          zTBonus = 0;
          if (jumper.gunOnGround === 0) {
            levelSet = levelCount + 1;
            if (levelSet > 10) {
              levelSet = 10;
            }
            hitRange += (levelCount*5);  /// gameDifficult = 5 easy, 4 challenging, 3 difficult, 2 expert, 1 god-like
            if (hitRange > 100) {
              hitRange = 100;
            }
            zeroTroopBonus = floor((hitValue + fallBonus) * levelCount) * 25;
            zTBonusAmnt = zeroTroopBonus;
            zTBonus = 1;
            hitWorth += zeroTroopBonus;
            pscore += hitWorth;
          }
          nextLevel = 1;
          flyPoint = createVector(width * 0.93, height * 0.125);
          flyPointZ = 75;
        }
      }
    }
    ammoCount -= 1;

    pop();
  }
  /// Activate computer-targeting
  if (key === "c") {
    if (pcPlayer) {
      pcPlayer = 0;
    } else {
      pcPlayer = 1;
      image(img, width * 0.5, height * 0.5);
      image(img2, width * 0.5, height * 0.5);
      let layerA = get();
      tint(255, 0, 0, 100);
      image(layerA, width * 0.5, height * 0.5);
      noTint();
      img = get();
    }
  }
  //// Activate Palyer's Guide
  if (key === "h") {
    if (howToOn) {
      howToOn = 0;
    } else {
      howToOn = 1;
    }
  }
  
  if (keyCode === DOWN_ARROW) {
    saveCanvas("ed_cavett_DemolitionTroopers", "png");
  }
  
}

function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

function instruct(){
  this.i = [];
  this.i.push("Demolition Troopers - by Ed Cavett (c) 2023");
  this.i.push("GAME CONTROLS:");
  this.i.push("Use the mouse to target paratroopers.");
  this.i.push("Press F to fire your pulse laser ray.");
  this.i.push("Press C to toggle the computer targeting system.");
  this.i.push("Press H to toggle this guide.");
  this.i.push("Press the Down Arrow to save a screen capture.");
  this.i.push("Note: A computer-play will tint the output.");
  this.i.push("MISSION GOALS:");
  this.i.push("Defend the city against waves of invading demolition troopers.");
  this.i.push("Use your laser ray to vaporize paratroopers before they land.");
  this.i.push("Paratroopers will land in an attempt to destroy the buildings in your city!");
  this.i.push("When enough troopers land, they will destroy a building.");
  this.i.push("Your mission will fail if all the buildings are destroyed.");
  this.i.push("Target and destroy enough paratroopers without running out of ammunition.");
  this.i.push("Eliminate the wave to advance to the next level.");
  this.i.push("Each advance will upgrade your defenses by increasing the range of your laser.");
  this.i.push("Your buildings will be reinforced after completing a level.");
  this.i.push("Heavily fortified buildings require more demolition troopers to destroy them.");
  this.i.push("You are awarded for each trooper you hit.");
  this.i.push("Complete a level with zero troopers on the ground to receive a Bonus Award.");
  this.i.push("Hit troopers quickly for a larger award.");
  this.i.push("Destroy all 25 waves to complete your mission and save the city.");
  this.i.push("Each wave of troopers will fall faster and evade more quickly.");
  
  this.i.push("MISSION STATUS DISPLAY:");
  this.i.push("BUILDINGS: The number of buildings left to defend.");
  this.i.push("Dual Value Displays: a) first number / b) second number");
  this.i.push("LANDINGS a) The number of demolition troopers on the ground");
  this.i.push("LANDINGS b) The number of demolition troopers needed to demolish a building.");
  this.i.push("TROOPERS HIT a) The number of paratroopers that have been hit this level.");
  this.i.push("TROOPERS HIT b) The number of paratroopers you must hit to advance.");
  this.i.push("AMMUNITION a) Laser pulses remaining.");
  this.i.push("AMMUNITION b) Laser pulses needed to destroy the current attack.");
  this.i.push("LEVEL: Current mission level.  Complete a total of 25 levels to defeat the enemy.");
  this.i.push("SCORE: Total points award during the mission.");
  this.i.push("AWARD: Total points awarded for hitting a paratrooper plus any level bonuses.");
  this.i.push("POWER: The effective targeting range of the laser pulse.");
  this.i.push("targeting Crosshairs: Center the circle on the paratrooper to vaporize enemy.");
  
  this.lineNum = 0;
  this.countA = 0;
  
  this.update = function() {
    this.countA += 1;
    if (frameCount%250 === 0) {
      this.lineNum += 1;
      this.countA = 0;
      if (this.lineNum > this.i.length-1) {
        this.lineNum = 0;
        howToOn = 0;
      }
    }
    let alph = map(this.countA,0,250,-96,512);
    push();
    textAlign(CENTER,CENTER);
    textSize(25);
    fill(255,alph);
    stroke(0,alph);
    if (alph > 255) {
      fill(255,512-alph);
      stroke(0,512-alph);
    }
    strokeWeight(5);
    text(this.i[this.lineNum],width*0.5,height*0.98);
    noStroke();
    text(this.i[this.lineNum],width*0.5,height*0.98);
    pop();
  }
  
}





