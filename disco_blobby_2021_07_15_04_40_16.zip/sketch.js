//// Circle Lines
//// w/ low alpha and fades.
//// coded by Ed Cavett

let particle;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  particle = new particles();

}

function draw() {
  background(0,15);
  translate(width/2,height/2);
  particle.update();
  
  // if (frameCount%200 === 0){
  // textAlign(CENTER);
  // let t = textWidth('draw make & code');
  // push();
  // noStroke();
  // fill(0,25);
  // textSize(50);
  // text('draw make & code',-t-6,100);
  // fill(255,25);
  // textSize(50);
  // text('draw make & code',-t,100);
  // pop();
  // }
}


function particles(){
  this.x = [];
  this.y = [];
  // this.xoff = [];
  this.xoff = 0;
  this.yoff = [];
  this.size = [];
  for (let i = 0; i < 60; i++){
    this.x.push(0);
    this.y.push(0);
    // this.xoff.push(0);
    this.yoff.push(0);
    this.size.push(cos(i)*(sin(i)*100));
  }
 
  
  
  this.update = function(){
    strokeWeight(6);
    for (let i = 0; i < 60; i++) {
      this.xoff += 0.0005;
      let rnoise = map( noise(this.xoff*0.1),
                       0,1,-TWO_PI,TWO_PI);
      let snoise = map(noise(this.xoff),0,1,
                       1,this.size[i]*3);
      
      this.x[i] = sin(i);
      this.y[i] = cos(i);
      // let mx = map(noise(this.xoff),0,1,
      //              -width/2,width/2);
      // let my = map(noise(frameCount*0.01),0,1,
      //              -height/2,height/2);
      push();
      translate(this.x[i]*200,
                this.y[i]*200);
      rotate(-rnoise*i*0.1);
      // stroke(0);
      // strokeWeight(3);
      // point(0,0);
      
      let scr = map(noise(frameCount*0.01),0,1,
                   50,355);
      let scg = map(noise(frameCount*0.025),0,1,
                   50,355);
      let scb = map(noise(frameCount*0.05),0,1,
                   50,355);
      stroke(scr,scg,scb,2);
      // stroke(0,0,0,25);
      // line(0,0,0,height);
      // line(0,0,width,0);
      line(0,0,0,-height);
      line(0,0,0,height);
      // stroke(0,scg,0,255);
      line(0,0,-width,0);
      line(0,0,width,0);
      // stroke(scr,scg,scb,255);
      line(0,0,-width,-height);
      line(0,0,width,height);
      // stroke(0,0,scb,255);
      line(0,0,width,-height);
      line(0,0,-width,height);
      pop();
    }
  }
  
  
}













/// Click to Go Fullscreen /bottom click
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

