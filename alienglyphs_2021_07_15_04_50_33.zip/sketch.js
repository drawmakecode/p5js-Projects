//// Alien Glyphs
//// Character Set
//// Generator
//// by Ed Cavett

let pass = 0;
let aglyph;
let chrscale = 100;
let xpos = 0;
let ypos = 0;
let scolor = [255, 255, 255];
let xwave = 0;
let ywave = 0;
let xwparts = 11/7;
let ywparts = 11/7;

let coln = 0;
let altcol = 1;

function setup() {
  // createCanvas(5120,
  //   2880);
  createCanvas(windowWidth,
               windowHeight);
  rectMode(CORNER);
  strokeCap(SQUARE);
  aglyph = new parts(chrscale);
  xpos = 0;
  ypos = aglyph.size * 1.1;
  testset();

  background(75,0,25, 255);
}

function draw() {
  // background(0,255);
  frameRate(1);
  let size = aglyph.size;
  xpos += size * 1.1;
  if (xpos >= width - size) {
    ypos += size * 1.1;
    ywave += 0.25;
    ywparts += 0.1;
    xwave = 0;
    xwparts = 0;
    xpos = size * 1.1;
    if (ypos > height - size) {
      ypos = size * 1.1;
      if (pass < 4) {
        // saveCanvas('alienglyphsLRG_B' + pass, 'png');
      }
      pass += 1;
      altcol += 1;
      if (pass/2 == int(pass/2)){
  background(75,0,25, 255);
      }
    }
  }

  // perm.update();
  rndparts();
  col = coln;
  // col = random(75,255);
  scolor = [col, col - (col * 0.33), col - (col * 0.66)];
  // scolor = [random(255),
  //           random(255),
  //           random(255)];
  aglyph.show(xpos, ypos, altcol);
  // aglyph.show(width/2,height/2, altcol);
}

function rndparts() {

  for (let i = 0; i < aglyph.style.length; i++) {
    xwparts += 0.01
    rpart = floor(map(noise(xwparts, ywparts), 0, 1,
      0, 19));
    aglyph.style[i] = true;
    if (random(1) < 0.5){
      aglyph.style[i] = false;
    }
  }
}


 

// function keyPressed(){
//   if (keyCode === DOWN_ARROW) {
//     // console.log('save letter'+whichone);
//     saveCanvas('alienglyphsLRG'+whichone, 'png');
//   }

// }


/// Click to Go Fullscreen /bottom click
function mousePressed() {
  if (mouseX > 0 &&
    mouseX < width &&
    mouseY > height / 2 &&
    mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}


function parts(size) {
  this.size = size;
  this.unit = 4;
  this.units = this.size / this.unit;
  this.wh = this.size / 2;
  this.style = [];
  this.fillon = [];

  for (let i = 0; i < 20; i++) {
    this.style[i] = false;
    this.fillon[i] = true;
  }
  this.fillon[20] = true;

  this.show = function(_x, _y,altcol) {
      // scolor[0] = coln * 0.33 + 50;
      // scolor[1] = coln * 0.66 + 50;
      // scolor[2] = coln + 50;
     
      scolor[0] = noise(ywave*0.5, xwave*0.5) * 255;
      scolor[1] = noise(ywave*0.05, xwave*0.05) * 255;
      scolor[2] = 0;

    if (altcol/2 === int(altcol/2)){
      scolor[0] = noise(ywave*0.5, xwave*0.5) * 255;
      scolor[1] = noise(ywave*0.05, xwave*0.05) * 255;
      scolor[2] = 0;
  } else {
      scolor[0] = 255-noise(ywave*0.5, xwave*0.5) * 255;
      scolor[1] = 255-noise(ywave*0.05, xwave*0.05) * 255;
      scolor[2] = 0;
  }

    push();
    stroke(scolor, 255);
    strokeWeight(this.size * 0.05);
      translate(_x, _y);
    push(); /// erase old figure
    this.fillit(20);
    fill(scolor,
      scolor);
    stroke(scolor,
      255);
      push();
      fill(125-noise(ywave*0.5, xwave*0.5) * 255,
           75-noise(ywave*0.25, xwave*0.05) * 255,
           noise(ywave*0.25, xwave*0.05) * 100,
           125);
    fill(25,75);
    rect(-this.wh, -this.wh, this.size, this.size);
      pop();
    pop();
  
  
    if (this.style[0]) { /// top horizontal line
      push();
      translate(0, -this.wh);
      this.fillit(0);
        line(-this.wh, 0,
          this.wh, 0);
      pop();
    }

    if (this.style[1]) { /// bottom horizontal line
      push();
      translate(0, this.wh);
      this.fillit(1);
        line(-this.wh, 0,
          this.wh, 0);
       pop();
    }

    if (this.style[2]) { /// left vertical line
      push();
      translate(-this.wh, 0);
      this.fillit(2);
        line(0, -this.wh,
          0, this.wh);
      pop();
    }

    if (this.style[3]) { /// right vertical line
      push();
      translate(this.wh, 0);
      this.fillit(3);
        line(0, -this.wh,
          0, this.wh);
        pop();
    }
    
    if (this.style[4]) { /// left top outside box
      push();
      strokeWeight(1);
      this.fillit(4);
      translate(-this.wh, -this.wh);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
               this.units*0.75);
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }

    if (this.style[5]) { /// right top outside box
      push();
      this.fillit(5);
      translate(this.units, -this.wh);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
               this.units*0.75);
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }

    if (this.style[6]) { /// left bottom outside box
      push();
      this.fillit(6);
      translate(-this.wh, this.units);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
               this.units*0.75);
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }

    if (this.style[7]) { /// right bottom outside box
      push();
      this.fillit(7);
      translate(this.units, this.units);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
               this.units*0.75);
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }

    if (this.style[8]) { /// left top inside box
      push();
      this.fillit(8);
      translate(-this.units, -this.units);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
               this.units*0.9);
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }
    
    if (this.style[9]) { /// right top inside box
      push();
      this.fillit(9);
      translate(0, -this.units);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
               this.units*0.9);
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }
    
    if (this.style[10]) { /// left bottom inside box
      push();
      this.fillit(10);
      translate(-this.units, 0);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
               this.units)*0.9;
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }
    
    if (this.style[11]) { /// right bottom inside box
      push();
      this.fillit(11);
      translate(0, 0);
      if (random(1) < 0.5) {
        circle(this.units*0.5, this.units*0.5,
        this.units*0.9);
      } else {
        rect(0, 0,
          this.units);
      }
      pop();
    }

    if (this.style[12]) { /// back diagonal
      push();
      translate(0, 0);
      this.fillit(12);
      line(-this.wh, -this.wh,
        this.wh, this.wh);
      pop();
    }

    if (this.style[13]) { /// forward diagonal
      push();
      translate(0, 0);
      this.fillit(13);
      line(-this.wh, this.wh,
        this.wh, -this.wh);
      pop();
    }

    if (this.style[14]) { /// center box 
      push();
      this.fillit(14);
      translate(0, 0);
      if (random(1) < 0.5) {
        circle(-this.units * 0.5, -this.units * 0.5,
          this.units);
      } else {
        rect(-this.units * 0.5, -this.units * 0.5,
          this.units);
      }
      pop();
    }
    
    if (this.style[15]) { /// big circle
      push();
      noFill();
      translate(0, 0);
      ellipse(0, 0,
        this.size);
      pop();
    }

    if (this.style[16]) { /// top triangle
      push();
      this.fillit(16);
      translate(0, -this.wh);
      triangle(0, 0,
        -this.units, this.units,
        this.units, this.units);
      pop();
    }

    if (this.style[17]) { /// bottom triangle
      push();
      this.fillit(17);
      translate(0, this.wh);
      triangle(0, 0,
        -this.units, -this.units,
        this.units, -this.units);
      pop();
    }
    
    if (this.style[18]) { /// left triangle
      push();
      this.fillit(18);
      translate(-this.wh, 0);
      triangle(0, 0,
        this.units, -this.units,
        this.units, this.units);
      pop();
    }
    
    if (this.style[19]) { /// right triangle
      push();
      this.fillit(19);
      translate(this.wh, 0);
      triangle(0, 0,
        -this.units, -this.units,
        -this.units, this.units);
      pop();
    }


    pop();

  }
this.fillit = function(fo) {
  xwave += 0.025;
  coln = map(noise(xwave*033, ywave*0.33), 0, 1, 0, 255);
  stroke(scolor, 255);
  noFill();
  if (this.fillon[fo]) {
    stroke(0,255);
    strokeWeight(aglyph.size*0.05);
    fill(scolor, 255);
  }

}

}




function testset() {
  for (let i = 0; i < aglyph.style.length; i++) {
    aglyph.style[19] = true;
  }

  aglyph.show(width / 2, height / 2);
}













//// end of sketch