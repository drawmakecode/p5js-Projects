let flies = []; /// fireflies method 
let population = 10;

let grassy; /// grass - yard method
let rot = 0;


function setup() {
  createCanvas(windowWidth,
               windowHeight);
  for (let i = 0; i < population; i++) {
    flies.push(new firefly());
  }
  grass = new yard();
}


function draw() {
  background(0,5,15,255);
  for (let i = 0; i < flies.length; i++) {
    flies[i].update();
  }
  // grass.update();
}

/// Click to Go Fullscreen
function mousePressed() {
  if (mouseX > 0 &&
    mouseX < width &&
    mouseY > height / 2 &&
    mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}



function firefly() {
  this.x = 0;
  this.y = 0;
  this.xoff = random(100);
  this.yoff = random(100);
  this.wave = random(5);
  this.rate = random(0.05,0.1);
  this.roff = random(2);
  this.rise = height*0.2;
  this.risepol = 1;
  this.toff = random(25);
  
  this.update = function(){
    this.xoff += 0.0025;
    this.yoff += 0.0025;
    
    let w = width*0.25;
    
    this.rise += this.risepol;
    if (this.rise < height*0.1 ||
        this.rise > height*0.7) {
      this.risepol *= -1;   
    }
    
    this.x = map(noise(this.xoff),0,1,
                 -w,width+w);
    this.y = map(noise(this.yoff),0,1,
                 this.rise,height);
    
    /// flashing
    this.wave += this.rate;
    let flash = abs(sin(this.wave)*255);
    let falpha = map(flash,0,255,50,155);
    stroke(flash*0.5,flash*0.5-20,0,falpha);
    /// display
    push();
    translate(this.x,this.y);
    
    /// turn wings
    this.toff += 0.1;
    let twing = map(noise(this.toff),0,1,-PI*0.5,PI*0.5);
    rotate(twing);
    
    /// wings
    this.roff += 2;
    let r = map(sin(this.roff),-1,1,-PI*0.25,PI*0.25);
    strokeWeight(2);
    let winglen = 12;
    push(); /// right wing
    stroke(255,200,0,125);
    rotate(r);
    line(0,0,-winglen,0);
    pop();
    
    push(); /// left wing
    stroke(255,200,0,125);
    rotate(-r);
    line(0,0,winglen,0);
    pop();
    
    let size = map(flash,0,255,10,25);
    strokeWeight(size);
    point(0,0); /// halo
    
    strokeWeight(size*0.25);
    stroke(255,255,0,255);
    point(0,0); /// light source
    pop();
    
  }
}

function yard() {
  this.grass = [];
  this.roff = [];
  this.rwave = [];
  this.size = [];
  this.seg = [];
  this.index = 0;
  this.population = 150;

   for (let i = 0; i < width; i+= width/this.population){
    this.index += 1;
    this.grass.push(i);
    this.roff.push((this.index*0.085)+0.015);
    this.rwave.push(0);
    this.size.push(random(35,55));
    this.seg.push(0.75);
  }
 
  
  
  this.update = function(){
    for (let i = 0; i < this.index; i++){  // draw many blades
  
    // draw one blade of grass
    let len = this.size[i];
    push();
    translate(this.grass[i],height);
    this.blade(len,i);
    pop();
  }
  }
  
  this.blade = function(len,ind){
  this.roff[ind] += 0.005;
    if (ind/2 === int(ind/2)){
  // stroke(len*2.5,255-(len*2.5),10,255);
  stroke(125-(len*2.5),len*2.5,10,255);
      rot = map( noise(this.roff[ind]),0,1,
    -QUARTER_PI*0.75,QUARTER_PI*0.75 );
    }
    if (ind/2 != int(ind/2)){
      // stroke(len*2.5,255-(len*2.5),10,255);
      stroke(125-(len*2.5),len*2.5,10,255);
      rot = map( -sin(this.roff[ind]),-1,1,
                -QUARTER_PI*0.25,QUARTER_PI*0.25 );
    }
    
  // let rot = map( noise(this.roff[ind]),0,1,
  //   -QUARTER_PI*0.25,QUARTER_PI*0.25 );
  
  strokeWeight(len*2*random(0.07,0.11));
  rotate(rot);
  line(0,0,0,-len);
  translate(0,-len);
  if (len > 20) {
    this.blade(len*this.seg[ind],ind);
  }
}
  
}












/// end of sketch