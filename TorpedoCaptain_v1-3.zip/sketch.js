/// Torpedo Pilot
/// version 1.3 - Dec/16/2025
/// Destroy enemy ships with torpedos.
/// Misses take away from torpedos.
/// Run out of torpedos and game ends.
/// Too many ship escapes and game ends.
/// Ship can detect torpedo and will try to evade.
/// Avoid hitting passenger ships.
/// Hit a passenger ship and the game ends.
/// Use LEFT and RIGHT arrow to move torpedo.
/// Use DOWN ARROW to fire torpedo.
/// Direct hits earn higher score.
/// Quick firing earns shot bonus.
/// Hit ship to recharge Shot Clock Bar on periscope.
/// Level Up to multiply bonuses.
/// 0 misses adds 100% Score as a Bonus.
/// 0 escapes adds 50% Score as a Bonus.
/// Designed and Coded by Ed Cavett
/// (c)2025

let ship;
let torpedo;
let targetScanSpeed;
let score;
let scoreDisplay;
let scoring = 0;
let sights;
let torpedoCount = 5;
let gameOver = 1;
let firstPlay = 1;
let shipsEscaped = 0;
let shipType;
let detected;

let shipsSunk;
let level;
let nextLevel;
let levelUp;
let levelDisplayCount;

let detectChance;

let img1; /// right-facing ship
let img2; /// left-facing ship
let img3; /// wrecked ship
let img4; /// title screen
let img5; /// passenger
let img6; /// battleship right facing
let img7; /// battleship left facing
let img8; /// cloud 1
let img9; /// torpedo title
let shipImg;
let friendly = [];

let sharpnel;
let frameAdjust;
let gamePaused;
let noMissesBonus;
let noEscapesBonus;
let shotClock;
let shotClockBonus;
let helpScreen;
let missesAdd = 0;
let escapesAdd = 0;
let cloudx = [];
let cloudy = [];
let torpTitleX;
let torpTitleY;
let torpRot;

function preload() {
  img1 = loadImage("battleShip1.png");
  img2 = loadImage("battleShip2.png");
  img3 = loadImage("battleShipWrecked1.png");
  img4 = loadImage("titleScreen.png");
  img5 = loadImage("passenger.png");
  img6 = loadImage("battleShip3.png");
  img7 = loadImage("battleShip4.png");
  img8 = loadImage("cloud2.png");
  img9 = loadImage("torpedoTitle.png");
}

async function setup() {
  createCanvas(1990, 1080);
  // createCanvas(windowWidth,windowHeight);
  rectMode(CENTER);
  imageMode(CENTER);
  textAlign(LEFT);
  textSize(50);
  frameRate(30);
  score = 0;
  scoring = 0;
  targetScanSpeed = 20;
  torpedoCount = 4;
  gameOver = 1;
  frameAdjust = 30;
  if (firstPlay === 0) {
    gameOver = 0;
  }
  if (firstPlay === 1) {
    firstPlay = 0;
  }
  shipImg = [];
  shipImg[0] = img1;
  shipImg[1] = img2;
  shipImg[2] = img6;
  shipImg[3] = img7;
  shipsEscaped = 0;
  detected = false;
  shipsSunk = 0;
  level = 1;
  levelUp = 0;
  nextLevel = 5;
  levelDisplayCount = 1;
  detectChance = 0.01;
  gamePaused = 0;
  noMissesBonus = 1;
  noEscapesBonus = 1;
  shotClock = 250 * level;
  shotClockBonus = 0;
  missesAdd = 0;
  escapesAdd = 0;
  cloudx[0] = random(width * 0.1, width * 0.9);
  cloudx[1] = random(width * 0.1, width * 0.9);
  cloudy[0] = random(height * 0.1, height * 0.2);
  cloudy[1] = random(height * 0.1, height * 0.2);
  torpTitleX = width / 2;
  torpTitleY = 0;
  torpRot = 0;
  shipType = pickShipType();
  helpScreen = new instruct();
  ship = new shipMaker(0);
  torpedo = new torpedoMaker();
  friendly[0] = new friendlyMaker(0);
  friendly[1] = new friendlyMaker(1);
  shrapnel = new shrapnelMaker();
  scoreDisplay = 0;
  scoreX = width * 0.5;
  sights = width * 0.05;
}

function draw() {
  if (gamePaused) {
    stopPlay();
  } else {
    generatrix();
  }
}

function generatrix() {
  shotClock -= 2 * level;
  cloudx[0] += 1;
  cloudx[1] += 1.5;
  if (cloudx[0] > width) {
    cloudx[0] = 0;
    cloudy[0] = random(height * 0.1, height * 0.2);
  }
  if (cloudx[1] > width) {
    cloudx[1] = random(height * 0.1, height * 0.2);
    cloudy[1] = random(height * 0.1, height * 0.2);
  }
  if (shotClock < 0) {
    shotClock = 0;
  }
  /// sky and water background
  if (gameOver === 0) {
    backMaker();
    torpedo.update();
    ship.update();
    if (level > 1) {
      friendly[0].update();
    }
    if (level > 2) {
      friendly[1].update();
    }
    playerMover();
    periscope();
    playerStats();
    if (torpedoCount < 1 && torpedo.alive == 0) {
      gameOver = 1;
    }
    if (levelUp === 1) {
      levelUpDisplay();
    }
  }
  if (gameOver === 1) {
    gameEnd();
  }
}

function gameEnd() {
  backMaker();
  ship.update();
  friendly[0].update();
  friendly[1].update();
  periscope();
  fill(abs(sin(frameCount * 0.1)) * 255, 255);
  textAlign(LEFT);
  textSize(50);
  text("Score", 50, 50);
  text("Level", 50, 160);
  textSize(abs(cos(frameCount * 0.05)) * 40 + 25);
  text(nfc(score), 50, 100);
  textSize(abs(cos(frameCount * 0.075)) * 40 + 25);
  text(level, 50, 210);
  textAlign(CENTER);
  textSize(75 - abs(sin(frameCount * 0.05) * 10));
  stroke(0, 255);
  text(
    "GAME OVER",
    ship.x,
    ship.y - abs(sin(frameCount * 0.05) * (height * 0.18))
  );
  fill(0, 128, 255, abs(cos(frameCount * 0.05)) * 255);
  noStroke();
  text(
    "GAME OVER",
    ship.x,
    ship.y - abs(sin(frameCount * 0.05) * (height * 0.18))
  );
  image(img4, width / 2, height * 0.45);
  torpTitleY += 5;
  if (torpTitleY > height * 0.36) {
    torpTitleY = height * 0.36 + 1;
    torpRot += PI * 0.1;
    if (torpRot > TAU*0.98) {
      torpRot = TAU*0.98 + 0.1;
      torpTitleX += 200;
      if (torpTitleX > width + img9.width) {
        torpTitleX = width / 2;
        torpTitleY = 0;
        torpRot = 0;
      }
    }
  }
  push();
  translate(torpTitleX, torpTitleY);
  rotate(torpRot);
  image(img9, 0, 0);
  pop();

  textSize(25);
  fill(190, 190, 255, 255);
  text(
    "TORPEDO PILOT Concept, Design and Coding Procedures © 2025 Ed Cavett",
    width / 2,
    height * 0.9
  );
  textSize(15);
  text(
    "Written in Processing 5 for JavaScript, a GNU by The Processing Foundation.  For more info: processingfoundation.org",
    width / 2,
    height * 0.93
  );
  helpScreen.show();
}

function stopPlay() {
  push();
  stroke(0, 255);
  strokeWeight(2);
  fill(255, 255, 0, sin(frameCount * 0.1) * 255);
  textSize(100);
  textAlign(CENTER);
  text("PAUSE", width * 0.49, height * 0.1);
  pop();
  image(img4, width / 2, height * 0.45);
  helpScreen.show();
}

function pickShipType() {
  let pick = floor(random(0, 4));
  return pick;
}

function backMaker() {
  background(64, 128, 255, 255);
  fill(0, 200, 255, 255);
  rect(width / 2, ship.y * 0.4 + 5, width, height * 0.3);
  strokeWeight(1);
  stroke(255, 255);
  line(0, ship.y + 5, width, ship.y + 5);
  image(img8, cloudx[0], cloudy[0]);
  image(img8, cloudx[1], cloudy[1]);
}

function levelUpDisplay() {
  levelDisplayCount += 1;
  if (levelDisplayCount > 100) {
    levelUp = 0;
    levelDisplayCount = 1;
    score += missesAdd + escapesAdd;
    missesAdd = 0;
    escapesAdd = 0;
    noMissesBonus = 1;
    noEscapesBonus = 1;
    cloudx[0] = random(width * 0.1, width * 0.9);
    cloudy[0] = random(height * 0.1, height * 0.15);
    cloudx[1] = random(width * 0.1, width * 0.9);
    cloudy[1] = random(height * 0.1, height * 0.15);
  }
  if (noMissesBonus === 1) {
    missesAdd = score * level;
  }
  if (noEscapesBonus === 1) {
    escapesAdd = floor(score * level * 0.5);
  }
  push();
  textSize(floor(levelDisplayCount * 0.5));
  textAlign(CENTER);
  text("LEVEL UP", width / 2, height / 2);
  if (noMissesBonus === 1) {
    text("No Misses BONUS " + missesAdd, width / 2, height * 0.6);
  }
  if (noEscapesBonus === 1) {
    text("No Escapes BONUS " + escapesAdd, width / 2, height * 0.7);
  }
  pop();
}

function playerMover() {
  if (keyIsDown(DOWN_ARROW) === true && torpedo.alive === 0) {
    if (torpedoCount > 0) {
      torpedo.alive = 1;
      torpedoCount -= 1;
      shotClockBonus = floor(shotClock);
      score += floor(shotClockBonus);
    }
    if (random() < 0.25) {
      detected = true;
      ship.detectedSignal = true;
    }
  }

  if (keyIsDown(LEFT_ARROW) === true) {
    ship.aim -= targetScanSpeed;
    if (ship.aim < width * 0.05) {
      ship.aim = width * 0.05;
    }
  }
  if (keyIsDown(RIGHT_ARROW) === true) {
    ship.aim += targetScanSpeed;
    if (ship.aim > width * 0.95) {
      ship.aim = width * 0.95;
    }
  }
}

function periscope() {
  if (gameOver) {
    ship.aim = width * 0.5;
  }
  push();
  fill(0, 255);
  translate(ship.aim, height * 0.8);
  fill(90, 255);
  rect(0, sights, sights * 0.8, height * 0.25);
  textAlign(CENTER);
  textSize(20);
  noStroke();
  let clockBar = map(shotClock, 250 * level, sights, 25, height * 0.087);
  let barColor = map(shotClock, 250 * level, sights, 0, 255);
  fill(barColor, 255, 0, 255);
  rect(0, height * 0.05 + clockBar, sights * 0.6, 10);
  fill(90, 255);
  stroke(255, 255);
  circle(0, 0, sights * 1.25);
  strokeWeight(2);
  stroke(255, 128, 128, 255);
  fill(0, 0, 50, 255);
  circle(0, 0, sights);
  let sightMark = map(
    ship.x,
    ship.start,
    ship.end,
    -sights * 0.4,
    sights * 0.4
  );
  strokeWeight(15);
  stroke(255, 255);
  point(sightMark, 0);
  stroke(255, 128, 128, 255);
  strokeWeight(2);
  line(-sights * 0.25, 0, sights * 0.25, 0);
  line(-sights * 0.15, -sights * 0.25, sights * 0.15, -sights * 0.25);
  line(-sights * 0.15, sights * 0.25, sights * 0.15, sights * 0.25);
  line(0, -sights * 0.5, 0, sights * 0.5);
  pop();
}

function playerStats() {
  stroke(0, 255);
  fill(255, 255);
  textAlign(LEFT);
  text("Score", 50, 50);
  text(nfc(score), 50, 100);
  text("Level", 50, 160);
  text(level, 50, 210);
  if (torpedo.alive) {
    text(shotClockBonus, 50, height - 50);
    text("Shot Bonus", 50, height - 100);
  }
  textAlign(RIGHT);
  text("Torpedos", width - 50, 50);
  text(torpedoCount, width - 50, 100);
  text("Ships Sunk", width - 50, height * 0.9);
  text(shipsSunk + " of " + nextLevel, width - 50, height * 0.9 + 50);
  if (shipsEscaped == 3) {
    fill(abs(sin(frameCount * 0.1)) * 255, 0, 0, 255);
  }
  text("Escapes", width - 50, 160);
  text(shipsEscaped, width - 50, 210);
}

function shipMaker() {
  this.bottomSpeed = 1;
  this.topSpeed = 4;
  this.speed = floor(random(this.bottomSpeed, this.topSpeed));
  this.size = shipImg[shipType].width;
  this.sizeY = shipImg[shipType].height;
  this.start = -this.size * 1.25;
  this.end = width + this.size * 1.25;
  this.x = this.end;
  this.y = height * 0.25;
  this.aim = width * 0.5;
  this.direction = false;
  this.detectedSignal = false;

  this.update = function () {
    /// move in chosen direction
    if (this.direction === true) {
      this.x += this.speed + shipType * 2;
    } else {
      this.x -= this.speed + shipType * 2;
    }
    /// check detected torpedo - Evasive Action (alter speed)
    if (detected && torpedo.y < ship.y + ship.size * 0.5) {
      detected = false;
      if (random() < 0.5) {
        this.speed = floor(
          random(this.bottomSpeed + (shipType + 1) * 1.5, this.topSpeed)
        );
      } else {
        this.speed = floor(
          random(this.bottomSpeed + (shipType + 1) * 1.5, this.topSpeed)
        );
      }
      if (random() > 0.5 && shipType < 2) {
        if (this.direction === true) {
          this.direction = false;
          this.speed = floor(random(this.bottomSpeed, this.topSpeed));
        } else {
          this.direction = true;
          this.speed = floor(random(this.bottomSpeed, this.topSpeed));
        }
      }
    }

    /// check LEFT out of Bounds
    if (this.x < this.start) {
      this.speed = floor(random(this.bottomSpeed, this.topSpeed));
      shipType = pickShipType();
      shipsEscaped += 1;
      noEscapesBonus = 0;
      if (shipsEscaped > 3) {
        shipsEscaped = 3;
        gameOver = 1;
      }
      let pickDir = random();
      if (pickDir < 0.5) {
        this.x = this.start;
        this.direction = true;
      } else {
        this.x = this.end;
        this.direction = false;
      }
    }
    /// check RIGHT Out of Bounds
    if (this.x > this.end) {
      this.speed = floor(random(this.bottomSpeed, this.topSpeed));
      shipType = pickShipType();
      shipsEscaped += 1;
      noEscapesBonus = 0;
      if (shipsEscaped > 3) {
        this.detectedSignal = false;
        shipsEscaped = 3;
        gameOver = 1;
      }
      let pickDir = random();
      if (pickDir < 0.5) {
        this.x = this.start;
        this.direction = true;
      } else {
        this.x = this.end;
        this.direction = false;
      }
    }

    push();
    translate(this.x, this.y);
    stroke(125, 150, 255, noise(frameCount * 0.1) * 255);
    strokeWeight(floor(random(3, 5)));
    if (ship.direction === true) {
      scale(1, 1);
      image(shipImg[shipType], 0, -ship.sizeY * 0.2, ship.size, ship.sizeY);
      line(ship.size * 0.45, ship.sizeY * 0.28, -ship.size, ship.sizeY * 0.28);
    } else {
      scale(-1, 1);
      image(shipImg[shipType], 0, -ship.sizeY * 0.2, ship.size, ship.sizeY);
      line(-ship.size, ship.sizeY * 0.28, ship.size * 0.45, ship.sizeY * 0.28);
    }
    if (this.detectedSignal && torpedo.y < ship.y + ship.size) {
      fill(255, 75, sin(frameCount * 0.1) * 75, 255);
      text("!", 0, -ship.size * 0.25);
    }
    pop();
  };
}

function shrapnelMaker() {
  this.quant = 50;
  this.pos = [];
  this.vel = [];
  this.gravity = createVector(0, 0.25);
  for (let n = 0; n < this.quant; n++) {
    let shrapPos = p5.Vector.random2D;
    this.pos[n] = createVector(2 * shrapPos.x, 2 * shrapPos.y);
    this.vel[n] = createVector(random(-3, 3), random(-2, -10));
  }

  this.update = function () {
    for (let n = 0; n < this.quant; n++) {
      this.vel[n].add(this.gravity);
      this.pos[n].add(this.vel[n]);
      push();
      strokeWeight(random(3, 8));
      let c1 = noise(frameCount * 0.1) * 255;
      let fadeShrap = map(torpedo.explodeRad, 0, ship.size * 1.5, 255, 0);
      stroke(c1, c1, 255, fadeShrap);
      if (this.pos[n].y < 15) {
        point(this.pos[n].x, this.pos[n].y);
      }
      pop();
    }
  };

  this.reset = function () {
    this.pos = [];
    this.vel = [];
    for (let n = 0; n < this.quant; n++) {
      let shrapPos = p5.Vector.random2D;
      this.pos[n] = createVector(2 * shrapPos.x, 2 * shrapPos.y);
      this.vel[n] = createVector(random(-3, 3), random(-2, -10));
    }
  };
}

function torpedoMaker() {
  this.x = width * 0.5;
  this.y = height * 1.1;
  this.speed = 0.02;
  this.alive = 0;
  this.explode = 0;
  this.explodeRad = 1;
  this.explodeX = 0;

  this.update = function () {
    this.speed = level * 0.02;
    if (this.speed > 0.06) {
      this.speed = 0.06;
    }
    if (this.alive) {
      // torpedo is moving
      shotClock = 0;
      this.y = lerp(this.y, ship.y - ship.size * 0.25, this.speed);
      this.x = lerp(this.x, ship.aim, this.speed);
      if (this.y < ship.y + ship.y * 0.05) {
        this.explodeX = ship.x;
        // has torpedo reached the ship?
        this.alive = 0; // stop topedo moving
        this.y = height * 1.1; // set the torpedo back to start position
        if (
          this.x > ship.x - ship.size * 0.5 &&
          this.x < ship.x + ship.size * 0.5
        ) {
          // did torpedo hit ship?

          if (torpedoCount > -1) {
            torpedoCount += 1;
          }

          /// YES - update scoring Hit Detected
          let scoreDist = ship.size * 0.5 - dist(this.x, 0, ship.x, 0);
          scoring = floor(map(scoreDist, 1, ship.size * 0.5, 5, 15)) * 25;
          this.x = ship.x;
          shipType = pickShipType();
          ship.detectedSignal = false;
          let pickDir = random();
          if (pickDir > 0.5) {
            ship.x = ship.start;
            ship.direction = true;
          } else {
            ship.x = ship.end;
            ship.direction = false;
          }
          this.explode = 1;
          shotClock = 250 * level;
          ship.speed = floor(random(3, 8));
          scoreDisplay = 1;
        } else {
          if (levelUp != 1) {
            noMissesBonus = 0;
          }
        }
      }

      push();
      noFill();
      stroke(128, 0, 0, 128);
      strokeWeight(3);
      line(this.x - 25, ship.y, this.x + 25, ship.y);
      line(this.x, ship.y - 25, this.x, ship.y + 25);
      circle(this.x, ship.y, 45);
      translate(this.x, this.y);
      noStroke();
      let flicker = random(255);
      fill(flicker, flicker, 255, 255);
      let size = map(this.y, height, ship.y, 50, 3);
      circle(0, 0, size);
      pop();
    }

    if (this.explode) {
      this.explodeRad += 5;
      if (this.explodeRad > ship.size * 1.5) {
        this.explodeRad = 1;
        this.explode = 0;
        shipsSunk += 1;
        score += floor(scoring) * level;
        if (shipsSunk > nextLevel) {
          nextLevel += 5;
          shipsSunk = 0;
          level += 1;
          levelUp = 1;
          torpedoCount += 1;
          shipsEscaped -= 1;
          if (shipsEscaped < 0) {
            shipsEscaped = 0;
          }
          if (level > 2) {
            ship.bottomSpeed += 1;
            ship.topSpeed += 1;
          }
        }
        shrapnel.reset();
      }
      /// animate scoring
      if (scoreDisplay) {
        push();
        let xDisplay = map(this.explodeRad, 0, ship.size * 1.5, this.x, 150);
        let yDisplay = map(this.explodeRad, 0, ship.size * 1.5, ship.y, 150);
        if (this.explodeRad > 10) {
          translate(xDisplay, yDisplay);
          fill(0, 255);
          textAlign(CENTER);
          textSize(50);
          stroke(0, 255);
          strokeWeight(3);
          fill(255, 255);
          let hitScoreSize = map(xDisplay, this.x, 100, 15, 50);
          textSize(hitScoreSize);
          text(scoring * level, 0, 0);
          pop();
        }
      }

      push();
      translate(this.explodeX, ship.y);
      push();
      rotate(sin(noise(frameCount * 0.1)) * HALF_PI * 0.1);
      let sinkWrecked = map(
        this.explodeRad,
        0,
        ship.size * 1.5,
        0,
        img3.height * 0.8
      );
      if (this.explodeRad > 1) {
        image(img3, 0, sinkWrecked + 5);
      }
      pop();
      noStroke();
      fill(64, 128, 255, 255);
      rect(0, img3.height * 1.1, img3.width * 1.1, img3.height * 1.3);
      shrapnel.update();
      pop();
    }
  };
}

function friendlyMaker(n) {
  this.topSpeed = 15;
  this.bottomSpeed = 3;
  this.speed = floor(random(this.bottomSpeed, this.topSpeed));
  this.size = img5.width;
  this.sizeY = img5.height;
  this.start = -this.size * 1.25;
  this.end = width + this.size * 1.25;
  this.x = this.end;
  this.y = height * 0.4 + n * 100;
  this.aim = width * 0.5;
  this.direction = false;

  this.update = function () {
    if (this.direction === true) {
      this.x += this.speed;
    } else {
      this.x -= this.speed;
    }
    /// check LEFT out of Bounds
    if (this.x < this.start) {
      this.speed = floor(random(this.bottomSpeed, this.topSpeed));
      if (random() < 0.5) {
        this.x = this.start;
        this.direction = true;
      } else {
        this.x = this.end;
        this.direction = false;
      }
    }
    /// check RIGHT Out of Bounds
    if (this.x > this.end) {
      this.speed = floor(random(this.bottomSpeed, this.topSpeed));
      if (random() < 0.5) {
        this.x = this.start;
        this.direction = true;
      } else {
        this.x = this.end;
        this.direction = false;
      }
    }
    showImage = img5;
    push();
    translate(this.x, this.y);
    stroke(125, 150, 255, noise(frameCount * 0.1) * 255);
    strokeWeight(floor(random(3, 5)));
    if (this.direction === true) {
      scale(2, 2);
      image(showImage, 0, -this.sizeY * 0.2, this.size, this.sizeY);
      line(this.size * 0.45, this.sizeY * 0.28, -this.size, this.sizeY * 0.28);
    } else {
      scale(-2, 2);
      image(showImage, 0, -this.sizeY * 0.2, this.size, this.sizeY);
      line(-this.size, this.sizeY * 0.28, this.size * 0.45, this.sizeY * 0.28);
    }
    pop();

    /// is Torpedo hitting Passenger Ship?
    if (torpedo.alive) {
      if (torpedo.y > this.y - 10 && torpedo.y < this.y + 10) {
        if (
          torpedo.x > this.x - this.size * 0.8 &&
          torpedo.x < this.x + this.size * 0.8
        ) {
          gameOver = 1;
        }
      }
    }
  };
}

function keyPressed() {
  if (key === "r") {
    setup();
    loop();
  }
  if (key === "+") {
    frameAdjust += 5;
    if (frameAdjust > 60) {
      frameAdjust = 60;
    }
    frameRate(frameAdjust);
  }
  if (key === "=") {
    frameAdjust -= 5;
    if (frameAdjust < 5) {
      frameAdjust = 5;
    }
    frameRate(frameAdjust);
  }
  if (key === "p") {
    if (gamePaused) {
      gamePaused = 0;
    } else {
      if (!gameOver) {
        gamePaused = 1;
      }
    }
  }
  if (key === "q") {
    gameOver = 1;
  }
}

function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

function instruct() {
  this.msg = [];
  this.msg[0] = "-Destroy enemy ships with torpedos.";
  this.msg[1] = "-Misses take away from torpedos.";
  this.msg[2] = "-Run out of torpedos and game ends.";
  this.msg[3] = "-Too many ship-escapes and game ends.";
  this.msg[4] = "-Ship can detect torpedo and will try to evade.";
  this.msg[5] = "-Avoid hitting passenger ships.";
  this.msg[6] = "-Hit a passenger ship and the game ends.";
  this.msg[7] = "-Use LEFT and RIGHT arrow to move torpedo.";
  this.msg[8] = "-Use DOWN ARROW to fire torpedo.";
  this.msg[9] = "-Direct hits earn higher score.";
  this.msg[10] = "-Quick firing earns bonus.";
  this.msg[11] = "-Hit ship to recharge Shot Clock Bar.";
  this.msg[12] = "-Level Up to multiply points for each hit.";
  this.msg[13] = "-Level up with 0 misses or escapes for Bonus.";
  this.msg[14] = "-Press p to pause or r to reset/start game.";
  this.msg[15] = "-Adjust the frame rate with = or shft=.";
  this.msg[16] = "Designed and Coded by Ed Cavett © 2025";
  this.shipName = [];
  this.shipName[0] = "Slow and Evasive.";
  this.shipName[1] = "Faster and Evasive";
  this.shipName[2] = "Fast and Steady";
  this.shipName[3] = "Fastest and Steady";
  this.show = function () {
    push();
    fill(255, 98);
    stroke(64, 255);
    strokeWeight(10);
    rect(width * 0.87, height * 0.59, 450, height * 0.55);
    stroke(sin(frameCount * 0.05) * 128, 255);
    strokeWeight(7);
    noFill();
    rect(width * 0.87, height * 0.59, 450, height * 0.55);
    textAlign(CENTER);
    textSize(30);
    stroke(0, 255);
    strokeWeight(2);
    text("ENEMY WARSHIPS", width * 0.87, height * 0.37);
    noStroke();
    fill(255, 255);
    text("ENEMY WARSHIPS", width * 0.87, height * 0.37);
    pop();
    for (let n = 0; n < shipImg.length; n++) {
      push();
      translate(width * 0.87, height * 0.3 + height * 0.12 * (n + 1));
      image(shipImg[n], 0, 0);
      textAlign(CENTER);
      textSize(20);
      fill(0, 255);
      text(this.shipName[n], 0, 50);
      pop();
    }
    push();
    fill(0, 98);
    stroke(64, 255);
    strokeWeight(10);
    rect(255, height * 0.59, 450, height * 0.55);
    stroke(sin(frameCount * 0.05) * 128, 255);
    strokeWeight(7);
    noFill();
    rect(255, height * 0.59, 450, height * 0.55);
    textSize(32);
    textAlign(LEFT);
    stroke(0, 255);
    strokeWeight(2);
    fill(0, 255);
    text("HOW TO PLAY:", 50, height * 0.37);
    noStroke();
    fill(255, 255);
    text("HOW TO PLAY:", 50, height * 0.37);

    pop();
    for (let i = 0; i < this.msg.length; i++) {
      push();
      let fillSet = map(i, 0, this.msg.length, 128, 0);
      fillSet += sin(frameCount * 0.05) * 128;
      textSize(20);
      textAlign(LEFT);
      stroke(255 - fillSet, 255);
      strokeWeight(2);
      fill(0, 255);
      text(this.msg[i], 50, i * 30 + height * 0.4);
      textSize(20);
      fill(255, fillSet, 0, 255);
      noStroke();
      text(this.msg[i], 50, i * 30 + height * 0.4);
      pop();
    }
  };
}
