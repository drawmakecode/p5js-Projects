let ship;
let enemy;
let hiscores;

let asteroids = [];
let lasers = [];

let protect;
let letters;
let fromp = false; // let program know that a game is starting
let demoscreen;
let gamestart = 0;
let freesafe = 75; // 5secs of safe time b4 play 
let smallest = 20; // smallest asteroid size
let rockstostart = 2; // start game with this many asteroids
let roff = 0.001;
let roff2 = 0.005;
let level = 0;
let score = 0;
let maxscore = 0;
let gameover = true;
let shield = 300;
let rockvalue = 75;
let damage = 3;
let shellsfired = 0;
let instruct;
let flashr = 0;
let myfont;
let enemycount = 0;
let scoreshow = 0;
let starback;

let stars = [];
let speed = 8;
let acc = 0.075;
let maxtorpedos = 16;

function preload() {
  myfont = loadFont('asteroidfont.ttf');
}


function setup() {
  let cnv = createCanvas(windowWidth,windowHeight);
  //cnv.position(155,125);
  textFont(myfont);
  background(0);
 starback = new Starfield();
 starback.make();
  protect = new protection();
  ship = new Ship();
  demoscreen = new demo();
  instruct = new guide();
  instruct.guideassign();
  enemy = new EnemyShip();
  hiscore = new Scoreboard();  
  level = 1;
  for (let i = 0; i < 5; i++) {
  asteroids.push(new Asteroid());
  }
    for (let i = 0;
       i < 100;
       i ++) {
    stars.push(new Star());
  }
  speed = 25;
  
}

function draw() {
  background(0,0,0,255);
   ////stars print first
  push();
  translate(width/2,height/2);
  //starback.show();
  for (let i = 0;
       i < stars.length;
       i ++) {
    star = stars[i];
    star.update();
    star.show(); 
  }   
  pop();
  ///////////// end stars 

  
  
  if (asteroids.length <= 16 &&
     asteroids.length >= 8){
      enemy.attack = true;
      enemy.render();
      enemy.update();
      enemy.edges();
  } else {
    enemy.fadeup = 0;
    enemy.pos = createVector(random(100,width-100),
                             random(100,height-100));
    enemy.vel =   this.vel = p5.Vector.random2D();

    enemy.heading = random(360);
  }
      
  ///start shared setting -- new asteroid game/level
  if (asteroids.length === 0) {
    maxtorpedos -= 2;
    if (maxtorpedos < 1){
      maxtorpedos = 1;
    }
    enemy.attack = false;
    gamestart = frameCount;
    level += 1;
    maxscore += shield*(level*10);
    maxscore += shellsfired;
    //smallest = smallest + level;
    ship.pos.x = width/2;
    ship.pos.y = height/2;
    ship.vel.mult(0);
    for (let i = 0; i < rockstostart+level; i++) {
      asteroids.push(new Asteroid());
    }
  }
  
  //start split player one / demo game
  if (!gameover) {
     for (let i = asteroids.length-1; i >= 0; i--) {
       if (ship.hits(asteroids[i]) &&
         frameCount > gamestart+freesafe) {
         shield -= damage*level;
         protect.update();
       }
       asteroids[i].render();
       asteroids[i].update();
       asteroids[i].edges();
    }
    
    
    for (let i = lasers.length-1; i >=0 ; i--) {
    lasers[i].render();
    lasers[i].update();
      
      for (let j = asteroids.length-1; j >=0 ; j--){ 
        if (lasers[i].hits(asteroids[j])) {
          burst(asteroids[j].pos);
          if (asteroids[j].r > smallest) {
          var newAsteroids = asteroids[j].breakup();
          asteroids = asteroids.concat(newAsteroids);
          }
        rockvalue = map(asteroids[j].r,15,50,12,4);  
        score += (floor(rockvalue*level)*25);
        if (score > maxscore){
          maxscore = score;
        }
        burst(asteroids[j].pos);          
        asteroids.splice(j, 1);
        lasers.splice(i,1);
        break;
        }
      }
    } 
  
      if (lasers.length > 0){
          lasers[0].edges();
      }
    
  ship.render();
  ship.turn();
  ship.update();
  ship.edges();
  readout();
  } else if (scoreshow === 0) {
    hiscore.history();
    //demo();
    readout();

  } else if (scoreshow > 0) {  
    readout();
    demo();
    instruct.guideline();
  }
  
  
  if (fromp) {
        for (let i = asteroids.length;
        i >= 0; i--){
      asteroids.splice(i,1);
      fromp = false;
        }
  }
  
}

