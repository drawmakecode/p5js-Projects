function guide(){
  this.guidesize = 0;
  this.guideoff = 0;
  this.guide = [];
  this.whichone = 0;
  this.grow = 0;
  this.next = 0;
  
  this.guideassign = function(){
  this.guide[0] = "STAR TREK: ASTEROIDS - A FAN-GAME BY ED CAVETT";
  this.guide[1] = "ROMULANS HAVE ROBBED THE FERENGI OF DILITHIUM.";
  this.guide[2] = "RECOVER THE DILITHIUM ORE HIDDEN INSIDE ASTEROIDS.";
  this.guide[3] = "SHOOT THE ROLUMAN WARBIRDS & DESTROY THE ASTEROIDS.";
  this.guide[4] = "USE FRESHLY MINED DILITHIUM TO RESTORE SHIELDS.";  
  this.guide[5] = "ROMULANS WILL STEAL BACK THE ORE WHEN SHIELDS ARE DOWN.";
  this.guide[6] = "CAPTAIN SCORES DURING HIGHEST DILITHIUM STORAGE.";
  this.guide[7] = "CAPTAIN EARNS LATINUM BONUS BY FIRING PHOTON TORPEDO.";
  this.guide[8] = "GAIN LATINUM BONUS BY CLEARING THE SECTOR OF ASTEROIDS.";
  this.guide[9] = "BEWARE: ROMULANS HAVE ADDED PROPULSION TO ASTEROIDS.";
  this.guide[10] = "GENERATE A FEED-BACK PULSE BY SHOOTING THE ROLUMAN SHIP.";
  this.guide[11] = "THE PULSE CAUSES THE ASTEROID-PROPULSION TO SELF-DESTRUCT."
  this.guide[12] = "ROMULAN WARBIRD-PHASERS WILL DRAIN YOUR SHIELDS.";
  this.guide[13] = "USE UP-ARROW TO ENGAGE FORWARD IMPULSE ENGINES.";
  this.guide[14] = "USE LEFT AND RIGHT ARROW TO ENGAGE YAW THRUSTERS.";
  this.guide[15] = "PRESS SPACEBAR TO READY & FIRE PHOTON TORPEDOS.";
  this.guide[16] = "TOO MANY STRAY TORPEDOS WILL CAUSE A SAFETY-LOCKOUT.";
  this.guide[17] = "WARNING: DISTANT ASTEROIDS ARE HIDDEN FROM SENSORS.";
  this.guide[18] = "STAR TREK: ASTEROIDS - A FAN-GAME BY ED CAVETT";
  this.guide[19] = "STAR TREK: ORIGINAL SERIES (C) VIACOM CBS 1966-2021";
  this.guide[20] = "ATARI ASTEROIDS (C) ATARI 1979-2021";
  this.guide[21] = "INSERT COIN TO ENGAGE AND BEGIN YOUR TREK.";
  this.guide[22] = "OR PRESS P.";
  }
  
  this.guideline = function(){
  push();
    this.grow += 1.5;
    if (this.grow > 125) {
      this.next += 1;
      this.grow = 0;
      if (this.next > this.guide.length-1){
        this.next = 0;
        scoreshow = 0;
      }
    }
    translate(width/2,(height-50)-(this.grow));
    fill(255,255,255,this.grow*2);
    stroke(255,255,255,this.grow*2);
    strokeWeight(1);
    textAlign(CENTER,CENTER);
    textSize(this.grow*0.25);
    text(this.guide[this.next],0,0);
  pop();
  }
  
}