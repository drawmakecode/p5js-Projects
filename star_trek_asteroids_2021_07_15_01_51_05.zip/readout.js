function readout(){
  push();
  noFill();
  stroke(0,175,255,255);
  strokeWeight(1);
  textSize(25);
  textAlign(CENTER,CENTER);
  flashr += 0.075;
  this.flasher = sin(flashr)*255;
  stroke(255-this.flasher,100,this.flasher,255);
  text('START TREK: ASTEROIDS',width/2,15);
  stroke(0,175,255,255);
  if (frameCount < gamestart+freesafe) {
  stroke(255-flasher,100,this.flasher,255);
    text('RED ALERT',width/2,
         height/2-25);
    stroke(0,175,255,255);
    text('TARGET ENEMY ASTEROIDS',width/2,
        height/2+25);
    text('& FIRE AT WILL',width/2,
        height/2+50);

    circle(width/2,height/2,
           (freesafe-(frameCount-gamestart))*2);
  }
  
  noFill();
  if (shield < 100) {
  stroke(255-this.flasher,100,this.flasher,255);
  }
  let m = map(shield,0,300,0,255);
  rect(width/2-150,40,
      300,21,8);
  textSize(20);
  if (shield > 0){
  fill(255-m,m,0, 255);
  rect(width/2-(shield/2),40,
       shield,21,8);
  fill(0,0,0,255-shield);
  text('SHIELD STRENGTH: '+floor(shield/3)+'%',width/2,
      48);
  } else {
  shield = 0;
  fill(255);
  text('POWER FAILURE',width/2,
      48);
    score -= 25*level;
    if (score <= 0) {
      score = 0;
      if (!gameover) {
        gamestart = frameCount;
        level = 0;
        smallest = 10;
        ship.pos.x = width/2;
        ship.pos.y = height/2;
        
        for (let i = asteroids.length-1;
            i >= 0; i--){
          asteroids.splice(i,1);          
        }
      }
      gameover = true;
    }
  }
  fill(0,0,0,255);
  noFill();
  strokeWeight(4);
  rect(0,0,width,height,20);
  strokeWeight(2);
  textAlign(LEFT,TOP);
  text('SECTOR',10,5);
  text('ASTEROIDS',
       10,30);
  text('LATINUM BONUS',15,height-50);
  text(shellsfired,15,height-30);
  textAlign(RIGHT,TOP);
  text('DILITHIUM',width-10,5);
  text('TONS '+nfc(score, 0),width-10,30);
  text(level,155,5);
  text(asteroids.length,155,30);
  text('CAPTAIN SCORE',width-15,height-50);
  text(nfc(maxscore,0),width-15,height-30);
  textSize(15);
  textAlign(CENTER,CENTER);
  stroke(0,75,180,255);
  text('ATARI ATEROIDS (C) ATARI 1979-2021',width/2,height-30) 
  text('STAR TREK - ORIGINAL SERIES (C) VIACOM CBS 1966-2021',width/2,height-15) 
  textSize(15);
   this.lasersfired = floor(map(lasers.length,0,maxtorpedos,
                              255,1));
 text((maxtorpedos-lasers.length)+' ARMED TORPEDOS',
       width/2,
       height-75);
  rect(width/2-(255*0.5),
       height-60,
       255,15,4);

  fill(255-this.lasersfired,
      this.lasersfired,0,255);
  rect(width/2-(this.lasersfired*0.5),
       height-60,
       this.lasersfired,15,4);
  pop();
}