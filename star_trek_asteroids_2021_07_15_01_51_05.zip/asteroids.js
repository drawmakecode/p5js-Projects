function Asteroid(pos,r) {
  if (pos) {
    this.pos = pos.copy();
  } else {
  this.pos = createVector(random(width),
                         random(height));
  }
  
  if (r) {
    this.r = r*0.5;
  } else {
    this.r = random(40+level,50+level);
  }
  
  this.vel = p5.Vector.random2D();
  this.vel.mult(random(0.05,level*0.5));
  this.total = floor(random(7,15)); // # of sides
  this.offset = [];
  this.spin = 1;
  this.turn = random(-1,1)*random(2);
  for (let i = 0; i < this.total; i++){
    this.offset[i] = random(-this.r*0.3,
                            this.r*0.3);
    this.perlin = random(3);
    this.pnoise = 0;
    this.aheading = random(90);
  }
  this.movecheck = 0;
  this.movemark = 50;
  
  
  this.update = function() {
    this.pos.add(this.vel);
        this.vel.setMag(2);
  this.movecheck += 1;
    if (this.movecheck > this.movemark) {
      this.movemark = random(1,75);
      this.movecheck = 0;
    }
    this.perlin += level*0.0005;
    this.pnoise = floor(noise(this.perlin)*90);
    this.aheading = this.pnoise;
    let force = p5.Vector.fromAngle(this.aheading);
    this.vel.add(force);

  }
  
  this.render = function() {
    push();
    let d = dist(this.pos.x,this.pos.y,
                ship.pos.x,ship.pos.y);
    let m = map(d,0,width/2,255,0);
    let mm = map(m,255,0,4,1);
    fill(m-50,m,m-50,255);
    stroke(m,m,m,m);
    strokeWeight(mm);
    translate(this.pos.x,this.pos.y);
    this.spin += this.turn;
    rotate((this.spin*0.05)+PI);
    beginShape();
    for (let i = 0; i < this.total; i++){
      let angle = map(i,0,this.total,0, TWO_PI);
      let r = this.r + this.offset[i];
      let x = r * cos(angle);
      let y = r * sin(angle);
      vertex(x, y);
    }
    endShape(CLOSE);
    pop();
  }
  
    this.breakup = function() {
      let newA = [];
      newA[0] = new Asteroid(this.pos, this.r);
      newA[1] = new Asteroid(this.pos, this.r);
      burst(newA[0].pos);
      push();
      fill(255,200,0,255);
      noStroke();
      strokeWeight(1);
      for (let i = 0; i < 75; i++) {
        ellipse(this.pos.x,this.pos.y,i);
      }
      pop();
      return newA;
   }
  
    this.edges = function() {
    if (this.pos.x > width + this.r) {
      this.pos.x = -this.r;
    } else if (this.pos.x < -this.r) {
      this.pos.x = width + this.r;
    }
  
    if (this.pos.y > height + this.r) {
      this.pos.y = -this.r;
    } else if (this.pos.y < -this.r) {
      this.pos.y = height + this.r;
    }
  }
}

// generates asteroids explosion animation
function burst(pos) {
  push();
  fill(255,200,0,255);
  noStroke();
  strokeWeight(1);
    for (let k = 0; k < 50; k+=5) {
      ellipse(pos.x,pos.y,k);
    }
  pop();
 
}
