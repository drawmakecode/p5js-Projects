function EnemyShip(){
  this.pos = createVector(random(100,width-100),
                          random(100,height-100));
  this.vel = createVector(4+level,4+level);
  this.vel.mult(random(2,4));
  
  this.r = 15;
  this.attack = false;
  this.fadeup = 0;
  this.enemyturn = 0;
  this.heading = 0;
  
  this.update = function(){
  roff2 += 0.000075;
  this.enemyturn = noise(roff2)*360;
  this.heading = this.enemyturn;
  this.pos.add(this.vel);
  }

  this.edges = function() {
    if (this.pos.x < 0 ||
       this.pos.x > width ||
        this.pos.y < 0 ||
       this.pos.y > height){
      this.pos = createVector(random(100,width-100),
                             random(100,height-100));
      this.vel =   this.vel = p5.Vector.random2D();
      this.vel.mult(random(2,4));
      this.attack = false;
      enemycount = 0;
      this.heading = random(360);
      this.fadeup = 0;
   }
  }
  
  this.render = function(){
  this.fadeup += 2;
    if (this.fadeup > 255){
      this.fadeup = 255;
    }
  push();
  
    let fire = random(1);
    if (fire < 0.025 &&
         frameCount > gamestart+freesafe){
  strokeWeight(3);
  stroke(255,random(25,255),255,255);
  line(this.pos.x,
       this.pos.y,
      ship.pos.x,
      ship.pos.y);
      shield -= 3;
      protect.update();
    }
  translate(this.pos.x,this.pos.y);
  rotate(this.heading);
  stroke(0,75,0,this.fadeup);
  fill(0,125,0,this.fadeup);
  //noFill();
  strokeWeight(12);
  point(0,7);
  strokeWeight(5);
  line(0,0,0,-20);
  strokeWeight(4);
  triangle(-5,-35,
           5,-35,
           0,-5);
  arc(0, -13, 40, 29, QUARTER_PI*4, 0);
  line(-21,-11,
       -21,-20);
  line(21,-11,
       21,-20);
  strokeWeight(1);
  stroke(100,200,0,this.fadeup);
  point(-4,6);
  point(-2,7);
  point(2,7);
  point(4,6);
  strokeWeight(3);
  stroke(255,25,0,this.fadeup);
    point(20,-21);
    point(-20,-21);
  stroke(75,135,0,this.fadeup);
    point(20,-10);
    point(-20,-10);
  pop();
  }  
}