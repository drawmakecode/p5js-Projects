function keyReleased() {
   ship.setRotation(0);
   ship.boosting(false);
  
}

function keyPressed() {
  if (key == ' ' && frameCount > gamestart+150) {
  protect.update();
    for (let i = 0;
        i < 2; i++){
      if (lasers.length < maxtorpedos) {
    lasers.push(new Laser(ship.pos,ship.heading));    
    }
    }  
    }
  if (key == 'p' || key == 'P') {
    maxtorpedos = 16;
    gameover = false;
    gamestart = frameCount;
    ship.pos.x = width/2;
    ship.pos.y = height/2;
    shield = 300;
    shellsfired = 0;
    level = 0;
    fromp = true;
    instruct.upscreen = height+height/2;
    maxscore += shield*level;
    maxscore += shellsfired;

  }
  if (keyCode == RIGHT_ARROW) {
    ship.setRotation(0.075);
  } else if (keyCode == LEFT_ARROW) {
    ship.setRotation(-0.075);
  } else if (keyCode == UP_ARROW) {
    ship.boosting(true);
  }
 }

function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}