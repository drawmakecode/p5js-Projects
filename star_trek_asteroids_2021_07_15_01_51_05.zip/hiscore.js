function Scoreboard() {
  this.hiscore = [];
  this.hiname = [];
  this.fadeup = 0;
  this.duration = 0;
  
   this.hiscore[0] = 5611095;
    this.hiscore[1] = 5007020;
    this.hiscore[2] = 4721555;
    this.hiscore[3] = 4418175;
    this.hiscore[4] = 3854400;
    this.hiscore[5] = 2229985;
    this.hiscore[6] = 2043905;
    this.hiscore[7] = 1886300;
    this.hiscore[8] = 1519275;
    this.hiscore[9] = 1000200;
    this.hiname[0] = "ACE"
    this.hiname[1] = "JIL"
    this.hiname[2] = "JJJ"
    this.hiname[3] = "BLK"
    this.hiname[4] = "DOG"
    this.hiname[5] = "CAT"
    this.hiname[6] = "MNM"
    this.hiname[7] = "AAA"
    this.hiname[8] = "TOP"
    this.hiname[9] = "GOD"
  
    this.displaystartx = 30;
  
  this.history = function() {
    this.duration += 1;
    if (this.duration > 100) {
      this.duration = 0;
      scoreshow = 1;
      this.fadeup = 0;
    }
    this.fadeup += 5;
    starback.show();
    if (this.fadeup > 255) {
      this.fadeup = 255;
    }
    push();
    strokeWeight(5);
    stroke(0,125,255,this.fadeup);
    fill(0,0,255,25);
    rect(width/2-235,height/2-235,
        470,465,25);

    strokeWeight(4);
    textSize(35);
    textAlign(CENTER,CENTER);
    stroke(0,75,125,75);
    fill(0,255,255,155);
    text('TOP CAPTAINS',width/2,height/2-215);
    this.shadowy = height/2-175;
    for (let i = 0; i < 10; i++){
    // shadow color
    stroke(175,175,255,this.fadeup);
    fill(0,0,0,this.fadeup);
    strokeWeight(2);
    textAlign(LEFT,CENTER);
    text(this.hiname[i],width/2-120,i*40+this.shadowy+3);
    textAlign(RIGHT,CENTER);
      if (i === 9) {
    text('#'+(i+1),width/2-145,i*40+this.shadowy+3);
      } else {
        text('# '+(i+1),width/2-145,i*40+this.shadowy+3);
      }
    text(nfc(this.hiscore[i],0),width/2+210,
         i*40+this.shadowy);

      
    // top color
    stroke(0,0,255,this.fadeup);
    fill(0,0,0,this.fadeup);
    strokeWeight(1);
    textAlign(LEFT,CENTER);
    text(this.hiname[i],width/2-120,i*40+this.shadowy);
    textAlign(RIGHT,CENTER);
      if (i === 9) {
    text('#'+(i+1),width/2-145,i*40+this.shadowy);
      } else {
        text('# '+(i+1),width/2-145,i*40+this.shadowy);
      }
    text(nfc(this.hiscore[i],0),width/2+210,
         i*40+this.shadowy);
    }
      pop();
  
  }
}