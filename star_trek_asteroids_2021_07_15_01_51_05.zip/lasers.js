function Laser(spos,angle) {
  this.pos = createVector(spos.x+random(-15,15),
                          spos.y+random(-15,15));
  this.vel = p5.Vector.fromAngle(angle);
  this.vel.mult(10);
  score -= 25;
  shellsfired += 1;
  if (score < 0) {
    score = 0;
  }
  this.update = function() {
    this.pos.add(this.vel);
  }

  this.render = function() {
    push();
    let shotd = dist(ship.pos.x,
                    ship.pos.y,
                    this.pos.x,
                    this.pos.y);
    let shotm = map(shotd,0,width/2,255,1);
    stroke(200,shotm,0,shotm);
    strokeWeight(7);
    point(this.pos.x,this.pos.y);
    
    pop();
  }
  
  this.hits = function(asteroid){
    let d = dist(this.pos.x,
                 this.pos.y,
                 asteroid.pos.x,
                 asteroid.pos.y);
    let ed = dist(this.pos.x,
                 this.pos.y,
                 enemy.pos.x,
                 enemy.pos.y);
    let ed2 = dist(this.pos.x,
                 this.pos.y,
                 enemy.pos.x,
                 enemy.pos.y-15);

    if (ed < 25 && enemy.attack &&
       enemy.fadeup > 75) {
       push();
       translate(enemy.pos.x,
                enemy.pos.y)
      protect.update();
      
       // rotate(enemy.heading);
       // stroke(0,255,0,255);
       // fill(0,255,0,50);
       // strokeWeight(1);
       // ellipse(0,
       //        0,25,25);
       // ellipse(0,-25,25,25);

       pop();
      maxscore += 1000*level
    }
    if (d < asteroid.r ||
       ed < 25) {
        shield +=10;
        if (shield > 300) {
          shield = 300;
        }
        return true;

    } else {
        return false;
    }
  }
  
  this.edges = function(){
    this.alloff = 0;
    
    for (let i = 0; i < lasers.length; i++) {
      if (lasers[i].pos.x < 0 ||
          lasers[i].pos.x > width ||
          lasers[i].pos.y < 0 ||
          lasers[i].pos.y > height) {
        this.alloff += 1;
      }
    }
    
    if (this.alloff == lasers.length) {
      for (let i = lasers.length-1; i >= 0; i--) {
        lasers.splice(i,1);
      }
    }
  }
}