function demo() {
    for (let i = asteroids.length-1; i >= 0; i--) {
    if (ship.hits(asteroids[i]) &&
      frameCount > gamestart+150) {
      shield -= damage*level;
      protect.update();
    }
    asteroids[i].render();
    asteroids[i].update();
    asteroids[i].edges();
    }

  this.demoboost = random(1);
  if (this.demoboost < 0.01) {
    ship.boost(); 
  }
  if (frameCount > gamestart+150){
  this.demoshoot = random(1);
  }
  if (this.demoshoot < 0.07) {
  protect.update();
    for (let i = 0;
        i < 2; i++){
      if (lasers.length < maxtorpedos) {
    lasers.push(new Laser(ship.pos,ship.heading));    
    }
    }  }
  
  for (let i = lasers.length-1; i >=0 ; i--) {
    lasers[i].render();
    lasers[i].update();
    for (let j = asteroids.length-1; j >=0 ; j--){ 
      if (lasers[i].hits(asteroids[j])) {
        burst(asteroids[j].pos);
        if (asteroids[j].r > smallest) {
        var newAsteroids = asteroids[j].breakup();
        asteroids = asteroids.concat(newAsteroids);
        }
        rockvalue = map(asteroids[j].r,15,50,12,4);  
        score += (floor(rockvalue*level)*25);
        if (score > maxscore){
          maxscore = score;
        }
        push();
        fill(0,255,0,255);
        noStroke();
        strokeWeight(1);
          for (let k = 50; k >= 0; k--) {
            ellipse(asteroids[j].pos.x,asteroids[j].pos.y,k);
          }
        pop();
        burst(asteroids[j].pos);          
        asteroids.splice(j, 1);
        lasers.splice(i,1);
        break;
      }
    }
  }
  
  
  
  
  
  if (lasers.length > 0){
    lasers[0].edges();
  }

  
  
  roff += 0.000225;
  this.demoturn = noise(roff)*360;
  ship.heading = this.demoturn;

  
  ship.render();
  ship.turn();
  ship.update();
  ship.edges();

  readout();

    for (let i = asteroids.length-1; i >=0 ; i--) {
    //asteroids[i].render();
    asteroids[i].update();
    asteroids[i].edges();
  }
  //labelrocks();
  // enemy.render();
  // enemy.update();

}