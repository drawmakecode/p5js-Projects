function Ship() {
  this.pos = createVector(width/2,height/2);
  this.r = 15;
  this.heading = PI/2;
  this.rotation = 0;
  this.vel = createVector(0,0);
  this.isBoosting = false;
  
  this.boosting = function(b) {
   this.isBoosting = b;   
  }
    
  this.update = function() {
    if (this.isBoosting) {
      this.boost();
    }
    this.pos.add(this.vel);
    this.vel.mult(0.99);
  }
  
  this.boost = function() {
    let force = p5.Vector.fromAngle(this.heading);
    this.vel.add(force);  
    push();
    translate(this.pos.x,this.pos.y);
    rotate(this.heading+PI/2);
  //thruster animation
    stroke(0,175,255,255);
    strokeWeight(3);
    triangle(this.r/2-2,this.r+2,
             this.r/4-2,this.r+20,
            -this.r/2+2,this.r);

        // line(this.r/2,this.r,
        //     -this.r/2,this.r);
    pop();
    
  }
  
  this.render = function(){
            push();
        stroke(170,170,170,255);
        fill(100,100,100,255);
        translate(this.pos.x,
                 this.pos.y);
        rotate(this.heading+PI/2);
        strokeWeight(1);
        
        ellipse(0,0,this.r*2,this.r);
        strokeWeight(3);
        line(this.r/2,this.r,
            this.r/2,this.r+8);
        line(-this.r/2,this.r,
            -this.r/2,this.r+8);
        strokeWeight(5);
        line(0,this.r-15,
            0,this.r+5);
        stroke(255,100,100,255);
        point(-this.r/2,this.r+9);
        point(this.r/2,this.r+9);
        stroke(200,200,200,255);
        point(0,0);
        pop();

  
  }
  
    this.hits = function(pos) {
    this.hitpos = pos;
    
    let d = dist(this.pos.x,this.pos.y,
                this.hitpos.pos.x,
                 this.hitpos.pos.y);
    if (d < this.r + pos.r) {
      return true;
    } else {
      return false;
    }
  }

  
  this.edges = function() {
    if (this.pos.x > width + this.r) {
      this.pos.x = -this.r;
    } else if (this.pos.x < -this.r) {
      this.pos.x = width + this.r;
    }
  
    if (this.pos.y > height + this.r) {
      this.pos.y = -this.r;
    } else if (this.pos.y < -this.r) {
      this.pos.y = height + this.r;
    }
  }
  
  this.setRotation = function(a) {
    this.rotation = a;
  }
  
  this.turn = function(){
        this.heading += this.rotation;
  }
}


/// generates ship shields animation
function protection() {
  this.r = 0;
  this.rr = 5;
  
  this.update = function(){
    this.r += this.rr;
    if (this.r > 60 || this.r < 1){
      this.rr *= -1;
    }
    
    push();
    noFill();
    strokeWeight(5);
    let m = map(shield,0,300,25,255);
    stroke(255,m,255-m,m);
    translate(ship.pos.x,ship.pos.y);
    rotate(ship.heading);
    ellipse(0,0,this.r,60);
    ellipse(0,0,60,this.r);
    pop();
  }
} 
