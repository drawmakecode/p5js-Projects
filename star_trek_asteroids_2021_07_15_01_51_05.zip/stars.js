class Star {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.vx = 0;
    this.vy = 0;
    this.vz = 0;
    this.cfade = 1;
    this.rfade = 1;
    this.ox = 0;
    this.oy = 0;
    this.oz = 0;
    this.px = 0;
    this.py = 0;
    this.pick = 0;
    this.vxo = 0;
    this.vyo = 0;
    this.twave = 0;
    
  }
  
  make(){
    this.px = this.x;
    this.py = this.y;
    this.x = random(-width,width);
    this.y = random(-height,height);
    this.z = random(width);
    this.big = 1;
  }
  
  update() {
    
    this.oz = this.z;
    this.z = this.z - level*2;
    if (this.z < 1) {
    this.make();
    this.oz = 0;
    }
   this.vxo = this.vx;
   this.vyo = this.vy;
   this.vx = map(this.x/this.z,0,1,0,width);
   this.vy = map(this.y/this.z,0,1,0,height);
  }
  
  show() {
    this.cfade = map(speed,1,45,200,255);
    this.rfade = map(speed,1,45,125,255);
    this.ox = map(this.x/this.oz,0,1,0,width);
    this.oy = map(this.y/this.oz,0,1,0,height);

    // stroke(this.rfade,
    //        255-this.rfade,
    //        255-this.rfade,
    //        this.cfade);
    push();
    this.twave += 0.01;
    this.ts = sin(this.twave)*360;
    this.tc = cos(this.twave)*360;
    translate(width/4-this.ts,
              height/4-this.tc);
    stroke(255);
    strokeWeight((width-this.z)*0.0015);
    //rotate(speed*0.2);
    if (dist(this.vxo,this.vyo,
             this.vx,this.vy) < 75) {
    line (this.vxo,this.vyo,
          this.vx,this.vy);
      
    }
        pop();

    }
  }
class Starfield {
  constructor() {
    this.x = [];
    this.y = [];
    this.brite = [];
    this.bigness = [];
  }

  make(){
    for (let i = 0;
         i < 500;
         i++) {
      this.x[i] = random(-width,width);
      this.y[i] = random(-height,height);
      this.brite[i] = random(50,100);
      this.bigness[i] = random(1,3);
    }
  }

  show(){
    push();
    for (let i = 0;
         i < this.x.length;
         i++) {
      strokeWeight(this.bigness[i]);
      stroke(this.brite[i]);
      point(this.x[i],this.y[i]);
     }
    pop();
  }
  
}