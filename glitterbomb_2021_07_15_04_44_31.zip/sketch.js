/// Glitter Bombs
/// "reverse fireworks" Particle System
/// by Ed Cavett



let particles = [];
let population = 10;
let glitterpop = 25;
let glitter = 5;
let fader = 0;
let pg;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  for (let i = 0; i < population; i++){
    particles.push(new Particle(width/2,0,i));
  }
  fader = width/population;
  pg = createGraphics(width,height);
}


function draw() {
  background(0,255);
  pg.background(0,15);
  image(pg,0,0);
  stroke(100,75,50,255);
  strokeWeight(30);
  line(0,height,width,height);
  for (let i = 0; i < population; i++){
    particles[i].update(i);
  }
}


/// Click to Go Fullscreen 
/// click bottom half of canvas
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}


function Particle(xpos,ypos,i){
  this.index = i+1;
  this.pos = createVector(xpos,ypos);
  this.vel = createVector(0,0);
  this.acc = createVector(0,
                          random(0.05,0.075));
  this.burst = false;
  this.size = glitter*random(0.5,0.75);
  this.c = 0;
  this.c1 = 0;
  this.c2 = 0;
  
  /// confetti animation
  this.conwoff = random(-100);
  this.conhoff = random(-100);
  this.conroff = random(-100);
  this.glitsize = 0;
  this.glittime = 0;
  
  
  this.parts = [];
  this.vels = [];
  for (let i = 0; i < glitterpop; i++) {
    this.vels.push(p5.Vector.random2D());
    this.parts.push(createVector(0, 0));
  }

  
  this.update = function(i){
    if (this.burst) {
      for (let j = 0; j < this.parts.length; j++) {
       this.parts[j].add(this.vels[j]);
      }
    }

    
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    if (this.pos.y > height-20 && !this.burst) {
      this.pos.y = height-19;
      this.vel.mult(-random(0.25,0.75));
      this.burst = true;
      this.glittime = 0;
      for (let i = 0; i < particles.length; i++) {
        for (let j = 0; j < particles[i].parts.length; j++) {
          this.parts[j] = createVector(0, 0);
          this.vels[j] = p5.Vector.random2D();
          this.vels[j].mult(-random(2));
        }
      }
    }
    
    if (this.pos.y > height+height && this.burst) {
      this.pos = createVector(width/2-random(-10,10),0);
      this.vel = createVector(0,0);
      this.acc = createVector(0,
                          random(0.05,0.075));
      this.burst = false;
      for (let i = 0; i < particles.length; i++) {
        for (let j = 0; j < particles[i].parts.length; j++) {
          this.parts[j] = createVector(0, 0);
          this.vels[j] = p5.Vector.random2D();
        }
      }
    }    
    
    /// color modifiers
    this.c = map(i, 0, population - 1, 50, 255);
    this.c1 = map(i,0,population-1,255,50);
    this.c2 = map(fader, 0, width, 255, 255);
    push();
    pg.rectMode(CENTER);
    pg.push();
    translate(this.pos.x,this.pos.y);
    pg.translate(this.pos.x,this.pos.y);
    for (let i = 0; i < this.parts.length; i++){  
      if (this.burst){
        let glitcolor = map(i,0,glitterpop,75,255);
        pg.stroke(glitcolor, glitterpop+this.c1, this.c, this.c2);
        this.glittime += 1;
        this.glitsize = map(this.glittime,
                            0,2500,10,0);
        pg.strokeWeight(random(this.glitsize*0.25,
                               this.glitsize)+this.glitsize);
        this.conwoff += 1+i;
        this.conhoff += 1+i;
        this.conroff += 0.00+i;
        let widn = abs(noise(this.conwoff)*this.size);
        let hein = abs(noise(this.conhoff)*this.size);
        let rotn = abs(noise(this.conroff)*(TWO_PI*2));
        // pg.strokeWeight(hein);
        // pg.push();
        // pg.fill(this.c2,this.c1,this.c,this.c2);
        // pg.noStroke();
        // pg.translate(this.parts[i].x,
        //              this.parts[i].y);
        // pg.rotate(rotn);
        // pg.rect(0,0,widn*2,hein);
        // pg.pop();
        pg.point(this.parts[i].x,
              this.parts[i].y);
        if (this.glittime < 500) {
        }
      }
    }
    if (!this.burst){
      stroke(this.c2, this.c1, this.c, this.c2);
      strokeWeight(5);
      point(0,0);
    }
    pg.pop();
    pop();
  }
}


//// end of sketch