//// Altereffect 
//// Particle-Grid Stochastic
//// Long-form Generative System

//// by Ed Cavett
//// November 2021

////////////////
//// Generates a grid of geometies using stylistic
//// randomness.  The output can range from broken
//// windows in an industrial setting to cubist style
//// abstracts found in practical art.
//// The system moves through the grid locations
//// one-by-one.  As it does this, a random grid
//// location is selected and tested against the 
//// current location.  If they are close enough,
//// a vertex is plotted and other output is 
//// generated.  The ranges and thresholds for
//// movement and graphic attributes are varied 
//// through stochastic procedures and
//// stylistic randomness.
////////////////


/// Declare a variable to hold the particle-grid
/// object.
let thing;


function setup() {
  createCanvas(windowWidth,
               windowHeight);

  /// Assign to the particle-grid variable a 
  /// new instance of the particle-grid object.
  thing = new thingMaker();
  background(0,255);
}

/// Execute the update method of the particle-grid
/// object.
function draw() {
  // background(0,4);
  thing.update();
}


function thingMaker() {
  
  /// Control how the canvas is proportioned.
  let factor = 12;
  
  /// Creates a noise mover within the proportioned
  /// area.
  this.pos = [];
  this.vel = [];
  
  /// Define the range of the noise-mover area.
  this.scale = (height/factor)*0.5;
  
  /// Provide a means of moving through the
  /// elements of the array in an arbitrary or
  /// directed manner.
  this.index = -1;
  
  /// Declare and assign local variables to 
  /// find the column and row proportion.
  let col = width/factor;
  let row = height/(factor);
  
  /// Loop through the column and row proportions
  /// to get the "node" coordinates.  These will
  /// be the anchor location around which the
  /// noise mover for a given proportion will live.
  /// Arrange the loops to get verticle or horizontal
  /// output.
  
  /// Row-loop Col-loop = horizontal output
  /// Col-loop Row-loop = vertical output 
  for (let y = row/2;
       y < height-(row/2);
       y += row) {
    for (let x = col;
         x < width-(col);
         x += col) {
      
      /// Assign to the current open element
      /// in the arrays the node location from
      /// the loop variables.
      /// Give a random velocity seed to the
      /// velocity variable.
      this.pos.push(createVector(x,y));
      this.vel.push(random(1000));
    }
  } 
  
  /// This method calculates and generates output
  /// for the draw function.
  this.update = function() {
    
    /// Use a sine wave to uniformly modify the anchor
    /// location across the entire system.
    let scal = map(sin(frameCount*0.01),-1,1,
                   -this.scale,this.scale);
    
    /// Connect the nodes with lines using
    /// a vertices.
    beginShape();
    
    /// Associate a element pointer value with the
    /// nodes.  The association is uniform and
    /// resets to the beginning location after
    /// reaching the end of the arrays.
    this.index += 1; 
    if (this.index > this.pos.length-1) {
      this.index = 0;
    }
    
    /// Change the way the way the pointer finds
    /// an element to compare with the system.
    /// Assign locally the uniform mover or 
    /// allow the statement that sets locally
    /// an interpolated mover.
    let ir = this.index;
    
    /// Set a local variable to hold the 
    /// pointer value from a noise mover.
    
    // let ir = floor(map(noise(this.index*0.01,this.vel[this.index]*0.05,
    //                          frameCount*0.01),0,1,
    //                          0,this.pos.length));
    
    /// Loop through the elements in the arrays.
    /// Use the stored anchor location to isolate
    /// any movements and vertices to the proportioned
    /// areas.
    for (let i = 0; i < this.pos.length; i++) {
      
      /// Use the velocity as an argument in the
      /// sin and cos functions.  This produces a
      /// circle.  Modify the range of the return
      /// by adding the local variable that is 
      /// holding the anchor modifier value (scal).
      this.vel[i] += 1;
      
      /// Get modified-circular movement values using
      /// sin and cos.
      let xm = map(sin(this.vel[i]*0.01),-1,1,
                   -this.scale+scal,
                   this.scale+scal);
      let ym = map(cos(this.vel[i]*0.5),-1,1,
                   -this.scale+scal,
                   this.scale+scal);
      
      /// Get modified locational variants using
      /// noise mapped to the modified proportioned
      /// areas.
      let xn = map(noise(i*0.05,this.pos[i].x*0.01,
                         this.vel[i]*0.05),0,1,
                   -this.scale+scal,this.scale+scal);
      let yn = map(noise(i*0.05,this.pos[i].x*0.01,
                         this.vel[i]*0.1),0,1,
                   -this.scale+scal,this.scale+scal);

      /// Translate to the modified anchor location
      /// within the current proportioned area.
      // push();
      // translate(this.pos[i].x+xn,
      //           this.pos[i].y+yn);
    
      //// Choose to degrade the visible output
      //// with a "spray" of geometries within
      //// the current proportioned area.
      // stroke(0,255);
      // for (let n = 0; n < 4; n ++){
      //   strokeWeight(random(this.scale*0.01,
      //                      this.scale*0.25));
      //   let rx = random(-this.scale/2,this.scale/2);
      //   let ry = random(-this.scale/2,this.scale/2);
      //   point(xm+rx,ym+ry);
      // }
      // pop();
      
      
      //// Generate vertices and fill with a 
      //// low alpha to produce trinagular and
      //// polygonal panes.  With perstent output,
      //// the overlapping panes create layers and
      //// gradients.
      //// Degrade the output with random panes.
      push();
      
      /// Modify the current location using
      /// a noise mover within the proportioned area.
      let xnt = map(noise(i*0.05,this.pos[ir].x*0.1,
                         frameCount*0.05),0,1,
                   -this.scale,this.scale);
      let ynt = map(noise(i*0.05,this.pos[ir].x*0.05,
                         frameCount*0.01),0,1,
                   -this.scale,this.scale);
      
      /// Test the distance between the current anchor
      /// and the assocated location from the element
      /// pointer.  As the element pointer moves- to
      /// select an element in the array, the loop is
      /// cycling through each grid location.  Comparing
      /// the current grid location in the loop with the
      /// element selected by the mover will give us a 
      /// range of unique geometries that will fill a 
      /// range of proportioned areas.
      let d = dist(this.pos[i].x,
                   this.pos[i].y,
                   this.pos[ir].x,
                   this.pos[ir].y);
      if (d < this.scale*random(1,8)) {
        
        /// Generate geometries.
        vertex(this.pos[i].x+xnt,
               this.pos[i].y+ynt);
        
        /// Connect the applicable nodes.
        /// Degrade the output with a lower alpha.
        /// Add more randomness to the modified 
        /// locations.  These strokes can add a
        /// gem-like quality to the proportioned output.
        stroke(0,96);
        line(this.pos[i].x+xn+random(5),
                   this.pos[i].y+yn,
                   this.pos[ir].x+xnt+random(5),
                   this.pos[ir].y+ynt);     
      }
      pop();
    }
    
    /// Make determinations about how to display the
    /// output.  Add stochatic systems to generate
    /// balanced color combinations and gradients.
    fill(255,255);
    stroke(255,random(200,125),0,16);
    strokeWeight(random(1,2));
    // noFill();
    // noStroke();
    let colr = random(175,200);
      fill(0,colr-75,colr,16);
    if (random() < 0.5) {
      fill(0,0,0,255);
    }
    if (noise(frameCount*0.1) > 0.55){
      fill(255,16);
      stroke(0,64);
    }
    if (noise(frameCount*0.1) < 0.35){
      fill(125,0,0,64);
      stroke(255,random(200,125),50,16);
    }
    endShape();
  }
}

/// Provide a way to save the output as an image
/// file.  Press the DOWN ARROW to SAVE.
/// Be sure to give your system a unique name
/// to save the files under.
function keyPressed(){
  if (keyCode === DOWN_ARROW) {
    let fc = frameCount;
    console.log('Generation '+fc);
    console.log('saving...');

    /// Give the files a unique name that includes
    /// the generation number in frame counts.
    saveCanvas('Altereffects'+fc, 'png');
  }
}


/// Provide a way to view the output in full screen
/// mode.  Click the canvas to switch modes.
function mousePressed() {
  if (mouseX > 0 && mouseX < width &&
    mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}




