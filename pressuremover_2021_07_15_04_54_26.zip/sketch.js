//// Pressure Mover
//// Brownian Pressure
//// Visualization
//// by Ed Cavett
//// March 2021

//// Explore Brownian motion behavior
//// with this particle/cell object.
//// Brownian motion is a random
//// movement with equal vector
//// probability.  Each cycle
//// the object has an even chance
//// to move in any direct of 2PI
//// radians (360 degrees).
//// In this example, the cell object
//// receives a direction to move
//// from the particle objects
//// inside the cell.  When a particle
//// makes contact with the cell wall,
//// the direction of the cell changes
//// to match the direction of the
//// particle, then it is reflected or
//// it can be returned to the center.

//// Change motion behavior:
//// 1) Adjust pressure value
////    to increase or decrease
////    the number of particles inside
////    the cell.
//// 2) Adjust the radius of the cell
////    to increase or decrease the
////    time it takes for a particle
////    to make contact with the cell wall.

//// Learning tool:
//// Particle system
//// Distance calculations
//// Vectors and Positions Translations
//// Vector Methods
//// Angle-to-Heading calculation
//// Brownian Motion sub-type


/// The inside of the cell contains an array of 
/// particles that push on the cell.
let insides; /// array of particles inside cell

/// The cell confines the particles by its
/// radius using distance calculations.
/// Its movements are government by the impact
/// of the particles inside of it.
let cell; /// a single cell pushed by particles

/// The pressure inside the cell is represented
/// by the number of particles and the frequency
/// of impacts.  Pressure and particles are
/// directly proportional.
let pressure = 25; /// number of particles
/// Larger cell size allows for more cell
/// displacement between impacts
let cellsize = 200;
/// Use this variable to activate
/// a control when a particle hits
/// the cell wall.  It can be used to
/// change color; show or hide; etc.
let hitlight = 0;

/// Use the grid object to measure
/// the amount of cell displacement 
/// from window's center over time.


function setup() {
  if (cellsize > 280) {
    cellsize = 280;
  }
  /// Set canvas to the square 
  /// to make drawing grid faster.
  createCanvas(600,600);
  cell = new bubble();
  insides = new particles(cell.pos.x,
    cell.pos.y,
    pressure);
  /// Parameters for gridMaker control
  /// the square size.  Value is distributed
  /// to both x and y.
}

function draw() {
  /// Reduce the opacity
  /// to see the motion
  /// in fading trails
  /// that follow the 
  /// particles movements
  
  background(0, 0, 0, 255);
  
  //// Parameter for gridmaker
  //// sets the size and
  //// rotation of grid.
  //// QUARTER_PI sets 45-135 degrees
  // gridMaker(50,QUARTER_PI);
  
  //// PI sets 0-90 degree
  gridMaker(50,PI);
  cell.update(insides.angle);
  insides.update(cell.pos.x,
                cell.pos.y);
}


function gridMaker(size,rot){
  this.size = size;
  
  /// Highlight every nth line
  /// this.size * n
  /// Set n to 6 to divide grid by half
  /// Set n to 3 to divide quarters
  this.thicker = this.size*3;
  
  for (let i = 0; i < 601; i+=this.size) {
    push();
    translate(width/2,height/2);
    
    /// Snap the grid to the angle
    /// of the impact heading 
    // rotate(insides.angle);
    rotate(rot);
    stroke(75,255);
    // if (i > (width/2-this.size/2) &&
    //     i < (width/2+this.size/2)){
    if (i/this.thicker === int(i/this.thicker)){
    stroke(0,100,175,255);
    }
    strokeWeight(2);
    line(-width/2,i-width/2,
         width-width/2,i-width/2);
    line(i-height/2,-height/2,
         i-height/2,height-height/2);
    // line(0,i,width,i);
    // line(i,0,i,height);
    pop();
  }

}


function bubble() {
  /// The radius of the cell governs
  /// the frequency of impacts by the
  /// particles inside. The pressure
  /// and radius of the cell are
  /// directly proportional.
  this.r = cellsize; /// size of the cell
  
  /// Cell will begin at the center of window
  this.pos = createVector(width/2,
                          height/2);
  /// Cell will begin at a random location
  // this.pos = createVector(random(this.r * 2,
  //     width - this.r * 2),
    // random(this.r * 2,
    //   height - this.r * 2));

  this.vel = createVector(0,0);
  
  this.speed = random(1);
  this.vel.mult(this.speed);

  this.update = function(a) {
    this.vel = p5.Vector.fromAngle(a);
    this.pos.add(this.vel);
    
    if (this.pos.x < this.r){
      this.pos.x = this.r;
    }
    if (this.pos.x > width - this.r){
      this.pos.x = width-this.r;
    }
    if (this.pos.y < this.r){
      this.pos.y = this.r;
    }
    if (this.pos.y > height) {
      this.pos.y = height-this.r;
    }
  
    push();
    translate(this.pos.x,
              this.pos.y);
    
    /// Add the variable 'hitlight'
    /// to stroke for a hit effect
    stroke(255,255);
    fill(0,175);
    
    /// Display core to show
    /// particles relationship
    /// to the center of the cell.
    strokeWeight(50);
    stroke(hitlight,50);
    point(0,0);
    
    /// Display or hide the cell
    /// wall to infer the contraint
    /// from the motion of the particels.
    strokeWeight(10);
    stroke(255,100,0,175);
    circle(0, 0, this.r * 2);
    hitlight = 0;
    pop();
  }


}


function particles(x, y, qnty) {
  this.pos = [];
  this.vel = [];
  
  /// The distance calculation is
  /// sensative to the speed of particles.
  /// A high speed can jump the cell wall.
  /// There is a calculation to push
  /// back an overrun particle to the
  /// perimeter of the cell. However,
  /// larger velocity vectors may cause
  /// an error.
  /// As the cell moves in one direction
  /// particles moving in the opposite
  /// direct will experience twice
  /// the speed per frame with respect 
  /// to the cell wall's motion.
  /// To avoid this, the push back involves
  /// a multiplier of 90% of the distance
  /// from the cell's center.
  /// The intent is to fall within the cell
  /// wall range after an out-of-bounds
  /// is true for the particle.
  
  this.speed = [];
  this.angle = 0;
  this.headfind = createVector(0,0);
  
  for (let i = 0; i < qnty; i++) {
    this.pos.push(createVector(x, y));
    this.vel.push(p5.Vector.random2D());
    this.speed.push(random(1,3));
    this.vel[i].mult(this.speed[i]);
  }

  this.update = function(x,y) {
    for (let i = 0; i < qnty; i++) {
      this.pos[i].add(this.vel[i]);
      this.bounds(x,y,i);
      push();
      translate(this.pos[i].x,
        this.pos[i].y);
      stroke(50+(i*(205/pressure)),255,0,255);
      strokeWeight(10);
      point(0, 0);
      pop();
    }
  }

  this.bounds = function(x,y,i) {
    let xck = this.pos[i].x;
    let yck = this.pos[i].y;
    
    /// connect the particles
    /// to the center of the cell
    /// to see the relationship
    /// between their motion
    
    // stroke(255,100);
    // strokeWeight(1);
    // line(xck,yck,x,y);
    let d = dist(x, y, xck, yck);
    if (d > cell.r-3) {
      hitlight = 255;
//// bounce away after contact with cell wall
            this.headfind =
        createVector(this.pos[i].x-cell.pos.x,
                     this.pos[i].y-cell.pos.y);
      this.headfind.normalize();
      this.pos[i].set(this.headfind.mult(cell.r*0.9));
      this.pos[i].add(cell.pos);
      this.angle = this.headfind.heading();
      this.vel[i].mult(-1);
      
//// return to center after contact with cell wall
//       this.headfind =
//         createVector(this.pos[i].x-cell.pos.x,
//                      this.pos[i].y-cell.pos.y);
//       this.angle = this.headfind.heading();
//       this.pos[i].x = x;
//       this.pos[i].y = y;
//       this.vel[i] = p5.Vector.random2D();
//       this.vel[i].mult(2);
//       this.vel[i].x = random(-2,2);
//       this.vel[i].y = random(-2,2);
    }
  }
}


/// Click to Go Fullscreen /bottom click
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}


  //// end of sketch