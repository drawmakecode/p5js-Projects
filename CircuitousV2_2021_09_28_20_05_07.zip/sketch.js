//// "Circuitous" Generative System
//// by Ed Cavett
//// September 2021


/// Declare a variable to hold the shape-making
/// object system.
let shape;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  /// Center geometries.
  rectMode(CENTER);
  /// Clear background once at start.
  background(0,255);
  /// Instantiate the shape-maker system and
  /// assign it to the associated variable.
  shape = new shapeMaker();
}

function draw() {
  /// No background refresh will allow the
  /// output to persist and accumulate.
  
  /// Execute the update method in the shape-maker
  /// object function.
  shape.update();
}


/// The shape-maker function holds the properties of a
/// stochactic system that produces geometric structures
/// that grow across and down the canvas.  Pseudo-
/// randomness governs the direction and output of 
/// geometies.  

function shapeMaker() {
  /// Declare and assign global function variables.
  /// These include:
  /// The vertical range inside which the output
  /// for each pass is positioned.   
  this.size = width*0.016;
  /// The length of the stepping movement that moves
  /// the system's output across the canvas.
  this.scale = width * 0.1;
  /// The global position that moves the system's
  /// output down the canvas.
  this.shift = this.scale;
  
  /// The local position of the origin from which
  /// a line or geometry is output.  Calculate an
  /// offset for the vertical position to place it
  /// with a top margin.
  this.x = 0;
  this.y = this.shift/2;
  
  /// The previous or old positional values.
  this.xo = this.x;
  this.yo = this.y;
  
  /// A temporary x-position placeholder that
  /// retains the local x position to jump back to
  /// after processing a particular movement type.
  /// This maintains the contiguousness of the line.
  this.xr = this.x;
  
  /// An integer to switch on/off the type of 
  /// movement that is stochastically generated.
  this.d = 0;

  
/// This method directly outputs the path of the
/// movements choices it picks randomly.
/// It also executes the methods to overlay
/// geometries on the path that it generates.
  this.update = function(){
    
    /// Determine which system to use for the 
    /// stochastics; pseudorandom or geometric.
    if (random() < 0.5) {
      this.d = floor(
                 map(
                   noise(this.x*0.05,
                         this.y*0.01,
                         frameCount*0.05),
                   0,1,
                   -5,16));
    } else {
      this.d = floor(
                 map(
                   cos(frameCount*0.01),
                   -1,1,
                   0,6));
    }
  
    /// The noise return is a curved-distribution, so
    /// the ranges are spread out into invalid integers.
    /// This will constrain that return to valid movement
    /// values.  The constrained substitute for out-of-range
    /// values will be pseudorandom.
    if (this.d > 6 || this.d < 0) {
    this.d = floor(random(7));
    }
    /// Ahead of any changes to the local x,y position,
    /// store the current position into the previous position
    /// variables.
    this.xo = this.x;
    this.yo = this.y;
    
    /// Execute a method that affects the movements
    /// and output types for the shape-maker system.
    this.getMove();
    
    /// Once positions have been determined by the 
    /// movement calculation, check them for validity.
    this.bounds();
    
    /// Declare and assign a local variable to hold
    /// a color value interpolated to the current 
    /// vertical position of the output.
    let colb = map(this.y,0,height,255,50);
    
    /// Contain any changes to the graphic attributes.
    push();
    
    /// Set the outline color to a calculate of
    /// the local variable for color.
    stroke(255,random(255,175),colb,255);
    /// Set the thickness of the outline to a
    /// fraction of the canvas height.
    strokeWeight(height*0.0025);
    
    /// Output a line from the previous position of the 
    /// output to the current position of the output as
    /// defined by the local position values.
    line(this.xo,this.yo,this.x,this.y);
    pop(); /// End graphic attribute container.
    
    /// Output a stochastically determined geometry at the
    /// output position by executing a method that performs
    /// the conditions calculations and generates output for
    /// those geometries.
    this.geom();
  }   

/// Use the global function variables to
/// determine the output positions.  Translate
/// the origin to that position and output the 
/// geometry.
  this.geom = function(){
    
    /// Set a local variable to hold a size for
    /// the geometries.
    let size = height*0.018;
    
    /// Set a local variable to the return of a sine wave
    /// that tells the system which geometry to output.
    let typ = floor(
              map(sin(frameCount*0.01),-1,1,
                  0,5));
    
    /// Contain any changes to the graphics attributes.
    push();
    
    /// Set the origin to the current local position +-
    /// a random position in the local size area.
    translate(this.x,this.y+random(-size,size));
    
    /// Set some local variables to hold color values
    /// interplolated to the current local x,y positions.
    let colr = map(this.x,0,width,50,255);
    let colg = map(this.y,0,height,255,75);
    
    /// Determine to output with stroke/fill associated
    /// to one set or the inverse of that set.
    if (random() < 0.5) {
      stroke(0,255);
      fill(colr,colg,0,255);
    } else {
      stroke(colr,colg,0,255);
      fill(0,255);
    }
    
    /// Determine which geometry is being output by
    /// looking at the typ variable value.  Make
    /// the assigned geometry and output to the origin
    /// with a size set to the local size variable.
    if (typ === 0) {
      circle(0,0,size);
    }
    if (typ === 1) {
      rect(0,0,size);
    }
    /// Center the triangle in an area equal to the
    /// circle's and square's.  Do this by dividing
    /// the local size variable in half and making
    /// the triangle point along the division line.
    /// In this case, the division line is vertical,
    /// so the x-value is centered at the origin.
    if (typ === 2) {
      triangle(0,-size/2,
               -size/2,size/2,
               size/2,size/2);
    }
    
    /// Choose to add more geometries or line segments
    /// by increasing the range of typ values.
    /// These geometries are squares described by
    /// line segments.  
    if (typ === 3) {
      stroke(255,random(200,255),25,255);
      /// Loop through the x values inside
      /// the area of a square in the range of the 
      /// size variable value.
      for (let x = 0; x < size; x+=3) {
        line(x,-size/2,x,size/2);
      }
    }
    if (typ === 4) {
      stroke(255,random(200,255),25,255);
      /// Loop through the y values inside
      /// the area of a square in the range of the 
      /// size variable value.
      for (let y = 0; y < size; y+=3) {
        line(-size/2,y,size/2,y);
      }
    }
    ///////
    pop(); /// Close the container for the graphics
           /// attributes changes.  Origin returns to
           /// global setting.
  }

/// A method for moving the local position that uses
/// the global function variable this.d (an integer)
/// to stochastically determine which leftward direction
/// to travel.
  this.getMove = function(){

    /// Determine which direction to travel
    if (this.d === 0) {
      /// Travel up, then randomly determine to set the 
      /// direction to right for a net-diagonal travel.
      this.y -= this.size;
      if (random() < 0.5) {
        this.d = 4;
      }
    }
    
    if (this.d === 1) {
      /// Travel down, then randomly determine to set the
      /// direction to right for a net-diagonal travel.
      this.y += this.size;
      if (random() < 0.5) {
        this.d = 4;
      }
    }
    
    if (this.d === 2) {
      /// Set the local function variable to temporarily
      /// hold the local x position value.
      /// Travel right and up.
      this.xr = this.x;
      this.x += this.size;
      this.y -= this.size;
    }
    
    if (this.d === 3) {
      /// Set the local function varaible to temporarily
      /// hold the local x position value.
      /// Travel right and down.
      this.xr = this.x;
      this.x += this.size;
      this.y += this.size;
    }
    
    if (this.d === 4) {
      /// Accepts the movement set by type 0 and 1
      /// when the random chance is true.
      /// Set the temp x variable.
      /// Travel right.
      this.x = this.xr;
      this.x += this.size;
    }
    
    if (this.d === 5) {
      /// Determine to perform this type or
      /// skip it.
      if (random() < 0.5) {
        this.d = 6;
      }
      /// Set the temp x.
      /// Travel right twice as far.
      /// Travel up half as far for a net-diagonal
      /// that is - 45 degrees off horizontal
      this.x = this.xr;
      this.x += this.size*2;
      this.y -= this.size/2;
    }
    if (this.d === 6) {
      /// Set the temp x.
      /// Travel right twice as far.
      /// Travel down half as far for a net-diagonal
      /// that is +45 degrees off horizontal
      this.x = this.xr;
      this.x += this.size*2;
      this.y += this.size/2;
    }
    
    /// Add more direction types by increasing the 
    /// local function variable ranges.
    
    ////////
  }

  /// Use a method to contrain the positions to inside
  /// the canvas ranges.  
  /// Use the out-of-bounds tests to adjust the global
  /// position variable (this.shift) that moves the
  /// output stripe area down the canvas, and resets to
  /// the top when out-of-bounds.
  this.bounds = function(){
    /// Determine to reset the x position when passing
    /// the right margin of the canvas.
    /// The margin is adjusted by the scale of the output
    /// movement.
    if (this.x >= width-this.scale) {
      /// Set the current and previous x positions to
      /// the left margin for the canvas.
      this.x = 0;
      this.xo = 0;
      this.xr = this.x;
      /// Advance the global y position to the next
      /// place down the canvas.
      this.shift += this.scale;
      /// Set the current y position to the global
      /// y position.  Set the previous y position to the
      /// current y position.
      this.y = this.shift;
      this.yo = this.y;
      /// Diminish the persistent output so the 
      /// accumulated output doesn't over-saturate
      /// the canvas.  This allows the output to run
      /// indefiniately without filling in.
      background(0,24);
      /// Determine if the global y position is passing
      /// the bottom margin of the canvas.  This adjustment 
      /// allows for a margin inside the real canvas range.
      if (this.shift > height-this.scale) {
        /// Set the global y position to the scale of the
        /// local output area.
        this.shift = this.scale;
        /// Set the current y position to the global
        /// y position.
        this.y = this.shift;
        /// Set the previous position to the current
        /// y position.
        this.yo = this.y;
      }
    }
    /// Determine if the local y position is out-of-bounds
    /// to the global y position +- the scale of the 
    /// output area.
    if (this.y < this.shift-this.scale/2 ||
       this.y > this.shift+this.scale/2) {
      /// Set the current local y position to the global
      /// y position.
      this.y = this.shift;
      /// Set the previous locay y position to the current
      /// y position.
      this.yo = this.y;
    }
  }
 }





function keyPressed(){
  let name = frameCount;
  if (keyCode === DOWN_ARROW) {
    console.log('Generation '+name);
    console.log('saving...');
    saveCanvas('circuitousV2'+name+'png');
  }
}





