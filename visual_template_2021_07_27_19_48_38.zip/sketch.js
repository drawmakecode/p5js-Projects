//// Visualizer Template 
//// by Ed Cavett
//// July 2021


//// Provide a ready-to-use function
//// for starting a visualization sketch.
//// The starting environment includes
//// the file asset, declaration and assignments,
//// spectrum analysis and returns to global
//// variables.  The main body of the code handles
//// the sound analysis and looping through
//// the amplitude array.  The output is sent into
//// the visualizer function for processing.
//// Users are ready to begin implementing 
//// procedures that use the 0-63 amplitude elements
//// that receive a value from 0-255.
//// Use these data to graph as a visualization.
let music;
let ftrans;
let button;
let soundwave;
let visual;

function preload() {
  // music = loadSound('Dave_Depper_-_Up.mp3');
  music = loadSound('Meet & Fun! - Ofshane.mp3');
}


function setup() {
  createCanvas(windowWidth,
               windowHeight);
  button = createButton('Play/Pause');
  button.mousePressed(toggleMusic);
  music.play();
  ftrans = new p5.FFT(0.025, 64);
  visual = new visualizer();
}


function draw() {
  background(0,255);
  soundwave = ftrans.analyze();
  translate(width/2,height/2);
  stroke(255,255);
  strokeWeight(2);
  noFill();
  for (let i = 0; i < soundwave.length; i++) {
    beginShape();
    let amp = soundwave[i];
    visual.update(i,amp);
    endShape(CLOSE);
  }
}


function visualizer(){
  /// This variable normalizes the amplitude
  /// value into the desired range.
  this.ysize = height*0.05;
  
  /// Use an oscillator to generate a 
  /// sinusoridal waveform to wrap the
  /// amplitude values around.
  this.svel = 0.05; /// Velocity of oscillation
  this.sfrq = 50; /// Frequency of waveform

  
  //// vi is the element's index value (0-63) used
  //// to access a given amplitude value.
  //// vamp is the return of the given amplitude
  //// value in a range from 0-255.
  this.update = function(vi,vamp){
    
    /// Use the index value to set location x.
    let x = map(vi,0,63,-width/2,width/2);
    /// Factor the width by the amplitude array size
    let xf = -width/64;
    /// Use the amplitude value to set location y.
    let y = map(vamp,0,255,-this.ysize,this.ysize);
    /// Adjust the oscillator to generate waveform
    /// location.  Check for bounds.
    this.sfrq += this.svel * 0.05;
    if (this.sfrq < -50 || this.sfrq > 350) {
      this.svel *= -1;
    }
    /// Apply oscillator to get the waveform
    /// location values.
    let ymod = map(sin(this.sfrq*(vi*0.0005)),-1,1,
                   -height*0.4,height*0.4);    
    /// Insert graphic elements inside a
    /// container.
    push();
    vertex(x,y+ymod);
    vertex(x,-y+ymod);
    vertex(x+xf,-y+ymod);
    vertex(x+xf,y+ymod);
    pop();
  }
}


function toggleMusic() {
  if (music.isPlaying()) {
    music.pause();
  } else {
    music.play();
  }
}








/// end of sketch
