//// Ghost Orbs: Blurry Dust Particles
//// in p5.js
//// Public version - Free to Distribute

//// by Ed Cavett
//// May, 2021

//// A particle system that
//// produces a visual effect:
//// Out-of-focus, floating dust,
//// or "ghost orbs."

//// Note: There have been 2 edits
//// since publishing. 1) Noise 
//// offset is more relational
//// instead of random. 2) Sway
//// movement is more 3D with
//// velocity scaled to the size
//// of the particle.

/////////


/// Declare an empty array to hold
/// the instances of our particle
/// object.
let orb = [];

/// Declare and assign the number
/// of particles in the system
let popu = 40;

function setup() {
  createCanvas(windowWidth, windowHeight);

  /// Loop through all the elements
  /// and assign a new instance
  /// for each particle.
  for (let i = 0; i < popu; i++) {
    orb.push(new particle(i));
  }
}

function draw() {
  background(25, 255);

  /// Loop through all the elements
  /// and perform the 'update' method
  /// for each particle.
  for (let i = 0; i < orb.length; i++) {
    orb[i].update();
  }
}

/// Generates a unit particle with
/// position, velocity and scale.
function particle(i) {
  /// Assign the starting position
  /// for a new particle.
  this.pos = createVector(random(width), random(height));

  /// Generate a random direction for
  /// the particle to move.
  this.vel = p5.Vector.random2D();

  /// Generate a random magnitude
  /// and multiply the unit velocity
  /// by the magnitude.
  this.vel.mult(random(3) + 1);

  /// Assign an incrementer
  /// to move through perlin
  /// noise values.  This animnates
  /// the horizontal sway of each
  /// particle.
  
  /// (added after publishing)
  /// Stack the offset so the noise
  /// return values are closely
  /// relatational.  This makes them
  /// appear to move together in a
  /// draft.
  this.noff = i*0.001;
  
  /// (not implemented after publishing)
  // this.noff = random(100);
  
  /// Assign a scale to the particle
  /// that affects the stroke weight
  /// of a point.
  this.sw = random(25, 125);

  /// Assign the starting glint
  /// effect at n. When activated,
  /// the glint value will rise
  /// and then fall back down to n.
  /// The effect will brighten the
  /// particle for a brief moment.
  this.glint = 5;

  /// Assign the fade up/down value
  /// for when glinting occurs.
  this.gpol = 0;

  /// Assign a speed to
  /// to glint fade up/down.
  this.grate = 0.05;

  /// Create method to move particle,
  /// effect its appearance,
  /// and display output.
  this.update = function () {
    /// Increment the noise offset.
    this.noff += 0.005;

    /// Move particle to next
    /// location by adding
    /// its velocity (either - or +).
    this.pos.add(this.vel);

    /// Constrain the position of a particle
    /// by performing the bounds method.
    /// Make adjustments to x and y, as needed.
    this.bounds();

    /// Constrain the interpolated "sway" movement
    /// to the scale of the particle.  The limit
    /// is in the form of percent of the width.
    /// This creates a paralax effect where objects
    /// closer to the viewer move faster than those
    /// farther away.
    let cx = map( this.sw,25,125,0.1,0.5);
    
    /// Assign local x to the return
    /// of noise using the offset incrementer.
    /// Interpolate the return to 1/2 the width
    /// of the canvas.
    let x = map(noise(this.noff), 0, 1, -width * cx, width * cx);

    /// Loop through the scale value backwards.
    /// The decrement value controls appearance of
    /// density.  The stopping value controls
    /// the scale of the solid particle at center.
    /// The loop draws a progressively smaller point
    /// while affecting the stroke's alpha.
    /// This causes the edges to fade off, giving
    /// the particle a blurry appearance.
    for (let d = this.sw; d > 15; d -= 10) {
      
      /// Adjust stroke weight by
      /// reducing the top value with
      /// the loop value.
      strokeWeight(this.sw - d);

      /// Randomly trigger the glint
      /// effect value to start incrementing
      /// with a positive gpol.  Once glint
      /// reaches a max value, the gpol value
      /// goes negative and begins decrementing.
      /// The glint value will fall until it
      /// hits the minimum, at which point, it
      /// will hold at that value until
      /// triggered to increment again.

      /// Trigger incrementing.
      /// The triggering value
      /// controls the frequency
      /// at which glinting occurs.

      /// Move the glint value
      /// according to the glint
      /// conditions' adjustments
      /// to the increment/decrement value.
      this.glint += this.gpol;

      /// Randomly determine if a glint effect
      /// is activated.  This affects the frequency
      /// of glinting.
      if (random(1) < 0.001 && this.gpol === 0) {
        /// Get a random duration for
        /// glint fade up/down.
        this.grate = random(0.001, 0.25);
        /// Assign the glint up/down
        /// value with random duration value.
        this.gpol = this.grate;
      }

      /// Trigger decrementing.
      if (this.glint > 20) {
        this.glint = 20;
        this.gpol = -this.grate;
      }

      /// Hold at minimum.
      if (this.glint < 5) {
        this.glint = 5;
        this.gpol = 0;
      }

      /// Assign appearance attributes.
      /// Add a random amount of
      /// glint each frame for flickering
      /// effect.
      stroke(255, this.glint + random(this.glint / 2));

      /// Display output.
      point(this.pos.x + x, this.pos.y);
    }
  };

  /// Create a method that checks
  /// the position and constrains
  /// it with wrap-around adjustments.
  this.bounds = function () {
    /// extend x and y bounds
    /// outside of canvas
    let extx = width * 0.5;
    let exty = height * 0.5;

    /// check x
    if (this.pos.x < -extx) {
      this.pos.x = width + extx;
    }
    if (this.pos.x > width + extx) {
      this.pos.x = -extx;
    }

    /// check y
    if (this.pos.y < -exty) {
      this.pos.y = height + exty;
    }
    if (this.pos.y > height + exty) {
      this.pos.y = -exty;
    }
  };
}

//// end of sketch
