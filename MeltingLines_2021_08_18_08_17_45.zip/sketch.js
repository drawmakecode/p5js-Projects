/// Melting Lines
/// Generative Art
/// by Ed Cavett
/// August 2021

let ymod = 0;
let scale = 25;
let fall;


function setup() {
  createCanvas(windowWidth,windowHeight);
  fall = new fallers();
  background(0,255);
}

function draw() {
  background(0,5);
  push();
  fall.update();
  if (fall.posy[fall.posy.length-1] > height*2.5) {
    fall.restrt();
    background(0,75);
  }
  pop();
}


function fallers() {
  this.posx = [];
  this.posy = [];
  this.acc = [];
  this.vel = [];
  this.r = [];
  this.index = -1;
  this.colr = random(0,255);
  this.colg = random(0,255);
  this.colb = random(0,255);
  
  for (let y = 0; y < height/2; y+= height/scale) {
    for (let x = 0; x < width; x+= width/scale) {
      this.posx.push(0);
      this.posy.push(0);
      let aset = map(noise(x,y),0,1,
                    y*0.0001,y*0.00025);
      this.acc.push(aset);
      this.vel.push(0);
      this.r.push(0);
    }
  }
  
  this.update = function() {
    this.index = -1;
    let xoff = random(0.05,0.1);
    for (let y = 0; y < height/2; y+= height/scale) {
      beginShape();
      for (let x = 0; x < width; x+= width/scale) {
        this.index += 1;
        this.colr = map(noise(this.index*0.1),0,1,5,305);
        this.vel[this.index] += this.acc[this.index];
        this.posy[this.index] += this.vel[this.index];
        
        if (y < height/2-height/scale) {
          if (this.posy[this.index] >
              this.posy[this.index+scale]-scale/4){
            this.posy[this.index] = 
              this.posy[this.index+scale]-scale/4;
          }
        }
        ymod = this.posy[this.index]+y+(height/scale/2);
        push();
        translate(x,ymod);
        curveVertex(x,ymod);
        pop();
      }
      stroke(this.colr,this.colg,this.colb,128);
      let sw = map(ymod,0,height*2,8,1);
      strokeWeight(sw);
      noFill();
      endShape();
    }
  }
  
  this.restrt = function(){
    this.posx = [];
    this.posy = [];
    this.acc = [];
    this.vel = [];
    this.r = [];
    this.index = -1;

    for (let y = 0; y < height/2; y+= height/scale) {
      for (let x = 0; x < width; x+= width/scale) {
        this.index += 1;
        this.posx[this.index] = 0;
        this.posy[this.index] = height/8;
        this.acc[this.index] = random(y*0.0001,y*0.0002);
        this.vel[this.index] = 0;
        this.r[this.index] = 0;
        this.colr = random(0,255);
        this.colg = random(0,255);
        this.colb = random(0,255);
      }
    }
  }
}












