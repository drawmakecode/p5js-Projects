//// Shape Rain
//// by Ed Cavett
//// in p5.js WEBGL
//// June, 2021
//// Public Version - Free to Distribute


//// Generates a grid of falling geometries
//// within a particle system.
//// During the fall, the geometries will
//// stop at a set point for a short period
//// of time.  While stopped, the geometries
//// will randomly change shape until they
//// start falling, again.  Then, the last
//// change to the shape becomes the geometry's
//// new shape.  After reaching the bottom,
//// the geometries restart at the top and
//// fall through the field of view.
//// The global volume is rotated to 
//// provide a 360 degree view of the animation.

/// Declare a variable to hold 
/// the particle system function.
let shape;


function setup() {
  /// Tell p5.js that we want to use the Web
  /// Graphics Libray set of functions and methods.
  createCanvas(windowWidth, windowHeight, WEBGL);
  
  /// Assign a new instance of the particle
  /// system.
  shape = new shapeMover();

  /// Global set the fill and shut off the
  /// stroke.  Set the shapes to CENTER and
  /// clean the canvas to black.
  fill(255,175,0);
  noStroke();
  rectMode(CENTER);
  background(0);
}

function draw() {
  
  /// Clean the canvas each frame.
  /// Set local variables to handle
  /// color switching.
  let cr = map( noise(frameCount*0.01),0,1,
               -50,255);
  let cg = map( noise(frameCount*0.05),0,1,
               -50,255);
  let cb = map( noise(frameCount*0.075),0,1,
               -50,255);
  
  // background(cr,cg,cb);
  background(0,10,25);
  fill(0,0,0);
  /// The origin is set to 0,0,0 by default,
  /// but we can set it here to create a global
  /// change.
  translate(0,0,-height*0.1);
  
  /// Rotate the global volume
  /// toward the viewer (+X) by half-PI.
  /// The effect will be a top-side view
  /// of the grid.
  /// Note: The system is build as objects
  /// moving along the Z axis.  By rotating half PI,
  /// we are given the appearance of falling
  /// objects, even though they are not falling
  /// along the Y axis.
  // rotateX(-PI);
  
  /// With a dynamic rotation of the x-axis,
  /// we can view the output from top and bottom.
  rotateX(PI*0.2);
  /// Rotate the global volume around
  /// z-axis.  Because of how the system
  /// is built, this is visually similar
  /// to rotating around the Y axis.
    rotateZ(frameCount*0.01);
    // rotateY(frameCount*0.01);
    rotateX(frameCount*0.01);
  
  /// Call the update method of the particle
  /// system function through the assigned
  /// variable, shape.
  shape.update();
}

/// Generate a grid of geometries that
/// move along the z axis from + to -.
function shapeMover(){
  
  /// Declare an empty array
  /// to hold the change in location
  /// as the geometries fall.
  this.z = [];
  
  /// Declare and assign a variable
  /// to access the elements in the 
  /// arrays.
  this.index = 0;
  
  /// Declare an empty array
  /// to hold how fast geometries fall.
  this.speed = [];
  
  /// Declare an empty array to hold
  /// the value to assign geometry types.
  this.shp = [];
  
  /// Declare an empty array to hold
  /// the rotational angle for x,y and z.
  this.rotx = [];  
  this.roty = [];  
  this.rotz = [];  
  
  /// Declare an empty array to hold
  /// the change in angle per frame
  /// for the x,y and z axis.
  this.ratex = [];
  this.ratey = [];
  this.ratez = [];
  
  /// Declare an empty array to hold
  /// the halt-fall indicator and timer.
  this.stallz = [];
  
  /// Declare and assign a variable
  /// that will hold the growing size
  /// while geometry is stalled.
  this.cs = 10;
  
  /// Delcare and assign the x
  /// and y size of the grid. 
  /// These values will define
  /// the step size of each loop.
  let incremx = floor(width / 4);
  let incremy = floor(height / 4);
  
  /// Loop through the col spots (x) on the grid.
  for (let col = -width / 2; col < width / 2; col += incremx) {
    
    /// Loop through the row spots (y) on the grid.
    for (let row = -height / 2; row < height / 2; row += incremy) {
      
      /// Fill arrays with initial values.
      this.z.push(random(-width/2,width/2));
      this.speed.push(random(-10,-5));
      this.stallz.push(0);
      this.rotx.push(random(-PI,PI));
      this.roty.push(random(-PI,PI));
      this.rotz.push(random(-PI,PI));
      this.ratex.push(random(0.01,0.075));
      this.ratey.push(random(0.01,0.075));
      this.ratez.push(random(0.01,0.075));
      this.shp.push(floor(random(3)));
    }
  }
  
  /// Perform the movements for each
  /// particle.  Output the results.
  this.update = function(){
    
    /// Reset the index value to 
    /// move to begin moving through 
    /// the array sets.
    this.index = -1;
    
    /// Loop through the column spots.
    for (let col = -width / 2; col < width / 2; col += incremx) {
      push();
      translate(0,0,-height*0.1);
      stroke(0,200,255);
      strokeWeight(5);
      line(col,-height/2,col,height/2); 
      pop();
      /// Loop through the row spots.
      for (let row = -height / 2; row < height / 2; row += incremy) {
        push();
        translate(0,0,-height*0.1);
        stroke(100);
        strokeWeight(5);
        line(-width/2,row,width/2,row);
        pop();
        /// Move through the array sets
        /// by incrementing the index value.
        this.index += 1;
        
        /// Move the z location of a given
        /// geometry.
        // this.z[this.index] += this.speed[this.index];
        this.z[this.index] =
          lerp(this.z[this.index],-height-10,
              -this.speed[this.index]*0.005);
        /// Determine if the geometry has fallen
        /// to the farthest location.
        if (this.z[this.index] < -height) {
          /// Reset z location to front (top).
          this.z[this.index] = height ;
          /// Reset the stall timer to 0.
          this.stallz[this.index] = 0;
        }
        
        /// Check the z location for the 
        /// stalling level.  If stalling, increase
        /// stall timer and set location to
        /// stall level.
        if (this.z[this.index] < -height*0.1 &&
          this.stallz[this.index] < 100) {
          this.z[this.index] = -height*0.1;          
          this.stallz[this.index] += 1;
          /// Determine to make a change to the
          /// shape of the given geometry.
          if (random(1) < 0.075){
            this.shp[this.index] = floor(random(3));
          }
        }
        
        /// Isolate changes to the given
        /// geometry.
        push();
  
        /// Set the origin to the location
        /// of the given geometry's col and row.
        /// The z location is the falling vector.
        translate(col,row,this.z[this.index]);
        
        /// Determine to rotate only when
        /// the geometry is falling.
        if (this.stallz[this.index] === 0) {
          this.rotx[this.index] -= this.ratex[this.index];
          this.roty[this.index] -= this.ratey[this.index];
          this.rotz[this.index] -= this.ratez[this.index];
          rotateX(this.rotx[this.index]);
          rotateY(this.roty[this.index]);
          rotateZ(this.rotz[this.index]);
        }
        
        /// Generate output.
        strokeWeight(3);
        stroke(0,175,125);
        // fill(0,200,175);
        /// Randomly flash the
        /// fill and stroke.
        if (random(1) < 0.05) {
          stroke(0,random(175,255),0);
          strokeWeight(5);
        }
        if (random(1) < 0.01) {
          fill(0,random(50,200),0);
        }
        
        /// Determine which shape to
        /// output for the given geometry.
        
        /// Assign a local variable to hold
        /// the growing size while stalled.
        if (this.stallz[this.index] !== 0) {
          this.cs = map( this.stallz[this.index],
                      0,100,10,75);
        }
        
        if (this.z[this.index] > -height*0.1) {
          this.cs = 10;
        }
        if (this.shp[this.index] === 0) {
          circle(0,0,this.cs);
        }
        if (this.shp[this.index] === 1) {
          rect(0,0,this.cs);
        }
        if (this.shp[this.index] === 2) {
          triangle(0,
                   -this.cs*0.5,
                   -this.cs*0.5,
                   this.cs*0.5,
                   this.cs*0.5,
                   this.cs*0.5);
        }

        /// Detemine to grow a line to
        /// indicate the ground position.
        /// This creates some style to the
        /// output while giving the viewer
        /// a directional frame of reference.
        if (this.stallz[this.index] > 0) {
          
          /// Generate the output for the 
          /// line that extends from the
          /// stalled geometries.
          push();
          rotateX(-PI*0.5);
          let ll = map(this.stallz[this.index],0,100,
                       0,height);
          strokeWeight(6);
          stroke(0,200,255);
          line(0,0,0,ll+this.z[this.index]);
          pop();
        }
        
        /// End incapsulation.
        pop();
      }
    }
  }
}


/// Click to Go Fullscreen
function mousePressed() {
  if (mouseX > 0 &&
    mouseX < width &&
    mouseY > height / 2 &&
    mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}







