/// Nature's Vanity (Slide Show)
/// by Ed Cavett
/// fx(hash) Compliant NFT Design
/// June 2023

//--------------------------------------------------------
//// Key Press Options
//// Down Arrow - Save full-sized color image
//// Up Arrow   - Save the current frame.
//// B or b     - Save full-sized black-and-white image
//// P or p     - Save full-size posterized image
//// T          - Save "Tree" rendering layer on black
//// t          - Save "Tree" rendering layer on white
//// Space      - Start slide show

//// Author's Curated Random Seeds:
//// 911.0367437824607
//// 9033.190289046615

let colKeep;
let layerA;
let layerB;
let layerC;
let getLayerB;
let rock;

let fillR;
let fillG;
let fillB;
let strokeR;
let strokeG;
let strokeB;
let colMakerSet;

let gmax;
let gmin;
let leafYes;

let tgmaxLen;
let tgminLen;
let myFont;

let spotxoff;
let spotyoff;
let capImg;
let treeKeep;
let saveLayer;

let fadeTrans;
let xspot;
let yspot;
let stopOff;

let mushcol;

function preload() {
  // myFont = loadFont("Angeline Vintage_Demo.otf");
  myFont = loadFont("times-new-roman.ttf");
}

function setup() {
  let hashGen = fxrand() * 10000;
  console.log("random seed: " + hashGen);
  randomSeed(hashGen);
  noiseSeed(hashGen);
  generatrix();
}

function generatrix() {
  textFont(myFont);
  createCanvas(800, 800);
  layerA = createGraphics(1000, 1000);
  layerB = createGraphics(1000, 1000);
  rock = new rockMaker();
  strokeCap(SQUARE);
  strokeJoin(MITER);
  rectMode(CENTER);
  imageMode(CENTER);
  colMakerSet = floor(random(15));
  mushcol = floor(random(15));
  colMaker(colMakerSet);
  leafYes = floor(random(2));
  spotxoff = random(10000);
  spotyoff = random(10000);
  fadeTrans = 0;
  stopOff = 0;
}

function draw() {
  if (frameCount < 7) {
    titleMaker();
  }
  if (frameCount === 102) {
    createCanvas(800, 800);
  }
  if (frameCount > 103 && frameCount < 109) {
    plateA();
  }

  if (frameCount === 109) {
    treeKeep = get();
    plateB();
  }

  if (frameCount === 110) {
    plateC();
  }

  if (frameCount === 111) {
    ////grass LayerB -- foreground
    let stackGrass = 0;
    for (let ng = 0; ng < 2; ng++) {
      let startTheta = random(TAU);
      for (let gn = 0; gn < 100; gn++) {
        let gxSet = random(width);
        let gxFix = map(gxSet, 0, width, 0, TAU);
        stackGrass = height * random(0.01, 0.1);
        let glenMax = sin(startTheta + gxFix) * (height * 0.1) + stackGrass;
        gmax = abs(glenMax * random(0.6, 1));
        gmin = gmax * 0.1;
        layerB.push();
        layerB.translate(gxSet, height);
        colMaker(colMakerSet);
        grassMaker(gmax, random(-PI * 0.1, PI * 0.1));
        layerB.pop();
      }
    }
    getLayerB = layerB.get();
    getLayerB.filter(BLUR, 3);
    image(getLayerB, width * 0.5, height * 0.5);
    getLayerB = get();
    saveLayer = getLayerB;
  }
  if (frameCount === 111 && !stopOff) {
    fxpreview();
    noLoop();
  }
  if (frameCount === 112) {
    createCanvas(getLayerB.width * 1.05, getLayerB.height * 1.05);
    backgroundMaker();
    image(getLayerB, width * 0.5, height * 0.5);
    capImage = get();
    capImage.resize(3000, 3000);
    createCanvas(1550, 800);
    titleMaker();
  }
  //// Animation
  if (frameCount > 112 && frameCount % 150 === 0) {
    let xRatio = (capImage.width - width) * 0.5;
    xRatio -= width * 0.08;
    let yRatio = (capImage.height - height) * 0.5;
    yRatio -= height * 0.08;
    xspot = random(-xRatio, xRatio);
    yspot = random(-yRatio, yRatio);
    image(capImage, xspot + width * 0.5, yspot + height * 0.5);
  }
  if (frameCount % 150 === 0) {
    fadeTrans = 0;
    noTint();
  }

  if (frameCount > 112) {
    if (frameCount === 113) {
      console.log("Nature's Vanity");
      console.log("Generative System by Ed Cavett");
      console.log("June 2023");
    }
    fadeTrans += 0.2;
    tint(255, 255, 255, fadeTrans);
    image(capImage, xspot + width * 0.5, yspot + height * 0.5);
  }
}

function titleMaker() {
  push();
  strokeJoin(MITER);
  backgroundMaker();
  translate(width * 0.5, height * 0.5);
  pop();
  textAlign(CENTER);
  textSize(75);
  noFill();
  stroke(strokeR, strokeG, strokeB, 175);
  strokeWeight(20);
  text("Nature's Vanity", width * 0.5, height * 0.5);
  textSize(50);
  text("by Ed Cavett", width * 0.5, height * 0.6);
  fill(255, 225);
  stroke(0, 255);
  strokeWeight(2);
  textSize(75);
  text("Nature's Vanity", width * 0.5, height * 0.5);
  textSize(50);
  text("by Ed Cavett", width * 0.5, height * 0.6);
  if (frameCount === 112) {
    fill(255, 255);
    textSize(50);
    stroke(strokeR, strokeB, strokeB, 175);
    strokeWeight(10);
    text("Preparing Slide Show", width * 0.5, height * 0.7);
    stroke(0, 255);
    strokeWeight(2);
    text("Preparing Slide Show", width * 0.5, height * 0.7);
  } else {
    stroke(strokeR, strokeG, strokeB, 175);
    strokeWeight(10);
    textSize(50);
    text("Preparing Scene...", width * 0.5, height * 0.7);
    textSize(50);
    fill(255, 255);
    stroke(0, 255);
    strokeWeight(2);
    text("Preparing Scene...", width * 0.5, height * 0.7);
  }
}

function plateA() {
  push();
  translate(random(width), height * 1.05);
  leafYes = floor(random(2));
  newTree(height * 0.65);
  pop();
  let getLayer = get();
  getLayer.resize(layerA.width * 0.2, 0);
  getLayer.resize(layerA.width, 0);
  layerA.image(getLayer, 0, 0);
}

function plateB() {
  createCanvas(layerA.width, layerA.height);
  // backgroundMaker();
  lineMaker(random(TAU));
  image(layerA, width * 0.5, height * 0.5);
  push();
  /// rock layer - background
  push();
  translate(random(width), height);
  buildMound();
  pop();
  translate(random(width), height * 1.05);
  colMakerSet = floor(random(15));
  colMaker(colMakerSet);
  leafYes = floor(random(2));
  newTree(height * 1.2);
  pop();
  push();
  translate(random(width), height * 1.05);
  colMakerSet = floor(random(15));
  colMaker(colMakerSet);
  leafYes = floor(random(2));
  newTree(height);
  pop();
  getLayer = get();
  image(getLayer, width * 0.5, height * 0.5);
  getLayer.filter(POSTERIZE, 3);
  tint(255, 255, 255, 64);
  image(getLayer, width * 0.5, height * 0.5);
  getLayer = get();
  noTint();
  backgroundMaker();
  getLayer.filter(BLUR, 2);
}

function plateC() {
  /// background with backTrees

  image(getLayer, width * 0.5, height * 0.5);
  push();
  translate(random(width), height * 0.95);
  colMakerSet = floor(random(15));
  colMaker(colMakerSet);
  leafYes = 1;
  newTree(height);
  pop();

  let nset = floor(random(3, 5));
  colMaker(mushcol);
  for (let n = 0; n < nset; n++) {
    rkeep = 0;
    push();
    translate(random(width), height);
    branchMaker(height * 0.25, 0);
    pop();
  }
  colMaker(colMakerSet);
  for (let fadey = 0; fadey < height; fadey++) {
    let alph = map(fadey, 0, height, 0, 32);
    stroke(0, alph);
    strokeWeight(2);
    line(0, fadey, width, fadey);
  }

  /// rock layer - background
  push();
  translate(random(width), height);
  buildMound();
  pop();
}

function mushroom(len) {
  this.wide = len * random(0.1, 1);
  this.tall = len * random(0.1, 1.6);
  this.r = len;
  this.gap = TAU * 0.01;
  let sided = random();
  let x = cos(HALF_PI) * this.wide;
  let y = sin(HALF_PI) * this.tall;
  let xprev = x;
  let yprev = y;
  let offset = random(10000);
  push();
  translate(0, 0);
  /// Stem
  for (let r = HALF_PI; r > 0; r -= this.gap) {
    push();
    translate(0, sin(HALF_PI) * this.wide * 0.5);
    stroke(strokeR, strokeG, strokeB, 255);
    xprev = x;
    yprev = y;
    x = cos(r) * this.wide;
    y = sin(r) * this.tall;
    let sw = map(r, HALF_PI, 0, 5, 1);
    strokeWeight(sw);
    if (sided < 0.5) {
      stroke(strokeR * 0.75, strokeG * 0.75, strokeB * 0.75, 255);
      line(xprev + sw * 0.4, yprev + sw * 0.4, x, y);
      stroke(strokeR, strokeG, strokeB, 255);
      line(xprev, yprev, x, y);
    } else {
      stroke(strokeR * 0.75, strokeG * 0.75, strokeB * 0.75, 255);
      line(-xprev + sw * 0.4, yprev + sw * 0.4, -x, y);
      stroke(strokeR, strokeG, strokeB, 255);
      line(-xprev, yprev, -x, y);
    }
    pop();
  }
  /// Cap
  let cwide = len * random(0.05, 0.5);
  let ctall = len * random(0.05, 0.06);

  let cx = cos(HALF_PI) * cwide;
  let cy = sin(HALF_PI) * ctall;
  push();
  if (sided < 0.5) {
    translate(x, sin(HALF_PI) * this.wide * 0.5);
    translate(0, sin(HALF_PI) * ctall * 0.25);
  } else {
    translate(-x, sin(HALF_PI) * this.wide * 0.5);
    translate(0, sin(HALF_PI) * ctall * 0.25);
  }
  let cr = 1;
  for (let r = HALF_PI; r < TAU + HALF_PI + this.gap; r += this.gap) {
    
                            
    cx = cos(r) * cwide;
    cy = sin(r) * ctall;
    let cmod = createVector(cx,cy);
    cmod.mult(map(noise(offset,frameCount,r),0,1,0.5,1.1));
    cr -= 0.003;
    let crmod = random(0.5,1);
    cr *= crmod;
    stroke(fillR * cr, fillG * cr, fillB * cr, 255);
    strokeWeight(1);
    line(0, 0, cmod.x,cmod.y);
  }
  pop();
  pop();
}

function grassMaker(len, theta) {
  layerB.push();
  layerB.translate(0, 0);
  layerB.rotate(theta);
  let sw = map(len, gmin, gmax, 1, 10);
  layerB.stroke(strokeR, strokeG, strokeB, 255);
  layerB.strokeWeight(sw);
  layerB.line(0, 0, 0, -len);
  layerB.strokeWeight(1);
  layerB.stroke(0, 255);
  layerB.line(-sw, 0, -sw * 0.8, -len);
  layerB.line(sw, 0, sw * 0.8, -len);
  layerB.translate(0, -len);
  if (len > gmin) {
    grassMaker(len * 0.8, theta * 1.1);
  }
  layerB.pop();
}

function branchMaker(len, rkeep) {
  let swMax = 16;
  let swMin = floor(swMax * 0.25) + 1;
  let swAlpha = 255;
  let bmaxLen = height * 0.2;
  let bminLen = bmaxLen * 0.1;
  push();
  strokeCap(SQUARE);
  translate(0, 0);
  let rot = random(-PI * 0.05, PI * 0.05);
  rotate(rot);
  rkeep += rot;
  let sw = map(len, bminLen, bmaxLen, swMin, swMax);

  for (let y = 0; y < len * 1.01; y++) {
    let x = map(y, 0, len, sw, sw * 0.8);
    let col = map(x, bminLen, 1, 255, 50);
    colKeep = col;
    push();
    translate(random(-1, 1), -y);
    strokeWeight(2);
    stroke(col, 255);
    line(-x, 0, x, 0);

    stroke(col * random(0.8, 1) + random(25), 255);
    line(-x, 0, -x * 0.32, 0);
    stroke(col * random(0.6, 0.8) + random(25), 255);
    line(-x * 0.32, 0, x * 0.32, 0);
    stroke(col * random(0.4, 0.6) + random(25), 255);
    line(x * 0.32, 0, x, 0);
    stroke(random(25, 75), 255);
    strokeWeight(1);
    point(-x - 1, 0);
    strokeWeight(2);
    point(x + 2, 0);

    if (random() < 0.001) {
      push();
      strokeCap(SQUARE);
      translate(0, 0);
      let rot = random(-PI * 0.05, PI * 0.05);
      rotate(rot);
      rkeep += rot;
      let sw = map(len, bminLen, bmaxLen, swMin, swMax);

      for (let y = 0; y < len * 1.01; y++) {
        let x = map(y, 0, len, sw, sw * 0.8);
        let col = map(x, bminLen, 1, 255, 50);
        colKeep = col;
        push();
        translate(random(-1, 1), -y);
        strokeWeight(2);
        stroke(col, 255);
        line(-x, 0, x, 0);

        stroke(col * random(0.8, 1) + random(25), 255);
        line(-x, 0, -x * 0.32, 0);
        stroke(col * random(0.6, 0.8) + random(25), 255);
        line(-x * 0.32, 0, x * 0.32, 0);
        stroke(col * random(0.4, 0.6) + random(25), 255);
        line(x * 0.32, 0, x, 0);
        stroke(random(25, 75), 255);
        strokeWeight(1);
        point(-x - 1, 0);
        strokeWeight(2);
        point(x + 2, 0);

        pop();
      }
      for (let fn = 0; fn < 5; fn++) {
        if (random() < 0.5) {
          push();
          translate(random(-sw * 1.5, sw * 1.5), random(-len, 0));
          flowerMaker(bminLen * random(0.1, 0.25));
          pop();
        }
        if (random() < 0.2 && len > bmaxLen * 0.6) {
          let mushDense = floor(random(2, 8));
          for (let mnm = 0; mnm < mushDense; mnm++) {
            push();
            translate(0, 0);
            mushroom(height * random(0.02, 0.03));
            pop();
          }
        }
      }
      if (random() < 0.5) {
        translate(0, -len);
      } else {
        translate(0, random(-len * 0.6, -len));
      }
      if (len > bminLen) {
        branchMaker(len * 0.8, rkeep);
      }
      pop();
    }

    pop();
  }
  for (let fn = 0; fn < 5; fn++) {
    if (random() < 0.3) {
      push();
      translate(random(-sw * 1.5, sw * 1.5), random(-len, 0));
      flowerMaker(bminLen * random(0.1, 0.25));
      pop();
    }
    if (random() < 0.32 && len > bmaxLen * 0.6) {
      let mushDense = floor(random(2, 8));
      for (let mnm = 0; mnm < mushDense; mnm++) {
        push();
        translate(0, 0);
        mushroom(height * random(0.02, 0.03));
        pop();
      }
    }
  }
  if (random() < 0.5) {
    translate(0, -len);
  } else {
    translate(0, random(-len * 0.6, -len));
  }
  if (len > bminLen) {
    branchMaker(len * 0.8, rkeep);
  }
  pop();
}

function flowerMaker(z) {
  /// mushrooms
  let theta = random(-PI * 0.1, PI * 0.1);
  for (let n = 0; n < 6; n++) {
    push();
    translate(random(-z, z), random(-z, z));
    rotate(theta);
    let xZmod = random(3, 5);
    let yZmod = random(0.6, 1);
    noStroke();
    fill(strokeR, strokeG, strokeB, 255);
    arc(0, -z * yZmod * 0.25, z * xZmod, z * yZmod, -PI, 0);
    fill(strokeR * 0.25, strokeG * 0.25, strokeB * 0.25, 255);
    arc(0, z * yZmod * 0.25, z * xZmod, z * yZmod, -PI, 0);
    pop();
  }
}

function backgroundMaker() {
  colMaker(colMakerSet);
  background(fillR * 1.1, fillG * 1.1, fillB * 1.1, 255);
  push();
  translate(width * 0.5, height * 0.5);
  rotate(random(TAU));
  for (let y = -height * 0.8; y < height * 0.8; y += 3) {
    let alph = map(y, -height * 0.8, height * 0.8, 0, 255);
    push();
    stroke(strokeR, strokeG, strokeB, alph);
    strokeWeight(5);
    line(-width * 0.2, y, width * 1.2, y);
    pop();
  }
  pop();
  lineMaker(random(TAU));
  push();
  translate(width * 0.5, height * 0.5);
  rotate(random(TAU));
  pop();
}

function lineMaker(rotSet) {
  for (let y = -height * 1.25; y < height * 1.25; y += 15) {
    push();
    translate(width * 0.5, height * 0.5);
    rotate(rotSet);
    stroke(strokeR * 0.25, strokeG * 0.25, strokeB * 0.25, 255);
    strokeWeight(3);
    fill(fillR, fillG, fillB, 32);
    let xc =
      cos(y * sin(frameCount * 0.0001)) *
      (width * sin(frameCount * 0.01) * 0.5);
    let yc =
      sin(y * cos(frameCount * 0.0001)) *
      (height * cos(frameCount * 0.01) * 0.5);
    bezier(-width + xc, y + yc, width, y, -width, y, width - xc, y - yc);
    pop();
  }
}

function newTree(zSet) {
  let tmaxLen = zSet;
  tmaxLen *= random(0.12, 0.16);
  push();
  translate(0, 0);
  treeMaker(tmaxLen, tmaxLen);
  tmaxLen = height;
  tmaxLen *= random(0.12, 0.2);
  treeMaker(tmaxLen, tmaxLen);
  pop();
}

function treeMaker(len, max) {
  let tmax = max;
  let tmin = tmax * 0.2;

  //// First Branch -- MAIN
  push();
  translate(0, 0);
  rotate(random(-PI * 0.1, PI * 0.1));
  let sw = map(len, tmin, tmax, 1, tmin * 0.5);
  for (let y = 0; y < len * 1.01; y++) {
    let x = map(y, 0, len, sw, sw * 0.8);
    let col = map(x, tmin * 0.5, 1, 255, 50);
    colKeep = col;
    push();
    translate(random(-1, 1), -y);
    strokeWeight(2);
    stroke(col, 255);
    line(-x, 0, x, 0);

    if (random() < 0.5) {
      stroke(col * random(0.8, 1) + random(25), 255);
      line(-x, 0, -x * 0.32, 0);
    }
    if (random() < 0.5) {
      stroke(col * random(0.6, 0.8) + random(25), 255);
      line(-x * 0.32, 0, x * 0.32, 0);
    }
    if (random() < 0.5) {
      stroke(col * random(0.4, 0.6) + random(25), 255);
      line(x * 0.32, 0, x, 0);
    }

    if (noise(len, y * 0.1) < 0.5) {
      stroke(random(25, 75), 255);
      point(-x - 2, 0);
      point(x + 2, 0);
    }
    ////Sub Branch
    if (random() < 0.005) {
      push();
      translate(0, 0);
      rotate(random(-PI * 0.1, PI * 0.1));
      let sw = map(len, tmin, tmax, 1, tmin * 0.5);
      for (let y = 0; y < len * 1.01; y++) {
        let x = map(y, 0, len, sw, sw * 0.8);
        let col = map(x, tmin * 0.5, 1, 255, 50);
        colKeep = col;
        push();
        translate(random(-1, 1), -y);
        strokeWeight(2);
        stroke(col, 255);
        line(-x, 0, x, 0);
        if (random() < 0.5) {
          stroke(col * random(0.8, 1) + random(25), 255);
          line(-x, 0, -x * 0.32, 0);
        }
        if (random() < 0.5) {
          stroke(col * random(0.6, 0.8) + random(25), 255);
          line(-x * 0.32, 0, x * 0.32, 0);
        }
        if (random() < 0.5) {
          stroke(col * random(0.4, 0.6) + random(25), 255);
          line(x * 0.32, 0, x, 0);
        }
        if (noise(len, y * 0.1) < 0.5) {
          stroke(random(25, 75), 255);
          point(-x - 2, 0);
          point(x + 2, 0);
        }
        pop();
      }
      translate(0, -len);
      if (random() < 0.1) {
        len *= 0.2;
      }
      if (len > tmin) {
        treeMaker(len * 0.8, tmax, tmin);
      }
      pop();
    }

    pop();
  }
  translate(0, -len);
  if (len > tmin) {
    treeMaker(len * 0.8, tmax, tmin);
  }
  if (len < tmax * 0.6) {
    if (random() < 0.5) {
      stickMaker(tmax * 0.25, tmax);
    }
  }
  pop();

  if (random() < 0.1) {
    //// Second Set - First Branch -- MAIN
    push();
    translate(0, 0);
    rotate(random(-PI * 0.2, PI * 0.14));
    let sw = map(len, tmin, tmax, 1, tmin * 0.5);
    for (let y = 0; y < len * 1.01; y++) {
      let x = map(y, 0, len, sw, sw * 0.8);
      let col = map(x, tmin * 0.5, 1, 255, 50);
      colKeep = col;
      push();
      translate(random(-1, 1), -y);
      stroke(col * random(0.8, 1), 255);
      strokeWeight(2);
      stroke(col, 255);
      line(-x, 0, x, 0);
      if (random() < 0.5) {
        stroke(col * random(0.8, 1) + random(25), 255);
        line(-x, 0, -x * 0.32, 0);
      }
      if (random() < 0.5) {
        stroke(col * random(0.6, 0.8) + random(25), 255);
        line(-x * 0.32, 0, x * 0.32, 0);
      }
      if (random() < 0.5) {
        stroke(col * random(0.4, 0.6) + random(25), 255);
        line(x * 0.32, 0, x, 0);
      }
      if (noise(len, y * 0.1) < 0.5) {
        stroke(random(25, 75), 255);
        point(-x - 2, 0);
        point(x + 2, 0);
      }

      ////Second Set - Sub Branch
      if (random() < 0.005) {
        push();
        translate(0, 0);
        rotate(random(-PI * 0.14, PI * 0.2));
        let sw = map(len, tmin, tmax, 1, tmin * 0.5);
        for (let y = 0; y < len * 1.01; y++) {
          let x = map(y, 0, len, sw, sw * 0.8);
          let col = map(x, tmin * 0.5, 1, 255, 50);
          colKeep = col;
          push();
          translate(random(-1, 1), -y);
          strokeWeight(2);
          stroke(col, 255);
          line(-x, 0, x, 0);
          if (random() < 0.5) {
            stroke(col * random(0.8, 1) + random(25), 255);
            line(-x, 0, -x * 0.32, 0);
          }
          if (random() < 0.5) {
            stroke(col * random(0.6, 0.8) + random(25), 255);
            line(-x * 0.32, 0, x * 0.32, 0);
          }
          if (random() < 0.5) {
            stroke(col * random(0.4, 0.6) + random(25), 255);
            line(x * 0.32, 0, x, 0);
          }

          if (noise(len * 0.5, y * 0.1) < 0.5) {
            stroke(random(25, 75), 255);
            point(-x - 2, 0);
            point(x + 2, 0);
          }
          pop();
        }
        translate(0, -len);
        if (random() < 0.1) {
          len *= 0.2;
        }
        if (len > tmin) {
          treeMaker(len * 0.8, tmax, tmin);
        }
        if (len < tmax * 0.6) {
          if (random() < 0.5) {
            stickMaker(tmax * 0.25, tmax);
          }
        }
        pop();
      }

      pop();
    }
    translate(0, -len);
    if (len > tmin) {
      treeMaker(len * 0.8, tmax, tmin);
    }
    if (len < tmax * 0.6) {
      if (random() < 0.5) {
        stickMaker(tmax * 0.25, tmax);
      }
    }
    pop();
  }
}

function stickMaker(len, maxi) {
  let smax = maxi;
  push();
  translate(0, 0);
  rotate(random(-PI * 0.2, PI * 0.2));
  strokeWeight(3);
  stroke(50, 255);
  line(0, 0, 0, -len);
  if (random() < 0.5) {
    push();
    translate(0, random(-len));
    if (leafYes) {
      leafMaker(smax);
    }
    pop();
  }
  translate(0, -len);
  if (len > 2) {
    stickMaker(len * 0.75, smax);
  }
  pop();
}

function leafMaker(len) {
  let leafDense = floor(random(1, 6));
  for (let n = 0; n < leafDense; n++) {
    let z = createVector(random(0.5, 1), random(0.25, 0.5));
    let pos = createVector(random(-1, 1), random(-1, 1));
    let m = random(10);
    pos.mult(m);
    let col = map(pos.y, -m, m, 255, 25);
    z.mult(25);

    push();
    translate(pos.x, pos.y);
    rotate(random(TAU));
    beginShape();
    vertex(0, 0);
    bezierVertex(z.x, z.y, z.x, -z.y, -z.x, -z.y);
    let frnd = random(0.6, 1.1);
    fill(
      colKeep + fillR * frnd,
      colKeep + fillG * frnd,
      colKeep + fillB * frnd
    );
    noStroke();
    endShape();

    beginShape();
    vertex(0, 0);
    bezierVertex(z.x, z.y, -z.x, z.y, -z.x, -z.y);
    frnd = random(0.6, 1.1);
    fill(
      colKeep + fillR * frnd,
      colKeep + fillG * frnd,
      colKeep + fillB * frnd
    );
    noStroke();
    endShape();
    strokeWeight(1);
    line(-z.x, -z.y, z.x * 0.25, z.y * 0.25);
    pop();
  }
}

function buildMound() {
  let z = height * random(0.25, 0.32);
  let gap = TAU * 0.01;

  for (let r = -HALF_PI; r > -PI - gap; r -= gap) {
    let y = sin(r) * z;

    for (let rLoop = 0; rLoop < 2; rLoop++) {
      let x = random(cos(r) * (z * 2), r);
      push();
      translate(x, y);
      rock.update();
      rock.show();
      pop();
      x = random(cos(r) * (z * 2), r);
      push();
      translate(x * -1, y);
      rock.update();
      rock.show();
      pop();
    }
  }
}

function rockMaker() {
  let heightSet = 100;
  this.gap = PI * 0.1;
  this.startgap = this.gap;
  this.xoff = random(10000);
  this.yoff = random(10000);
  this.zoff = random(10000);
  this.sizex = heightSet * 0.4;
  this.startx = this.sizex;
  this.sizey = heightSet * random(0.2, 0.9);
  this.starty = this.sizey;

  this.update = function () {
    layerC = createGraphics(100, 100);
    this.sizey = heightSet * random(0.2, 0.9);
    this.starty = this.sizey;
    layerC.push();
    layerC.translate(heightSet * 0.5, heightSet * 1.1);
    this.xoff = random(10000);
    this.yoff = random(10000);
    this.zoff = random(10000);
    for (let n = 0; n < 3; n++) {
      this.gap = PI * map(noise(frameCount * 0.1), 0, 1, 0.01, 0.1);
      layerC.beginShape();

      for (let theta = -PI; theta < PI; theta += this.gap) {
        let x = cos(theta) * this.sizex;
        let y = sin(theta) * this.sizey;
        let xmod = 0;
        let ymod = -this.gap;
        if (theta > -PI) {
          xmod = map(
            noise(this.xoff, theta, frameCount * 0.05),
            0,
            1,
            -this.sizex * 0.4,
            this.sizex * 0.4
          );
          ymod = map(
            noise(this.yoff, theta, frameCount * 0.05),
            0,
            1,
            -this.sizey * 0.4,
            this.sizey * 0.4
          );
        }
        let shorten = random(0.2, 0.4);
        if (theta > -PI * (n * 0.32)) {
          this.sizex *= 1 - n * 0.1;
        }
        layerC.vertex(x + xmod, y + ymod);
      }
      colMaker(colMakerSet);
      let colr = fillR * (n * 0.3 + 0.1);
      let colg = fillG * (n * 0.3 + 0.1);
      let colb = fillB * (n * 0.3 + 0.1);
      layerC.fill(colr, colg, colb, 255);
      layerC.stroke(strokeR, strokeG, strokeB, 255);
      layerC.strokeWeight(3);
      layerC.noStroke();
      layerC.endShape();
      this.sizex = this.startx;
    }
    layerC.pop();
  };

  this.show = function () {
    let getLayerC = layerC.get();
    getLayerC.resize(layerC.width * 2, 0);
    layerC = createGraphics(getLayerC.width, getLayerC.height);
    // layerC.filter(BLUR, 2);
    layerC.image(getLayerC, 0, 0);
    push();
    translate(0, 0);
    image(layerC, 0, 0);
    translate(0, layerC.height * 0.5);
    let tgDense = floor(random(1, 3));
    for (let tgn = 0; tgn < tgDense; tgn++) {
      push();
      translate(random(-layerC.width * 0.5, layerC.height * 0.5), 0);
      tgmaxLen = height * random(0.01, 0.05);
      tgminLen = tgmaxLen * 0.2;
      tallgrass(tgmaxLen, random(-PI * 0.02, PI * 0.02));
      pop();
    }
    pop();
  };
}

function tallgrass(len, theta) {
  push();
  translate(0, 0);
  rotate(theta);
  let sw = map(len, tgminLen, tgmaxLen, 1, 10);
  stroke(fillR, fillG, fillB, 255);
  strokeWeight(sw);
  line(0, 0, 0, -len);
  if (len < tgminLen * 1.5) {
    for (let y = 0; y < len; y++) {
      let col = random(0.25, 1);
      stroke(fillR * col, fillG * col, fillB * col, 255);
      strokeWeight(random(2));
      push();
      translate(0, 0);
      rotate(random(-PI * 0.1, PI * 0.1));
      line(-len * random(0.5, 0.7), y, len * random(0.5, 0.7), y);
      pop();
    }
  }
  translate(0, -len);
  if (len > tgminLen) {
    tallgrass(len * 0.9, theta * 0.99);
  }
  pop();
}

function colMaker(n) {
  let sr = random(255);
  let sg = random(255);
  let sb = random(255);
  let fr = random(255);
  let fg = random(255);
  let fb = random(255);
  if (n === 0) {
    //Grays
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * 2;
    sb = 255 * pick * 2;
    fr = 255 * pick;
    fg = 255 * pick;
    fb = 255 * pick;
  }
  if (n === 1) {
    // Yellow and Purple
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * 2;
    sb = 0;
    fr = 255 * pick;
    fg = 0;
    fb = 255 * pick;
  }
  if (n === 2) {
    // Orange and Green
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick;
    sb = 0;
    fr = 25 * pick;
    fg = 255 * pick;
    fb = 25 * pick;
  }
  if (n === 3) {
    // Red and Gray
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 0;
    sb = 0;
    fr = 255 * pick;
    fg = 255 * pick;
    fb = 255 * pick;
  }
  if (n === 4) {
    // Sky Blue and Orange
    let pick = random(0.5);
    sr = 0;
    sg = 128 * pick * 2;
    sb = 255 * pick * 2;
    fr = 255 * pick * 2;
    fg = 255 * pick;
    fb = 0;
  }
  if (n === 5) {
    // Orange and Sapphire
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * random(1.6);
    sb = 0;
    fr = 0;
    fg = 255 * pick * 2;
    fb = 255 * pick * 2;
  }
  if (n === 6) {
    // Dark Green and Sapphire
    let pick = random(0.5);
    sr = 0;
    sg = 255 * pick * 2;
    sb = 255 * pick * 2;
    fr = 0;
    fg = 128 * pick * 2;
    fb = 0;
  }

  if (n === 7) {
    // Gray and Pink
    let pick = random(0.5);
    sr = 128 * pick;
    sg = 128 * pick;
    sb = 128 * pick;
    fr = 255 * pick * 2;
    fg = 200 * pick * 2;
    fb = 200 * pick * 2;
  }
  if (n === 8) {
    // Yellow and Orange
    let pick = random(0.5);
    sr = 255 * pick;
    sg = 255 * pick;
    sb = 0;
    fr = 255 * pick * 2;
    fg = 255 * pick * random(1.6);
    fb = 0;
  }
  if (n === 9) {
    // Blue and Gray
    let pick = random(0.5);
    sr = 0;
    sg = 255 * pick;
    sb = 255 * pick;
    fr = 255 * pick * 2;
    fg = 255 * pick * 2;
    fb = 255 * pick * 2;
  }
  if (n === 10) {
    // Moss Green / Smoke Green
    let pick = random(0.5);
    sr = 255 * pick;
    sg = 255 * pick * 2;
    sb = 255 * pick;
    fr = 200 * pick * 2;
    fg = 255 * pick * 2;
    fb = 200 * pick * 2;
  }
  if (n === 11) {
    // Cream Yellow / Dark Purple
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * 2;
    sb = 200 * pick;
    fr = 225 * pick;
    fg = 200 * pick;
    fb = 200 * pick * 2;
  }
  if (n === 12) {
    // Dark Red and Red
    let pick = random(0.5);
    sr = 255 * pick;
    sg = 0;
    sb = 0;
    fr = 225 * pick * 2;
    fg = 0;
    fb = 0;
  }
  if (n === 13) {
    // Dark Blue and Sky Blue
    let pick = random(0.5);
    sr = 0;
    sg = 0;
    sb = 128 * pick;
    fr = 200 * pick;
    fg = 200 * pick;
    fb = 255 * pick * 2;
  }
  if (n === 14) {
    // Dark Green and Bright Green
    let pick = random(0.5);
    sr = 0;
    sg = 128 * pick;
    sb = 0;
    fr = 200 * pick;
    fg = 255 * pick * 2;
    fb = 200 * pick;
  }

  fillR = fr;
  fillG = fg;
  fillB = fb;
  strokeR = sr;
  strokeG = sg;
  strokeB = sb;
}

function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

function keyPressed() {
  if (key === " ") {
    loop();
    stopOff = 1;
  }
  if (keyCode === DOWN_ARROW) {
    createCanvas(saveLayer.width, saveLayer.height);
    noTint();
    image(saveLayer, width * 0.5, height * 0.5);
    let getImg = get();
    getImg.resize(2000, 2000);
    createCanvas(2000, 2000);
    image(getImg, width * 0.5, height * 0.5);
    saveCanvas("ed_cavett_naturesVanity", "png");
    createCanvas(1550, 800);
    loop();
    stopOff = 1;
  }
  if (keyCode === UP_ARROW) {
    saveCanvas("ed_cavett_naturesVanityAF", "png");
    loop();
    stopOff = 1;
  }
  if (key === "b" || key === "B") {
    let getImg = saveLayer.get();
    getImg.filter(GRAY);
    createCanvas(2000, 2000);
    getImg.resize(width, height);
    noTint();
    image(getImg, width * 0.5, height * 0.5);
    saveCanvas("ed_cavett_naturesVanity_B", "png");
    createCanvas(1550, 800);
    loop();
    stopOff = 1;
  }
  if (key === "p" || key === "P") {
    let getImg = saveLayer.get();
    getImg.filter(POSTERIZE, 4);
    createCanvas(2000, 2000);
    getImg.resize(width, height);
    noTint();
    image(getImg, width * 0.5, height * 0.5);
    saveCanvas("ed_cavett_naturesVanity_P", "png");
    createCanvas(1550, 800);
    loop();
    stopOff = 1;
  }
  if (key === "t" || key === "T") {
    createCanvas(2000, 2000);
    if (key === "t") {
      background(255, 255);
    } else {
      background(0, 255);
    }
    treeKeep.resize(width, height);
    noTint();
    image(treeKeep, width * 0.5, height * 0.5);
    saveCanvas("ed_cavett_naturesVanity_D", "png");
    createCanvas(1550, 800);
    loop();
    stopOff = 1;
  }
}
