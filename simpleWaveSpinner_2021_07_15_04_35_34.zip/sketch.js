let arm = [];
let popu = 6;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  for (let i = 0; i < popu; i++){
    arm.push(new waveMaker());
  }


}

function draw() {
  background(0,0);
  for (let i = 0; i < arm.length; i++){
    arm[i].update(i);
  }
}


function waveMaker(){
  this.size = 5;
  this.yoff = 0;
  this.roff = 0;
  
  this.update = function(_i){
    this.roff += 0.01;
    let xoff = 0;
    let yoff = this.yoff;
    push();
    translate(width/2,height/2);
    rotate(this.roff+_i);
    strokeWeight(2);
    beginShape();
    vertex(0,0);
    for (let x = 0; x < height; x += this.size){
      let colr = map( noise(xoff,this.roff),0,1,
                      -45,300);
    stroke(colr,colr-50,0,225);
    fill(0,255-colr-50,200-colr-50,125);
      let y = map( noise(xoff,yoff),0,1,
                  -this.size*8,this.size*8);
      vertex(x,y);
      let v2size = map(noise(this.roff),0,1,
                       1,6);
      vertex(x+this.size,y*v2size);
      // point(x,y);
      // point(y,x);
      xoff += 0.05;
    }
    this.yoff += 0.01;
    endShape();
    pop();
  }
}



/// Click to Go Fullscreen
function mousePressed() {
  if (mouseX > 0 &&
    mouseX < width &&
    mouseY > height / 2 &&
    mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}









