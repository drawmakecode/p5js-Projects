//// Procedural Art
//// "Homogeny" by Ed Cavett
//// May, 2021
//// Public version - free to copy/distribute.


//// Create objects that move
//// around the canvas and
//// interact by changing colors.

//// 


let heading = [];
let popu = 24;
let r = 75;
let sw = [];
let swmax = 32;
let colr = [];

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  // createCanvas(5120,2880);
  // createCanvas(2560,1440);
  
  for (let i = 0; i < popu; i++) {
    heading.push(new mover(0.005,0.005));
    colr.push(new colorer(i));
    sw.push(0);
  } 
  background(50,25,5,255);
}

function draw() {
  background(0,255);
  for (let i = 0; i < heading.length; i++) {
    heading[i].update();
    let xh = heading[i].x;
    let yh = heading[i].y;    

    for (let ii = 0; ii < heading.length; ii++) {
      let xht = heading[ii].x;
      let yht = heading[ii].y;
      let d = dist(xh,yh,xht,yht);
      if (d < swmax && i !== ii) {
        let ran = random(1);
        if (ran < 0.25) {
          /// make both the same color
          /// depending on comparison order
          colr[ii].r = colr[i].r;
          colr[ii].g = colr[i].g;
          colr[ii].b = colr[i].b;
        } else if (ran > 0.75) {
          /// make both the average of their
          /// color.
          let rtemp = (colr[i].r+colr[ii].r)*0.5;
          let gtemp = (colr[i].g+colr[ii].g)*0.5;
          let btemp = (colr[i].b+colr[ii].b)*0.5;
          colr[i].r = rtemp;
          colr[i].g = gtemp;
          colr[i].b = btemp;
          // colr[ii].r = colr[i].r;
          // colr[ii].g = colr[i].g;
          // colr[ii].b = colr[i].b;
        } else {
          if (random(1) < 0.001){
            /// small chance of spontaneous color
            /// regeneration.
          colr[i].r = random(50,255);
          colr[i].g = random(50,255);
          colr[i].b = random(50,255);
          colr[ii].r = random(50,255);
          colr[ii].g = random(50,255);
          colr[ii].b = random(50,255);
          }
        }
      }
      if (d < r && i !== ii) {
        sw[i] = map(d,0,r,swmax,1);
        sw[ii] = map(d,0,r,swmax,1);
        strokeWeight(sw[ii]);
        stroke(colr[i].r,
               colr[i].g,
               colr[i].b,
               128);
        line(xh,yh,xht,yht);
        stroke(colr[ii].r,
               colr[ii].g,
               colr[ii].b,
               128);
        line(xh,yh,xht,yht);
        strokeWeight(swmax*1.1-sw[i]);
        stroke(colr[i].r,
           colr[i].g,
           colr[i].b,
           255);
        point(xh,yh);

      }
    }
  noFill();  
  // strokeWeight(swmax*1.1-sw[i]);
  strokeWeight(5);
    stroke(colr[i].r,
         colr[i].g,
         colr[i].b,
         255);
  ellipse(xh,yh,swmax*1.1-sw[i]);
  }
}

function mover(r,s) {
  this.x = random(width);
  this.y = random(height);
  this.xl = random(width);
  this.yl = random(height);
  this.rate = r;
  this.speed = s;
  
  this.update = function(){
    if (random(1) < this.rate) {
      this.xl = random(width);
      this.yl = random(height);
    }
    this.x = lerp(this.x,this.xl,this.speed);
    this.y = lerp(this.y,this.yl,this.speed);
  }
  
  
}



function colorer(i){
  this.r = random(50,255);
  this.g = random(50,255);
  this.b = random(50,255);

}









//// end of sketch