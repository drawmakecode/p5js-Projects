let xoff;
let yoff;



function setup() {
  createCanvas(windowWidth,
               windowHeight);
  xoff  = random(10);
  yoff  = random(10);
}

function draw() {
  background(0,100,125,255);
  // let x = winMouseX;
  // let y = winMouseY;
  xoff += 0.01;
  yoff += 0.01;
  
  let x = noise(xoff)*width;
  let y = noise(yoff)*height;
  
  let cx = width/2;
  let cy = height/2;
  
  let hoff = 10;
  let shadow = 2;
  
  let hx = map(x,0,width,-hoff,hoff);
  let hy = map(y,0,height,-hoff,hoff);
  
  let sx = map(x,0,width,hoff*shadow,-hoff*shadow);
  let sy = map(y,0,height,hoff*shadow,-hoff*shadow);
  
  let word = 'Draw Make Code';
  
  textSize(100);
  textAlign(CENTER,CENTER);
  
  push();
  noStroke();
  /// shadow
  fill(0,20,50,255);
  text(word,cx+sx,cy+sy);
  /// highlight
  fill(0,220,255,255);
  text(word,cx+hx,cy+hy);
  /// primary shape
  fill(0,0,0,255);
  text(word,cx,cy);
  pop();
  
  stroke(255,255);
  strokeWeight(1);
  fill(255,25);
  let d = height/2; //dist(x,y,cx,cy);
  circle(sx+cx,sy+cy,d*2);

}
















/// end of sketch