/// Jacob's Ladder
/// Electric Toy Animation
/// by Ed Cavett
/// December 2021


let ladder = [];

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  for (let i = 0; i < 3; i++) {
    ladder.push(new ladderMaker());
  }
}

function draw() {
  background(0,128);
  for (let i = 0; i < ladder.length; i++) {
    ladder[i].update();
  }
}


function ladderMaker(){
  this.xoff = 0;
  this.yoff = random(100);
  this.step = 10;
  this.range = height*0.1;
  this.left = width/2-(width*0.1);
  this.right = width/2+(width*0.1);
  this.start = height*0.99;
  this.end = height*0.2+this.range;
  this.rise = 1;
  this.locate = random(this.end,
                       this.start);
  
  this.update = function() {
  
    this.locate -= this.rise;
    this.rise += 0.25;
    if (this.locate < this.end) {
      this.locate = this.start;
      this.rise = 2;
      this.step = 10;
    }
    push();
    strokeWeight(8);
    stroke(75,255);
    line(width/2-(width*0.02),height,
         width/2-(width*0.07),height*0.2);
    line(width/2+(width*0.02),height,
         width/2+(width*0.07),height*0.2);
    pop();
    push();
    this.xoff = 0;
    beginShape();
    this.left = map(this.locate,this.start,this.end,
                    width/2-(width*0.02),
                    width/2-(width*0.07));
    this.right = map(this.locate,this.start,this.end,
                    width/2+(width*0.02),
                    width/2+(width*0.07));
    this.step = map(this.locate,this.start,this.end,
                    10,2);
    
    
    for (let x = this.left; x < this.right; x+= this.step) {
      let y = map(noise(this.xoff,this.yoff,
                        frameCount*0.025),0,1,
                  -this.range,this.range);
      vertex(x,y+this.locate);
      this.xoff += 0.075;
    }
    this.yoff += 0.075;
    let thick = map(this.locate,this.start,this.end,
                    8,1);
    stroke(0,175,255,255);
    strokeWeight(thick);
    if (random() < 0.2) {
      stroke(255,255);
      strokeWeight(thick*0.5);
    }
    noFill();
    endShape();
    pop();
  }
}


