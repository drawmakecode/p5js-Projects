/// Move To Process Structure
/// "Lurch and Halting"
/// by Ed Cavett
/// October 2021
///
/// Featured in One Minute Tips
/// from Draw, Make & Code.

//// This program combines cartesian vectors
//// with linear interpolated vectors to
//// move points toward the center of 
//// the canvas.  For cartesian vectors,
//// tests determine the
//// required direction of movement to
//// reach the center, and applies a constant
//// velocity.  The results define a linear
//// movement response.
//// With radial vectors, a lerp function is used
//// to direct and move points toward the center
//// using radial adjustments.
//// Using a random determination, a choice
//// between these two styles of movement
//// is performed.  The end result is a 
//// strange, "crowded" movement style I call
//// "Lurch and Halting".


/// Declare a variable to hold the particle
/// system given to it as a single object.
let ghostMatter;

function setup() {
  createCanvas(windowWidth,
               windowHeight);
  /// Assign to the variable a new instance
  /// of the matterMaker function.  This function
  /// contains the entire particle system and
  /// generates its output.
  ghostMatter = new matterMaker();
}

function draw() {
  background(200,255,200,255);
  
  /// Execute and receive the output
  /// for the ghostMatter object.
  ghostMatter.update();
}

/// This function returns the output for a
/// particle system that is animated by movers 
/// two different styles.  Those styles are
/// randomly combined to create a third
/// mover style.
function matterMaker(){
  
  /// Use and array of vectors to represent
  /// the particle system that will be
  /// arranged in a grid to start.
  this.pos = [];
  this.vel = [];

  /// Provide a set of points by assigning
  /// proportions of the canvas to columns
  /// and rows.
  let col = width/15;
  let row = height/15;
  
  /// Loop through the real positions
  /// in the center of each portion of the
  /// canvas.  Give that to the array positions.
  /// Set the initial velocity to zero.
  for (let k = row; k < height; k+= row) {
    for (let j = col; j < width; j+= col) {
      this.pos.push(createVector(j,k));
      this.vel.push(createVector(0,0));
    }
  }

  /// When executed, this method determines
  /// the movement style, calculates new
  /// positions, and generates the output for
  /// the entire particle system.
  this.update = function(){
    
    /// Set some easy variables to the find
    /// the center of the canvas.
    let cx = width/2;
    let cy = height/2;
    
    /// Loop through the arrays and change
    /// their positions accordingly.
    for (let i = 0; i < this.pos.length; i++) {
      
      /// Set some easy variables to find
      /// the current point coordiantes.
      let px = this.pos[i].x;
      let py = this.pos[i].y;
      
      /// Determine with a coin-flip to move
      /// in either of the two styles.
      if (random() < 0.5) {
        
        /// Style One -- Linear Interpolation
        ///              Radial Vectors
        /// This procedure finds a new position
        /// for the current particle by comparing
        /// it's current position to a desired
        /// position and moves it a proportional
        /// amount in a radial vector toward that
        /// desired position.
      this.pos[i].x = lerp(px,cx,0.05);
      this.pos[i].y = lerp(py,cy,0.05);
      } else {
        
        /// Style Two -- Constant Velocity
        ///              Cartesian Vectors
        /// This procedure tests the current
        /// position for its relationship to
        /// the desired position.  If the desired
        /// position is positively located 
        /// relative to the current position,
        /// the new position will step positively
        /// using a constant.  This is reversed
        /// when the desired location is negatively
        /// positioned relative to the current
        /// position.  This is performed for both
        /// the x and y independently.
        if (px < cx) {
          this.pos[i].x += 1;
        } else {
          this.pos[i].x -= 1;
        }
        if (py < cy) {
          this.pos[i].y += 1;
        } else {
          this.pos[i].y -= 1;
        }
      }
      
      /// Output the result of the current particle.
      push();
      stroke(0,0,0,255);
      strokeWeight(3);
      fill(0,125,0,100);
      translate(this.pos[i].x,
                this.pos[i].y);
      ellipse(0,0,25,25);
      pop();
    }
  }
}


