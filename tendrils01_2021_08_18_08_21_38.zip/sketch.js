/// Recursive Tendrils
/// Mandala Maker
/// in p5.js
/// by Ed Cavett
/// August 2021

/// For more about the code,
/// check out the video that accompanies
/// this code at youtube.com/drawmakecode
/// https://www.youtube.com/watch?v=3m6i4r3ttmY

/// Updated to fix missing arguments.
/// The update method receives two arguments.
/// One for the size and one for the tendril id.

let arms = [];
let dense = 20;

function setup() {
	createCanvas(windowWidth, windowHeight)
	for (let i = 0; i < dense; i++){
		arms.push(new chain());
		
	}
}

function draw() {
	background(255,255);
	ellipse(width/2,height/2,200,200);
	for (let i = 0; i < dense; i++){
		push();
		translate(width/2,height/2);
		rotate(PI*(i*0.1));
		point(0,0);
		push();
		arms[i].xoff = 0;
      
      /// Be sure to include two arguments in the 
      /// method call.
		arms[i].update(100,i);
		pop();
		pop();	
	}
	
}



function chain(){
	this.xoff = random(100);
	this.yoff = random(100);
	this.theta = 0;
	this.sw = 0;
	this.colr = 0;

  /// Be sure to include two arguments in the 
  /// method assignment.
	this.update = function(size,_i){
		this.xoff += 0.1;
		this.theta = map(noise(this.xoff,this.yoff),0,1,
							-PI,PI);
		stroke(0,255);
		this.sw = map(size,100,1,25,2);
		strokeWeight(this.sw);
		if (size < 95) {
		line(0,0,size,0);
		}
		translate(size,0);
		rotate(this.theta);
		if (size > 1) {
          
          /// Be sure to use two arguments in the
          /// method call.
			this.update(size*0.8,_i);
			this.yoff += 0.0005;
		}
	}
	
}








