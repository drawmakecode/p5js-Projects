/// Halloween Spiders
/// Version 3
/// in p5.js
/// by Ed Cavett
/// October 2021


let spider = [];
let shigh;
let quant = 11;

function setup() {
  createCanvas(windowWidth,900);
  for (let i = 0; i < quant; i++) {
    spider.push(new spiderMaker(i+1));
  }
  background(255,255);
}

function draw() {
  let bcolr = map(cos(frameCount*0.001),-1,1,
                  0,255);
  let bcolg = map(sin(frameCount*0.001),-1,1,
                  255,0);
  background(bcolr,bcolg,75,255);
  for (let i = 0; i < spider.length; i++) {
    shigh = map(sin(spider[i].dropRate*
                    (frameCount*0.0025)),
                -1,1,-height*0.09,height*0.85);
    /// Check spider's position and reset location
    /// and size when it's above the canvas.
    if (shigh < -(spider[i].scale*2)) {
      spider[i].x = random(width);
      spider[i].scale = height*random(0.01,0.03);
      spider[i].style = floor(random(2));
      spider[i].longer = random(spider[i].scale*0.5);
    }
    push();
    translate(spider[i].x,shigh);
    rotate(PI); /// Flip 180-degrees 
    stroke(175,255);
    strokeWeight(height*0.0025); /// web-line thickness.
    line(0,0,0,height*0.85); /// web line output
    spider[i].update(i); /// Generate the spider's
                         /// legs and animate them.
                         /// Output the legs before
                         /// outputting the body.
    spider[i].spiderBody(i);
  }
}


function spiderMaker(i) {
  this.x = random(width); /// each spider get own spot
  this.y = 0; /// start at top (bottom actually)
  this.scale = height*random(0.01,0.03); /// how big?
  this.len = this.scale*random(this.scale*2); /// legs size
  this.sw = this.scale*0.2; /// legs thickness
  this.drop = random(height*0.1); /// starting drop
  this.dropRate = random(2,16); /// dropping speed
  this.style = floor(random(2));
  this.longer = random(this.scale*0.5);
  
  this.update = function(i){
    this.drop += this.dropRate; /// lower/raise spider
    push();
    if (this.style) {
      stroke(0,255);
    } else {
      stroke(255,255);
    }
    strokeWeight(this.sw);

    /// Front set of legs origin set
    translate(0,0);
    this.legsR(1,-PI,1); /// execute leg animation
    translate(0,this.scale*0.01); /// move to next leg
    this.legsR(2,-PI,1); /// execute next leg animation.

    /// Back set of legs origin set
    translate(0,this.scale*0.01);
    this.legsR(3,PI*0.75,1.25);
    translate(0,this.scale*0.01);
    this.legsR(4,PI*0.75,1.25);
    pop();

    /// Left Side Legs
    push();
    if (this.style) {
      stroke(0,255);
    } else {
      stroke(255,255);
    }
    strokeWeight(this.sw);
    /// Front set origin set
    translate(0,0);
    this.legsL(1,PI,1);
    translate(0,this.scale*0.01);
    this.legsL(2,PI,1);

    /// Back set origin set 
    translate(0,this.scale*0.01);
    this.legsL(3,-PI*0.75,1.25);
    translate(0,this.scale*0.01);
    this.legsL(4,-PI*0.75,1.25);
    pop();
  }

  
  /// Right Set Legs Animation:
  /// Locate, rotate by perlin noise.
  this.legsR = function(arm,pi,ln) {
    let fc = (frameCount+arm)*0.025;
    let r = map(
              noise( (arm*0.75),
                     (arm+1)+fc),
              0,1,
              -pi*0.1,pi*0.45);
    this.len = this.scale+this.longer;
    push();
    translate(0,0);
    rotate(r);
    line(0,0,this.len,0);
    translate(this.len,0); /// move to end of leg
    rotate(r*1.1);
    this.len *= 0.8;
    strokeWeight(this.sw*0.75); /// reduce thickness
    line(0,0,this.len*ln,0);
    translate(this.len,0); /// move to end of leg
    rotate(r*1.5);
    this.len *= 0.8;
    strokeWeight(this.sw*0.5);
    line(0,0,this.len*ln,0);
    pop(); /// Close the graphics attributes container.
  }
  this.legsL = function(arm,pi,ln) {
    let fc = (frameCount-arm)*0.025;
    let r = map(
              noise( (arm*0.75),
                     (arm+1)+fc),
              0,1,
              -pi*0.1,pi*0.45);
    this.len = this.scale+this.longer;
    push();
    translate(0,0);
    rotate(r);
    line(0,0,-this.len,0); /// Use a -x length.
    translate(-this.len,0); /// move to end of leg
    rotate(r*1.1);
    this.len *= 0.8;
    strokeWeight(this.sw*0.75); /// reduce thickness
    line(0,0,-this.len*ln,0); /// Use -x length.
    translate(-this.len,0); /// move to end of leg
    rotate(r*1.5);
    this.len *= 0.8;
    strokeWeight(this.sw*0.5);
    line(0,0,-this.len*ln,0); /// Use -x length.
    pop();
  }
  this.spiderBody = function(i) {
    let size = spider[i].scale;
    push(); /// Contain any changes to the graphics
    let bodyD1 = 0.5; /// Wide
    let bodyD2 = 1.25;  /// Tall
    let bodyD3 = 1.5; /// Extra Tall
    strokeWeight(1);
    stroke(50,255);
    //// Make the abdomen of the spider (cephalothorax).
    /// Make style decisions.
    if (this.style) {
      fill(255,0,0,255);
    } else {
      fill(0,0,0,255);
    }
    ellipse(0,0,
            size*bodyD1,
            size*bodyD2);
    
    //// Made the body of the spider.
    if (this.style) {
      fill(0,0,0,255);
    } else {
      fill(255,0,0,255);
    }
    push();
    translate(0,0);
    let r = map(
          noise((i+1)*0.05,frameCount*0.05),
                 0,1,-PI*0.1,PI*0.1);
    rotate(r);
    ellipse(0,size*bodyD2,
            size*bodyD2,
            size*bodyD3);
    pop();
    let fangD1 = 0.8; // left/right position
    let fangD2 = 0.18; // bottom position
    let fangD3 = 0.355; // top position
    stroke(0,255);
    strokeWeight(size*0.1);
    /// Make the spider's FANGS (left, then right).
    line(-size*fangD2,
          -size*fangD3,
         -size*fangD2,
         -size*fangD1);
    line(size*fangD2,
          -size*fangD3,
         size*fangD2,
         -size*fangD1);
    let eyeD1 = 0.1; /// left 
    let eyeD2 = 0.18; /// right 
    let eyeD3 = 0.35; /// bottom row 
    let eyeD4 = 0.4; /// top row 
    strokeWeight(height*0.0028);
    let twinkle = random();
    stroke(255,255);
    if (twinkle < 0.1) {
      stroke(255,0,0,255);
    }
    if (twinkle > 0.9) {
      stroke(0,255,0,255);
    }
    
    point(-size*eyeD2,
          -size*eyeD3);
    point(size*eyeD2,
          -size*eyeD3);
    point(-size*eyeD1,
          -size*eyeD4);
    point(size*eyeD1,
          -size*eyeD4);
    pop(); /// Close eyes container
    pop(); /// Close spider object container
  }
}


/// Allow the user to view in fullscreen
/// by clicking or tapping the top-half of 
/// the canvas.
function mousePressed() {
  if (mouseX > 0 && mouseX < width &&
    mouseY > 0 && mouseY < height/2) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}




