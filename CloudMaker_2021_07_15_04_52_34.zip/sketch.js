/// Cloud Maker Object
/// by Ed Cavett
/// March, 2021

//// Makes a single cloud object 
//// that partially hides the sun.
//// Changing Weather Motion Graphic:
//// Cloud grows large and turns grey.
//// Once large enough, rain will fall.
//// Falling rain reverses cloud growth.
//// The rain will stop and the cloud
//// dissipates.
//// Process repeats.
//// Optional text output that 
//// displays the weather condition.

/// Definitions:
/// Cloud unit - one instance of a circle
///    that changes in radius by a noise wave
///    and is tied to an instance location.
/// Instance location - the location around which
///    a cloud unit random area is center.
/// Cloud shape - the drawing of many cloud
///    units that all share the same instance
///    location.
/// Drop or raindrop - the feature of a cloud
///    unit that can be switched on and fall
///    like rain from the cloud unit's center.

let clouds = []; /// Hold array of circles
                 /// Total array makes a cloud
let billows = 30; /// How dense is the cloud?
                  /// Adjust the array size < or >
                  /// 1 billow = 1 cloud unit
function setup() {
  createCanvas(windowWidth,
               windowHeight);
  let w = width; /// shortcuts for width and height
  let h = height;
  
  /// Create the array elements with instances of cloud-unit
  /// Array length relates to the density of the cloud shape
  for (let i = 0; i < billows; i++) {
    /// cloudMaker creates a single cloud unit with a single
    /// raindrop unit.  The function handles the growth of
    /// the cloud units, their area, color, rain activation
    /// and deactivation.  The variable ".arange" (0-3>) describes
    /// the state of the cloud shape in area & scale.
    /// parameters: pos.x&y, area scale, cloud radius zmin,zmax);
    /// ]pos.x&y: the center of the cloud shape
    /// ]area scale: the range a cloud shape is spread around in
    /// ]cloud radius zmin: smallest radius a cloud unit will be
    /// ]cloud radius zmax: largest radius a cloud unit will be
    clouds.push(new cloudMaker(w / 2, h * 0.20, 45, 0, 150));
  }
}

function draw() {
  /// Blue sky background
  /// Draw a sun shape first
  background(0, 175, 225, 255);
  push();
  translate(width / 2, height * 0.20);
  stroke(200, 175, 0, 200);
  strokeWeight(5);
  fill(255, 255, 0, 255);
  circle(-30, 10, 100); /// sun
  pop();

  /// Update the cloud unit objects
  /// in the clouds[] array
  /// function will display the output
  /// as the cloud shape that appears
  /// over the sun.
  for (let j = 0; j < 2; j++) {
    for (let i = 0; i < clouds.length; i++) {
      clouds[i].update(j);
    }
  }
  
  /// Use cloud[0] state information to
  /// display a state indicator
  // weatherreport();
  
  /// Display grass colored 
  /// rectangle for the ground layer
  push();
  stroke(100,200,255,255);
  strokeWeight(5);
  fill(75,200,0,255);
  rect(0,height*0.95,width,height-height*0.95);
  pop();
}

/// Receives a location to center the random
/// position of a cloud unit.
/// Receives a magnitude used with growth wave
/// Receives a range to map growth wave to position


function cloudMaker(xc, yc, a, zlo, zhi) {
  this.r = zhi; /// radius changes by zwave noise
                /// Start with highest range value
  this.rx = random(-a, a); /// random x position
                           /// within received area value
                           /// full range width and positioned
                           /// both leftward and rightwardly
  this.ry = random(0, a);  /// random y position
                           /// within received area value
                           /// half as wide and positioned
                           /// upwardly.
  this.arange = 1; /// Allows units to expand as the
                   /// cloud shape grows with unit radius increase
  /// The position of a cloud unit is the product of the 
  /// random position value x and the given range value
  /// plus the center of the cloud shape
  /// The verticle position is a ratio of the width
  this.pos = createVector(this.rx * this.arange + xc,
                          yc-this.ry);
  /// 
  this.rainpos = this.pos.copy();
  this.zoff = random(10);
  this.zwave = 0;
  this.zmin = zlo;
  this.zmax = zhi;

  this.zrange = this.zmax;
  this.zrpol = -0.075;
  this.arange = this.zrpol;

  this.rainvel = createVector(0.5, 3);
  this.rainfall = false;

  this.update = function(j) {
    this.zrange += this.zrpol;
    /// arange describes the state of the 
    /// cloud shape related to size.
    /// Larger clouds drop rain.
    /// Larger clouds turn grey.
    /// Larger clouds block the sun.
    /// arange moves through these states
    /// which are assigned:
    /// 0-1 Sunny
    /// 1-2 Parly Cloudy
    /// 2-2.5 Cloudy
    /// 2.5-3.5 Rainy
    /// 3.5-3.7 Heavy Rain
    this.arange = (this.zmax - this.zrange) * 0.025;
    /// Use arange as the magnitude for the
    /// cloud unit locations related to the 
    /// cloud shapes center position.
    this.pos.set(this.rx * this.arange + xc,
                 this.ry * (this.arange *
                 0.5)-yc+(this.zmax*1.75));
    /// Reverse polarity of scale oscillator
    /// when out of bounds
    if (this.zrange > this.zmax ||
      this.zrange < this.zmin) {
      this.zrpol *= -1;
    }
    /// Generates the noise offset for 
    /// cloud unit radius variances
    this.zoff += 0.0075;
    /// Returns radius variances as noise
    /// constrained by the parameters zmin,zmax
    this.zwave = map(noise(this.zoff),
      0, 1, this.zmin, this.zmax - this.zrange);
    /// Assign the radius of a cloud unit
    /// the noise wave returned value
    this.r = this.zwave;

    
    /// make and show rain first
    /// 1) Are clouds big enough to rain?
    /// 2) If so, check for a chance to fall.
    /// 3) Drop only if not already falling. 
    if (this.arange > 2.5) {
      /// Generate a probable chance to 
      /// release a drop that's switched off
      let yesrain = random(1);
      if (yesrain < 0.005 && !this.rainfall) {
        /// Switch drop to falling and
        /// give it the cloud unit's pos to start
        this.rainfall = true;
        this.rainpos = this.pos.copy();
      } 
    } 
      
    /// Show rain only when cloud shape is
    /// in the state to drop rain.
    if (this.rainfall) {
        push(); /// show raindrops
        translate(this.rainpos.x, this.rainpos.y);
        noFill();
        stroke(225, 125);
        let dropsize = map(this.arange,0,3,-6,6);
        strokeWeight(2+dropsize);
        point(0, 0);
        let rcolor = map(this.zrange,this.zmin,
                         this.zmax,300,-100);
        stroke(0, 100, 200, 255);
        strokeWeight(dropsize);
        point(0, 0);
        pop();
        this.rain();
      }


      /// make clouds over the top of rain   
      push();
      translate(this.pos.x, this.pos.y);
      noStroke();
      // fill(175,255); /// make an arc for shadow/hilite
      // circle(0,+4,this.r-1);
      if (j === 0) {
        fill(175, 255);
        circle(0, 0, this.r + (this.zmax * 0.075));
      }
      if (j === 1) {
        let ccolor = map(this.zrange,this.zmin,
                         this.zmax,125,355);
        fill(ccolor, 255);
        circle(0, 0, this.r);
      }
      pop();
    }
  /// Generates the updated position
  /// of a falling raindrop.
  /// Checks if drop has reached the ground.
  /// Sets the falling state to off when
  /// out-of-bounds.
  this.rain = function() {
    if (this.rainfall) {
      this.rainpos.add(this.rainvel);
      if (this.rainpos.y > height) {
        this.rainpos = this.pos.copy();
        this.rainfall = false;
      }
    }
    }
  }

/// Generates text output of the 
/// cloud state with arange value.
function weatherreport() {
  push();
  noStroke();
  fill(255,255);
  textAlign(LEFT);
  textSize(35);
  translate(50,125);
  if (clouds[0].arange < 1) {
  text('Sunny',0,0);
  }
  if (clouds[0].arange >= 1 &&
      clouds[0].arange < 2.0){
  text('Partly Cloudy',0,0);
  }
  if (clouds[0].arange >= 2.0 &&
      clouds[0].arange < 2.5) {
  text('Cloudy',0,0);
  }
  if (clouds[0].arange >= 2.5 &&
      clouds[0].arange < 3.5){
  text('Rainy',0,0);
  }
  if (clouds[0].arange >=3.5){
  text('Heavy Rain',0,0);
  }
  pop();
}












  //// end of sketch