/// Solar Rays Animation
/// by Ed Cavett
/// December 2021

/// Generate a sun-shape with a corona
/// and wavey rays surrounding it.
/// The waves represent solar winds and
/// expand as they move away from the sun.


let sun;
let index = 0;
let img;

function setup(){
  
  createCanvas(windowWidth,
               windowHeight);
  sun = new sunMaker();
  fill(255,255,175,255);
  noStroke();
  rectMode(CENTER);
  
  img = createGraphics(width,height);
  img.background(0,32);
  img.noStroke();
  img.fill(124,118,0,2);
  for (let r = 1; r < height*0.25; r++) {
    img.circle(width/2,height/2,r);
  }  
}


function draw() {
  translate(width/2,height/2);
  image(img,-width/2,-height/2);
  let i = -1;
  
  for (let n = 0; n < TWO_PI; n += PI*0.2) {
    i++;
    sun.update(i);
  }
  circle(0,0,50);
  sun.rot = 0;
}

function sunMaker(){
  this.xoff = 0;
  this.yoff = [];
  this.y = 0;
  this.rot = 0;
  this.len = width*0.4;
  this.step = 3;
  this.range = this.len*0.1;
  this.delta = 10;
  let i = 01;
  for (let n = 0; n < TWO_PI; n += PI*0.1) {
    i += 0.1;
    this.yoff.push(random(100));
  }
  
  this.update = function(n) {
    this.rot += (PI*0.2);
    push();
    translate(0,0);
    rotate(this.rot);
    this.xoff = 0;
    this.delta = 25;
    
    for (let x = 0; x < this.len; x += this.step) {
      this.delta = lerp(this.delta,x,0.025);
      let prevy = this.y;
      this.y = map(noise(this.xoff,this.yoff[n]),0,1,
                  -this.delta,0);
      let alph = map(x,0,this.len,8,1);
      let colr = map(noise(this.xoff,this.yoff[n],
                           frameCount*0.01),0,1,
                     255,50);
      let topThick = map(sin(frameCount*0.05),-1,1,
                         16,64);
      let thick = map(x,0,this.len,1,topThick);
      stroke(colr,colr-55,0,alph);
      strokeWeight(thick);
      line(x,this.y,
           x-this.step,prevy);
      this.xoff += 0.05;
    }
    this.yoff[n] += 0.01;
    pop();
  }
}






