//// Mushroom Forest
//// by Ed Cavett
//// June 2023

//// fx(hash) compliant NFT


///////////////////
// Key Controls:
//--------------------------------
// q - 1st Layer (Back texture)  
// w - 2nd Layer (Tree Branches)
// e - 3rd Layer (In-focus Leaves & Sticks)
// r - 4th Layer (Bare Branches)
// r - 5th Layer (Ferns, Mushrooms & Moss)

// a - Fade into 1st Layer (Back texture)  
// s - Fade into 2nd Layer (Tree Branches * Leaves)
// d - Fade into 3rd Layer (Tree Branches)
// f - Fade into 4th Layer (Ferns, Mushrooms & Moss)

// z - Invert 1st Layer
// x - Invert 2nd Layer
// c - Invert 3rd Layer
// v - Invert Top Layer


// y - Add Black-n-White Filter
// h - Add Sepia Filter 

// u - Invert current output
// j - Blur current output
// m - All Layer in Original Order

// p - Save current canvas outuput

// i - Fill with Black
// o - Fill with White
// k - Fill with Random
// l - Fill with Palette


//// Curated Hashes
/// 5335.555772762746
/// 6553.301936946809
/// 3234.4276271760464
/// 86.92895760759711


let ypos;
let fillR;
let fillG;
let fillB;
let strokeR;
let strokeG;
let strokeB;
let skR;
let skG;
let skB;
let colSet;
let colA;
let colB;
let colC;
let colD;
let colE;
let vel;
let drot;
let tmaxLen;
let tminLen;
let tside;
let mushy = [];
let vine = [];
let wcount;

let fmaxLen;
let fminLen;
let flmaxLen;
let flminLen;

let keepBack;
let keepMid;
let keepMidFront;
let keepFore;
let keepForeFront;
let keepFernRock;
let keepA;
let wKick;
let mushL;
let pos;
let mSizeYVel;
let rmush;

function setup() {
  let hashGen = fxrand() * 10000;
  console.log("random seed: " + hashGen);
  randomSeed(hashGen);
  noiseSeed(hashGen);

  createCanvas(1195, 740);
  imageMode(CENTER);
  strokeCap(SQUARE);
  waver = new waveMaker();
  ypos = 0;
  colSet = 0;
  colA = floor(random(14));
  colB = floor(random(14));
  colC = floor(random(14));
  colD = floor(random(14));
  colE = floor(random(14));
  colSelect(colD);
  skR = fillR;
  skG = fillG;
  skB = fillB;
  mushL = random();
  vel = random(1, 25);
  drot = 0;
  for (let n = 0; n < 12; n++) {
    vine.push(new vineMaker());
  }
  colSelect(colA);
  tmaxLen = height * 0.4;
  tminLen = tmaxLen * 0.1;
  tside = 0;
  rmush = 0;
  for (let n = 0; n < 49; n++) {
    mushy.push(new mushMaker());
  }
  rmush = 1;
  for (let n = 0; n < 50; n++) {
    mushy.push(new mushMaker());
  }
  fmaxLen = height * 0.3;
  fminLen = fmaxLen * 0.2;
  flmaxLen = fmaxLen * 0.2;
  flminLen = flmaxLen * 0.2;
  background(fillR,fillG,fillB,255);
  if (random() < 0.5) {
    background(strokeR,strokeG,strokeB,255);
  }
  wcount = -1;
  wKick = 0;
  mSizeX = width*random(0.25,0.45);
  mSizeY = height*0.25;
  mSizeYVel = 2;
  pos = createVector(random(width*0.2,width*0.8),
                     height*1.5);
}

function draw() {
  ypos += vel;
  if (wcount < 3) {
    if (ypos > height * 1.35) {
      colA = floor(random(14));
      colB = floor(random(14));
      colSelect(colA);
    }
    drot += 0.005;
    vel += 0.1;
    push();
    translate(width * 0.5, ypos);
    rotate(drot);
    waver.update();
    pop();
  } else {
    if (wcount > 4) {
      for (let vn = 0; vn < 25; vn++) {
        push();
        translate(width * 0.5, height * 0.5);
        for (let i = 0; i < vine.length; i++) {
          push();
          translate(vine[i].loc.x, vine[i].loc.y);
          vine[i].update();
          pop();
        }
        pop();
      }
    }
  }
  if (ypos > height * 1.35 && frameCount < 300) { /// runs solo on wcount=3
    ypos = -height * 0.1;
    wcount += 1;
    drot = 0;
    let layerA = get();
    layerA.filter(BLUR, 2);
    image(layerA, width * 0.5, height * 0.5);
    image(layerA, width*0.5,height*0.5);
    if (wcount === 3) {
        keepBack = get();
        keepBack.resize(1990,1080);
        createCanvas(1990,1080);
        imageMode(CENTER);
    }
  }
  if (wcount === 4) {
    wcount += 1;
    for (let tn = 0; tn < 4; tn++) {
      push();
      translate(width * 0.5, height * 0.5);
      if (random() < 0.5) {
        tside = 0;
        rotate(HALF_PI);
      } else {
        tside = 1;
        rotate(-HALF_PI);
      }
      tmaxLen = height * random(0.1, 0.3);
      tminLen = tmaxLen * 0.1;
      translate(random(-width * 0.25, width * 0.25), height);
      treeMaker(tmaxLen);
      pop();
    }
  }
  if (frameCount === 301) {
    let layerA = get();
    layerA.filter(DILATE);
    layerA.filter(DILATE);
    createCanvas(1990, 1080);
    imageMode(CENTER);
    image(layerA, width * 0.5, height * 0.5);
    keepMid = get();
    keepMid.filter(BLUR,2);
    createCanvas(1990,1080);
    skR = 0;
    skG = 0;
    skB = 0;
    for (let tn = 0; tn < 4; tn++) {
      push();
      translate(width * 0.5, height * 0.5);
      if (random() < 0.5) {
        tside = 0;
        rotate(HALF_PI);
      } else {
        tside = 1;
        rotate(-HALF_PI);
      }
      tmaxLen = height * random(0.2, 0.4);
      tminLen = tmaxLen * 0.1;
      translate(random(-width * 0.25, width * 0.25), height);
      treeMaker(tmaxLen);
      pop();
    }
    keepMidFront = get();
    createCanvas(1990,1080);
  }
  if (frameCount === 302) {
    keepFore = get();
    let fernDense = floor(random(2, 5));
    for (let fernNum = 0; fernNum < fernDense; fernNum++) {
      colSelect(colD);
      let fernPos = random(width * 0.1, width * 0.9);
      for (let n = 0; n < 4; n++) {
        push();
        translate(fernPos + random(-width * 0.15, width * 0.15), height);
        fernMaker(fmaxLen, random(-PI * 0.08, PI * 0.08));
        pop();
      }
      layerA = get();
      layerA.filter(BLUR, 1);
      layerA.filter(GRAY);
      tint(255,255,255,125);
      image(layerA, width * 0.5, height * 0.5);
      noTint();
    }
  }
  if (frameCount === 303) {
    push();
    translate(0, height * 1.1);
    mossMaker();
    pop();
  }
  if (frameCount > 303 && frameCount < 684) {
    push();
    translate(pos.x,pos.y);
    mSizeX -= 0.25;
    mSizeY += mSizeYVel;
    moundMaker(mSizeX,mSizeY);
    pop();
    if (mSizeY > height*0.3) {
      mSizeYVel = -1;
    }
  }
  if (frameCount === 684) {
    keepFernRock = get();
    createCanvas(1990,1080);
    rmush = 0;
    let mushPut = random(width * 0.15, width * 0.85);
    for (let i = 0; i < floor(mushy.length*0.5); i++) {
      colSelect(colD);
      for (let cn = 1; cn < 700; cn++) {
        push();
        translate(mushPut, height * 1.05);
        mushy[i].update(cn);
        pop();
      }
    }
    push();
    translate(0, height * 1.15);
    mossMaker();
    pop();
    keepForeFront = get();
    createCanvas(1990,1080);
    imageMode(CENTER);
    image(keepBack,width*0.5,height*0.5);
    image(keepMid,width*0.5,height*0.5);
    image(keepFernRock,width*0.5,height*0.5);
    image(keepMidFront,width*0.5,height*0.5);
    image(keepForeFront,width*0.5,height*0.5);
    keepA = get();
    fxpreview();
    console.log("Mushroom Forest");
    console.log("Generative Art by Ed Cavett");
    console.log("July 2023");
    noLoop();
  }
}

function moundMaker(zx,zy) {
  this.wide = zx;
  this.tall = zy;
  this.gap = TAU * 0.02;
  let xoff = random(10000);
  let yoff = random(10000);
  beginShape();
  let count = 0;
  for (let r = -PI-this.gap; r < (this.gap*2); r+= this.gap){
    count += 0.05;
    let x = cos(r)*this.wide;
    let y = sin(r)*this.tall;
    let xmod = map(noise(frameCount*0.1,x*0.05,count*0.1),0,1,
                   -this.wide*0.1,
                   this.wide*0.1);
    let ymod = map(noise(frameCount*0.1,y*0.05,count*0.1),0,1,
                   -this.tall*0.1,
                   this.tall*0.1);
    let fc = frameCount*0.75;
    vertex(x+xmod+fc,y+ymod);
    push();
    let sMod = createVector(random(-1,1),
                            random(-1,1));
    sMod.mult(random(1,1.5));
    translate(x+xmod+fc+sMod.x,
              y+ymod+sMod.y);
    let chanceSM = map(zy,height*0.25,2,1,0.25);
    if (random() < chanceSM) {
      let z = height * 0.005;
      let sxmod = random(-z * 2, z * 2);
      let symod = random(-z, z);
      stroke(strokeR, strokeG, strokeB, 255);
      strokeWeight(10);
      point(sxmod,symod);
      strokeWeight(random(1, 3));
      for (let r = 0; r < PI; r += TAU * 0.16) {
        colSelect(colD);
        stroke(fillR, fillG, fillB, 255);
        push();
        translate(sxmod,symod);
        rotate(r);
        line(-z, 0, z, 0);
        pop();
      }
    }
    pop();
    
    if (random() < 0.001) {
      let mpick = floor(random(mushy.length*0.5,mushy.length-1));
      colSelect(colD);
      for (let cn = 1; cn < 700; cn++) {
        push();
        translate(x+xmod+fc,y+ymod);
        mushy[mpick].update(cn);
        pop();
      }
    }
    if (random() < 0.01) {
      push();
      translate(x+xmod+fc,y+ymod);
      colSelect(colA);
      fleafMaker(flmaxLen * random(0.75, 1),
                 random(-PI * 0.05, PI * 0.05));
      pop();
    }
  } 
  let colMod = map(zy,height*0.25,2,1.1,0.25);
  colSelect(colB);
  stroke(strokeR*colMod,strokeG*colMod,strokeG*colMod,255);
  strokeWeight(1);
  fill(fillR,fillG,fillB,255);
  endShape();
  colSelect(colA);
}

function fernMaker(len, theta) {
  push();
  translate(0, 0);
  rotate(theta);
  let sw = map(len, fminLen, fmaxLen, 1, 10);
  strokeWeight(sw);
  stroke(strokeR, strokeG, strokeB, 255);
  line(0, 0, 0, -len);
  for (let y = 0; y < len; y += len * 0.3) {
    push();
    translate(0, -y);
    rotate(-HALF_PI);
    fleafMaker(len * 0.25, theta * 1.5);
    pop();
    push();
    translate(0, -y);
    rotate(HALF_PI);
    fleafMaker(len * 0.25, theta * 1.5);
    pop();
  }
  translate(0, -len);
  if (len > fminLen) {
    fernMaker(len * 0.8, theta * 1.25);
  }
  pop();
}

function fleafMaker(len, theta) {
  push();
  translate(0, 0);
  rotate(theta);
  let sw = map(len, flminLen, flmaxLen, 1, 10);
  strokeWeight(sw);
  stroke(fillR, fillG, fillB, 255);
  line(0, 0, 0, -len);
  for (let y = 0; y < len; y += len * 0.2) {
    push();
    translate(0, -y);
    rotate(-HALF_PI);
    flernMaker(len * 0.32, random(-PI * 0.1, PI * 0.1));
    pop();
    push();
    translate(0, -y);
    rotate(HALF_PI);
    flernMaker(len * 0.32, random(-PI * 0.1, PI * 0.1));
    pop();
  }
  translate(0, -len);
  if (len > flminLen) {
    fleafMaker(len * 0.8, theta * 1.5);
  }
  pop();
}

function flernMaker(len, theta) {
  push();
  translate(0, 0);
  rotate(theta);
  let sw = map(len, flminLen, flmaxLen, 3, 15);
  strokeWeight(sw);
  let colMod = random(0.5, 1);
  stroke(fillR * colMod, fillG * colMod, fillB * colMod, 255);
  line(0, 0, 0, -len);
  translate(0, -len);
  if (len > flminLen) {
    flernMaker(len * 0.8, theta * 1.5);
  }
  pop();
}

function mossMaker() {
  let xoff = random(1000);
  let yoff = random(1000);
  let z = height * 0.005;
  push();
  for (let posy = height * 0.75; posy < height * 1.1; posy += 2) {
    let posMod = map(noise(posy*0.1),0,1,0,-height*0.2);
    let gap = floor(random(10,25));
    for (let x = -width * 0.1; x < width * 1.1; x += gap) {
      colSelect(colD);
      let y = map(noise(xoff, yoff), 0, 1, -height * 0.2,
                  height * 0.2);
      if (random() < 0.3) {
        let xmod = random(-z * 2, z * 2);
        let ymod = random(-z, z)+posMod;
        stroke(strokeR, strokeG, strokeB, 255);
        strokeWeight(10);
        point(x + xmod, y + ymod);
        strokeWeight(random(1, 3));
        for (let r = 0; r < PI; r += TAU * 0.16) {
          colSelect(colD);
          stroke(fillR, fillG, fillB, 255);
          push();
          translate(x + xmod, y + ymod);
          rotate(r);
          line(-z, 0, z, 0);
          pop();
        }
        if (random() < 0.005) {
          push();
          translate(x + xmod, y + ymod);
          colSelect(colD);
          fleafMaker(flmaxLen * random(0.75, 1), random(-PI * 0.05, PI * 0.05));
          pop();
        }
      }
      xoff += 0.05;
    }
    yoff += 0.01;
  }
  pop();
}

function mushMaker() {
  this.pos = [];
  this.prev = [];
  this.vel = [];
  this.age = [];
  this.life = [];
  this.alive = [];
  this.offset = [];
  this.xr = [];
  this.yr = [];
  this.turnIt = [];
  this.capEnd = [];
  this.cpos = random(100, 200);
  if (mushL < 0.5) {
    this.cpos = random(-200,-100);
  }
  if (random() < 0.1) {
    this.cpos = random(-990, 990);
  }
  this.turn = 0;
  this.turnDir = [];
  let mdense = 1;
  if (rmush) {
    mdense = floor(random(1,3));
    this.cpos = 0;
  }
  for (let n = 0; n < mdense; n++) {
    if (!rmush) {
      this.pos.push(createVector(random(-width * 0.1, width * 0.1), 0));
    } else {
      this.pos.push(createVector(0,0));
    }
    this.vel.push(createVector(0, -1));
    this.age.push(0);
    let sizeMin = 50;
    let sizeMax = 600;
    let lifeSet = random(sizeMin,sizeMax);
    if (rmush) {
      lifeSet = random(100,400);
      sizeMin = 100;
      sizeMax = 400;
    }
    this.life.push(floor(lifeSet));
    this.offset.push(random(10000));
    let radSetx = map(lifeSet, sizeMin, sizeMax, 0.01, 0.05);
    let radSety = map(lifeSet, sizeMin, sizeMax, 0.005, 0.01);
    this.xr.push(width * radSetx);
    this.yr.push(height * radSety);
    this.turnIt.push(random(-PI * 0.051, PI * 0.051));
    this.capEnd.push(random(0.015, 0.025));
    this.turnDir.push(random());
  }

  this.update = function (fc) {
    let col = 50;
    let check = 0;
    for (let i = 0; i < this.pos.length; i++) {
      if (this.age[i] < this.life[i]) {
        check += 1;
        this.age[i] += 1;
        
        if (rmush) {
          this.turn = map(this.age[i],0,this.life[i],
                          HALF_PI,0);
          if (this.turnDir[i] < 0.5) {
            this.turn = map(this.age[i],0,this.life[i],
                            PI*1.5,PI*2);
          }
        }
        let rot = map(
          noise((i + this.offset[i]) * 0.05, fc * 0.02),
          0,
          1,
          -PI * 0.8+this.turn,
          -PI * 0.2+this.turn
        );
        this.vel[i] = p5.Vector.fromAngle(rot);
        this.pos[i].add(this.vel[i]);
        let sw = map(this.age[i], 0, this.life[i], 20, 5);
        push();
        translate(this.cpos + this.pos[i].x, this.pos[i].y);
        rotate(this.turn);
        strokeWeight(2);
        sR = strokeR;
        sG = strokeG;
        sB = strokeB;
        if (this.age[i] > this.life[i] * 0.85) {
          let reduc = map(
            this.age[i],
            this.life[i] * 0.7,
            this.life[i],
            0.8,
            0.2
          );
          sR = strokeR * reduc;
          sG = strokeG * reduc;
          sB = strokeB * reduc;
        }
        stroke(sR, sG, sB, 255);
        line(-sw, 0, -sw * 0.5, 0);
        stroke(sR * 0.75, sG * 0.75, sB * 0.75, 255);
        line(-sw * 0.5, 0, 0, 0);
        stroke(sR * 0.5, sG * 0.5, sB * 0.5, 255);
        line(0, 0, sw * 0.5, 0);
        stroke(sR * 0.25, sG * 0.25, sB * 0.25, 255);
        line(sw * 0.5, 0, sw, 0);
        pop();
      } else {
        this.xr[i] = lerp(this.xr[i], 1, 0.1);
        if (this.xr[i] > width * this.capEnd[i]) {
          this.yr[i] += height * 0.01;
        } else {
          this.yr[i] -= height * 0.01;
        }
        push();
        translate(this.cpos + this.pos[i].x, this.pos[i].y);
        rotate(this.turnIt[i]);
        let gap = TAU * 0.01;
        beginShape();
        for (let theta = -PI * 1.02; theta < PI * 0.02 + gap; theta += gap) {
          let x = cos(theta) * this.xr[i];
          let y = sin(theta) * this.yr[i];
          vertex(x, y);
          if (random() < 0.1 && y < -1) {
            push();
            stroke(255 - strokeR, 255 - strokeG, 255 - strokeB, 255);
            strokeWeight(random(3, 8));
            point(x, y);
            pop();
          }
        }
        let col = map(this.xr[i], width * 0.1, width * 0.01, 125, 25);
        noStroke();
        fill(fillR, fillG, fillB, 255);
        endShape();
        pop();
        if (this.yr[i] < 1) {
          this.yr[i] = 1;
        }
      }
    }
  };
}

function treeMaker(len) {
  let z = map(tmaxLen, height * 0.1, height * 0.4, 25, 50);
  push();
  translate(0, 0);
  let rot = -PI * random(0.1, 0.2);
  if (random() < 0.5) {
    rot = PI * random(0.1, 0.2);
  }
  if (len === tmaxLen) {
    rot = PI * random(0.01, 0.05);
  }
  rotate(rot);
  let sw = map(len, tminLen, tmaxLen, 1, z);
  noStroke();
  fill(skR, skG, skB, 255);
  quad(
    -sw * 0.5,
    0,
    -sw * 0.5 * 0.8,
    -len * 1.05,
    sw * 0.5 * 0.8,
    -len * 1.05,
    sw * 0.5,
    0
  );
  strokeWeight(sw * 0.1);
  if (tside) {
    stroke(skR * 0.2, skG * 0.2, skB * 0.2, 255);
  } else {
    stroke(skR * 1.2, skG * 1.2, skB * 1.2, 255);
  }
  line(-sw * 0.5, 0, -sw * 0.5 * 0.8, -len);
  if (tside) {
    stroke(skR * 1.2, skG * 1.2, skB * 1.2, 255);
  } else {
    stroke(skR * 0.2, skG * 0.2, skB * 0.2, 255);
  }
  line(sw * 0.5, 0, sw * 0.5 * 0.8, -len);

  if (random() < 0.1) {
    len *= random(0.5, 1);
  }
  translate(0, -len);

  if (random() < 0.3) {
    push();
    translate(0, 0);
    let rot = -PI * random(0.1, 0.2);
    if (random() < 0.5) {
      rot = PI * random(0.1, 0.2);
    }
    if (len === tmaxLen) {
      rot = PI * random(0.01, 0.05);
    }
    rotate(rot);
    let sw = map(len, tminLen, tmaxLen, 1, z);
    noStroke();
    fill(skR, skG, skB, 255);
    quad(
      -sw * 0.5,
      0,
      -sw * 0.5 * 0.8,
      -len * 1.05,
      sw * 0.5 * 0.8,
      -len * 1.05,
      sw * 0.5,
      0
    );
    strokeWeight(sw * 0.1);
    if (tside) {
      stroke(skR * 0.2, skG * 0.2, skB * 0.2, 255);
    } else {
      stroke(skR * 1.2, skG * 1.2, skB * 1.2, 255);
    }
    line(-sw * 0.5, 0, -sw * 0.5 * 0.8, -len);
    if (tside) {
      stroke(skR * 1.2, skG * 1.2, skB * 1.2, 255);
    } else {
      stroke(skR * 0.2, skG * 0.2, skB * 0.2, 255);
    }
    line(sw * 0.5, 0, sw * 0.5 * 0.8, -len);
    if (random() < 0.1) {
      len *= random(0.5, 1);
    }
    translate(0, -len);
    if (len > tminLen) {
      treeMaker(len * 0.8);
    }
    pop();
  }
  if (random() < 0.3) {
    push();
    translate(0, 0);
    let rot = -PI * random(0.1, 0.2);
    if (random() < 0.5) {
      rot = PI * random(0.1, 0.2);
    }
    if (len === tmaxLen) {
      rot = PI * random(0.01, 0.05);
    }
    rotate(rot);
    let sw = map(len, tminLen, tmaxLen, 1, z);
    noStroke();
    fill(skR, skG, skB, 255);
    quad(
      -sw * 0.5,
      0,
      -sw * 0.5 * 0.8,
      -len * 1.05,
      sw * 0.5 * 0.8,
      -len * 1.05,
      sw * 0.5,
      0
    );
    strokeWeight(sw * 0.1);
    if (tside) {
      stroke(skR * 0.2, skG * 0.2, skB * 0.2, 255);
    } else {
      stroke(skR * 1.2, skG * 1.2, skB * 1.2, 255);
    }
    line(-sw * 0.5, 0, -sw * 0.5 * 0.8, -len);
    if (tside) {
      stroke(skR * 1.2, skG * 1.2, skB * 1.2, 255);
    } else {
      stroke(skR * 0.2, skG * 0.2, skB * 0.2, 255);
    }
    line(sw * 0.5, 0, sw * 0.5 * 0.8, -len);
    if (random() < 0.1) {
      len *= random(0.5, 1);
    }
    translate(0, -len);
    if (len > tminLen) {
      treeMaker(len * 0.8);
    }
    pop();
  }

  if (len > tminLen) {
    treeMaker(len * 0.8);
  }
  pop();
}

function leafMaker(len) {
  let leafDense = floor(random(1, 3));
  let berryDense = floor(random(3, 5));
  if (random() < 0.1) {
    for (let b = 0; b < berryDense; b++) {
      colSelect(colC);
      let z = createVector(random(0.5, 1), random(0.25, 0.5));
      let pos = createVector(random(-1, 1), random(-1, 1));
      let m = len * 0.5;
      pos.mult(m * 3);
      push();
      strokeWeight(1);
      stroke(fillR * 0.3, fillG * 0.3, fillB * 0.3, 255);
      line(0, 0, pos.x, pos.y);
      translate(pos.x, pos.y);
      strokeWeight(m + 1);
      stroke(0, 255);
      point(0, 0);
      stroke(fillR, fillG, fillB, 255);
      strokeWeight(m);
      point(0, 0);
      strokeWeight(1);
      stroke(fillR * 0.1, fillG * 0.1, fillB * 0.1, 255);
      strokeWeight(len * 0.16);
      fill(fillR * 0.3, fillG * 0.3, fillB * 0.3, 255);
      arc(0, 0, len * 0.45, len * 0.45, -QUARTER_PI, PI * 0.75);
      pop();
    }
  }
  for (let n = 0; n < leafDense; n++) {
    let z = createVector(random(0.5, 1), random(0.25, 0.5));
    let pos = createVector(random(-1, 1), random(-1, 1));
    let m = random(10);
    pos.mult(m);
    let col = 255;
    z.mult(len);
    colSelect(colB);
    push();
    translate(0, z.y);
    rotate(random(TAU));
    beginShape();
    vertex(0, 0);
    bezierVertex(z.x, z.y, z.x, -z.y, -z.x, -z.y);
    let frnd = random(0.6, 1.1);
    fill(fillR * frnd, fillG * frnd, fillB * frnd);
    noStroke();
    endShape();
    beginShape();
    vertex(0, 0);
    bezierVertex(z.x, z.y, -z.x, z.y, -z.x, -z.y);
    frnd = random(0.6, 1.1);
    fill(fillR * frnd, fillG * frnd, fillB * frnd);
    noStroke();
    endShape();
    strokeWeight(1);
    line(-z.x, -z.y, z.x * 0.25, z.y * 0.25);
    pop();
  }
}

function vineMaker() {
  this.pos = [];
  this.prev = [];
  this.vel = [];
  this.age = [];
  this.life = [];
  this.alive = [];
  this.offset = [];
  this.gap = [];
  this.leafSet = random(0.01, 0.35);
  this.loc = createVector(
    random(-width * 0.5, width * 0.5),
    random(-height * 0.5, height * 0.5)
  );
  let dense = 30;
  for (let n = 0; n < dense; n++) {
    this.pos.push(createVector(0, 0));
    this.prev.push(createVector(0, 0));
    this.vel.push(createVector(0, 0));
    this.age.push(0);
    this.life.push(125);
    this.alive.push(0);
    this.offset.push(random(10000));
    this.gap.push(floor(random(3, 12)));
  }
  this.alive[0] = 1;
  this.aliveCheck = 0;
  this.picker = 0;

  this.update = function () {
    if (random() < 0.1) {
      let pick = this.picker;
      let place = floor(random(this.picker));

      if (this.alive[place]) {
        this.pos[pick] = this.pos[place].copy();
      } else {
        this.pos[pick] = this.pos[0].copy();
      }
      this.alive[pick] = 1;
    }
    this.picker = 0;
    for (let i = 0; i < this.pos.length; i++) {
      this.aliveCheck = 0;
      if (this.age[i] < this.life[i] && this.alive[i]) {
        // alive and not too old?
        this.picker += 1;
        this.aliveCheck += 1;
        this.age[i] += 1; // age the point
        if (this.age[i] > this.life[i]) {
          this.age[i] = 0;
          this.alive[i] = 0;
        }
        let rot = map(
          noise((i + this.offset[i]) * 0.05, frameCount * 0.01),
          0,
          1,
          -TAU,
          TAU
        );
        this.vel[i] = p5.Vector.fromAngle(rot);
        this.vel[i].mult(this.gap[i]);
        this.prev[i] = this.pos[i].copy();
        this.pos[i].add(this.vel[i]);
        push();
        stroke(skR * 0.1, skG * 0.1, skB * 0.1, 128);
        let sw = map(this.age[i], 1, this.life[i], 5, 1);
        strokeWeight(sw);
        let pout = random(1, 1.2);
        if (random() > 0.05) {
          pout = 1;
        }
        line(
          this.pos[i].x * pout + sw * 0.5,
          this.pos[i].y * pout + sw * 0.5,
          this.prev[i].x + sw * 0.5,
          this.prev[i].y + sw * 0.5
        );
        stroke(skR * 0.6, skG * 0.6, skB * 0.6, 255);
        line(
          this.pos[i].x * pout,
          this.pos[i].y * pout,
          this.prev[i].x,
          this.prev[i].y
        );
        if (random() < this.leafSet) {
          push();
          translate(this.pos[i].x, this.pos[i].y);
          let leafZset = map(sw, 1, 5, 10, 40);
          leafMaker(leafZset);
          pop();
        }
        pop();
      }
    }
    if (!this.alive[0]) {
      this.aliveCheck = 1;
    }
  };
}

function waveMaker() {
  this.gap = width * 0.01;
  this.xoff = random(10000);
  this.yoff = random(10000);
  this.zoff = random(10000);
  this.xR = width * 0.7;
  this.xL = -width * 0.7;
  this.tall = height * 0.1;
  this.update = function () {
    let hmod = cos(frameCount * 0.05) * 0.1;
    let ymod = sin(frameCount * 0.01) * (height * hmod);
    this.gap = map(noise(frameCount * 0.01), 0, 1, width * 0.005, width * 0.1);
    push();
    beginShape();
    let prevX = this.xL;
    let prevY = 0;
    let y = 0;
    for (let x = this.xL; x < this.xR; x += this.gap) {
      prevY = y + ymod;
      y = map(
        noise((this.xoff + x) * 0.01, this.yoff),
        0,
        1,
        -this.tall,
        this.tall
      );
      prevX = x - this.gap;
      vertex(x, y + ymod);
      strokeWeight(17 - vel);
      let shayd = 1;
      if (y + ymod > prevY) {
        shayd = 0.1;
      }
      stroke(strokeR * shayd, strokeG * shayd, strokeB * shayd, 64);
      push();
      translate(prevX, prevY);
      rotate(cos((x + frameCount) * 0.01) * (PI * 0.1));
      line(0, 0, x, y + ymod);
      pop();
    }
    ymod = cos(frameCount * 0.1) * (height * hmod);
    for (let x = this.xR; x > this.xL; x -= this.gap) {
      prevY = y;
      y = map(
        noise((this.xoff + x) * 0.011, this.yoff),
        0,
        1,
        -this.tall,
        this.tall
      );
      prevX = x + this.gap;
      vertex(x, y);
      strokeWeight(17 - vel);
      let shayd = 1.0;
      if (y > prevY) {
        shayd = 0.1;
      }
      stroke(fillR * shayd, fillG * shayd, fillB * shayd, 128);
      push();
      translate(prevX, prevY);
      rotate(sin((x + frameCount) * 0.05) * (PI * 0.1));
      line(0, 0, x, y);
      pop();
    }
    this.yoff += 0.05;
    stroke(fillR, fillG, fillB, 255);
    strokeWeight(1);
    fill(strokeR, strokeG, strokeB, random(16, 64));
    // noFill();
    noStroke();
    endShape();
    pop();
  };
}

function colSelect(n) {
  let sr = random(255);
  let sg = random(255);
  let sb = random(255);
  let fr = random(255);
  let fg = random(255);
  let fb = random(255);
  if (n === 0) {
    //Grays
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * 2;
    sb = 255 * pick * 2;
    fr = 255 * pick;
    fg = 255 * pick;
    fb = 255 * pick;
  }
  if (n === 1) {
    // Yellow and Purple
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * 2;
    sb = 0;
    fr = 255 * pick;
    fg = 0;
    fb = 255 * pick;
  }
  if (n === 2) {
    // Orange and Green
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick;
    sb = 0;
    fr = 25 * pick;
    fg = 255 * pick;
    fb = 25 * pick;
  }
  if (n === 3) {
    // Red and Gray
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 0;
    sb = 0;
    fr = 255 * pick;
    fg = 255 * pick;
    fb = 255 * pick;
  }
  if (n === 4) {
    // Sky Blue and Orange
    let pick = random(0.5);
    sr = 0;
    sg = 128 * pick * 2;
    sb = 255 * pick * 2;
    fr = 255 * pick * 2;
    fg = 255 * pick;
    fb = 0;
  }
  if (n === 5) {
    // Orange and Sapphire
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * random(1.6);
    sb = 0;
    fr = 0;
    fg = 255 * pick * 2;
    fb = 255 * pick * 2;
  }
  if (n === 6) {
    // Dark Green and Sapphire
    let pick = random(0.5);
    sr = 0;
    sg = 255 * pick * 2;
    sb = 255 * pick * 2;
    fr = 0;
    fg = 128 * pick * 2;
    fb = 0;
  }

  if (n === 7) {
    // Gray and Pink
    let pick = random(0.5);
    sr = 128 * pick;
    sg = 128 * pick;
    sb = 128 * pick;
    fr = 255 * pick * 2;
    fg = 200 * pick * 2;
    fb = 200 * pick * 2;
  }
  if (n === 8) {
    // Yellow and Orange
    let pick = random(0.5);
    sr = 255 * pick;
    sg = 255 * pick;
    sb = 0;
    fr = 255 * pick * 2;
    fg = 255 * pick * random(1.6);
    fb = 0;
  }
  if (n === 9) {
    // Blue and Gray
    let pick = random(0.5);
    sr = 0;
    sg = 255 * pick;
    sb = 255 * pick;
    fr = 255 * pick * 2;
    fg = 255 * pick * 2;
    fb = 255 * pick * 2;
  }
  if (n === 10) {
    // Moss Green / Smoke Green
    let pick = random(0.5);
    sr = 255 * pick;
    sg = 255 * pick * 2;
    sb = 255 * pick;
    fr = 200 * pick * 2;
    fg = 255 * pick * 2;
    fb = 200 * pick * 2;
  }
  if (n === 11) {
    // Cream Yellow / Dark Purple
    let pick = random(0.5);
    sr = 255 * pick * 2;
    sg = 255 * pick * 2;
    sb = 200 * pick;
    fr = 225 * pick;
    fg = 200 * pick;
    fb = 200 * pick * 2;
  }
  if (n === 12) {
    // Dark Red and Red
    let pick = random(0.5);
    sr = 255 * pick;
    sg = 0;
    sb = 0;
    fr = 225 * pick * 2;
    fg = 0;
    fb = 0;
  }
  if (n === 13) {
    // Dark Blue and Sky Blue
    let pick = random(0.5);
    sr = 0;
    sg = 0;
    sb = 128 * pick;
    fr = 200 * pick;
    fg = 200 * pick;
    fb = 255 * pick * 2;
  }
  if (n === 14) {
    // Dark Green and Bright Green
    let pick = random(0.5);
    sr = 0;
    sg = 128 * pick;
    sb = 0;
    fr = 200 * pick;
    fg = 255 * pick * 2;
    fb = 200 * pick;
  }

  fillR = fr;
  fillG = fg;
  fillB = fb;
  strokeR = sr;
  strokeG = sg;
  strokeB = sb;
}

function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

function keyPressed() {
  if (key === "p") {
    saveCanvas("ed_cavett_mushroomForest", "png");
  }
  if (key === "t") {
    image(keepForeFront, width*0.5,height*0.5);
  }
  if (key === "m") {
    image(keepA, width*0.5,height*0.5);
  }
  if (key === "y") {
    let layerA = get();
    layerA.filter(GRAY);
    layerA.filter(DILATE);
    tint(255, 255, 255, 64);
    image(layerA, width * 0.5, height * 0.5);
    noTint();
  }
  if (key === "h") {
    let layerA = get();
    layerA.filter(GRAY);
    layerA.filter(DILATE);
    tint(255, 150, 0, 64);
    image(layerA, width * 0.5, height * 0.5);
    noTint();
  }
  if (key === "q") {
    keepBack.resize(1990,1080);
    image(keepBack,width*0.5,height*0.5);
  }
  if (key === "w") {
    image(keepMid,width*0.5,height*0.5);
  }
  if (key === "e") {
    image(keepFernRock,width*0.5,height*0.5);
  }
  if (key === "r") {
    image(keepMidFront,width*0.5,height*0.5);
  }
   if (key === "a") {
    keepBack.resize(1990,1080);
    let layerA = keepBack.get();
    tint(255, 255, 255, 64);
    image(layerA, width * 0.5, height * 0.5);
    noTint();
  }
  if (key === "s") {
    let layerA = keepMid.get();
    tint(255, 255, 255, 64);
    image(layerA, width * 0.5, height * 0.5);
    noTint();
  }
   if (key === "d") {
    let layerA = keepFore.get();
    tint(255, 255, 255, 64);
    image(keepFernRock,width*0.5,height*0.5);
    noTint();
  }
   if (key === "f") {
    let layerA = keepMidFront.get();
    tint(255, 255, 255, 64);
    image(layerA, width * 0.5, height * 0.5);
    noTint();
  }
   if (key === "g") {
    let layerA = keepForeFront.get();
    tint(255, 255, 255, 64);
    image(layerA, width * 0.5, height * 0.5);
    noTint();
  }
  if (key === "j") {
    let layerA = get();
    layerA.filter(BLUR,2);
    image(layerA, width*0.5,height*0.5);
  }
  
  if (key === "z") {
    keepBack.resize(1990,1080);
    keepBack.filter(INVERT);    
    image(keepBack,width*0.5,height*0.5);
  }
  if (key === "x") {
    keepMid.filter(INVERT);    
    image(keepMid,width*0.5,height*0.5);
  }
  if (key === "c") {
    keepFernRock.filter(INVERT);    
    image(keepFernRock,width*0.5,height*0.5);
   }
  if (key === "v") {
    keepMidFront.filter(INVERT);    
    image(keepMidFront,width*0.5,height*0.5);
  }
  if (key === "b") {
    keepForeFront.filter(INVERT);    
    image(keepForeFront,width*0.5,height*0.5);
   }
  if (key == "u") {
    let layerA = get();
    layerA.filter(INVERT);
    image(layerA,width*0.5,height*0.5);
  }
      
  if (key === "i") {
    background(0,255);
  }
  if (key === "o") {
    background(255,255);
  }
  if (key === "k") {
    background(random(255),random(255),random(255),255);
  }
  if (key === "l") {
    background(fillR,fillG,fillB,255);
  }
}
