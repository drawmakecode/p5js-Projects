/// Declare an empty array
/// and set it to part.
let part = [];

/// Assign a number of 
/// objects in our system.
let popu = 4;


/// Assign a scale size for the 
/// system of objects.
let size = 50;

/// Assign a rotational speed
/// scaling factor.
let speed = 0.001;

/// Assign a variable to handle
/// the thickness of a geometry.
let thick = 5;

/// Declare a variable to hold
/// a color moving object
let colorer;


function setup() {
  /// Tell p5.js you want to
  /// use the WEB graphics library.
  createCanvas(windowWidth,
               windowHeight,
              WEBGL); // <=== include this
  
  /// Loop through the number of items in
  /// your array of objects.
  for (let i = 0; i < popu; i++){
    /// Assign to the next open element
    /// a new instance of our function
    /// we'll make, called mover().
    part.push(new mover(0.01,0.05,i));
  }
  
  /// Instantiate an object to 
  /// move through color values.
  colorer = new coloring();
  
  /// Remove the stroke so our geometries
  /// won't show the edges of triangles
  /// that make up all 3D shapes.
  noStroke();
  background(0,255);
}

function draw() {
  // background(0,255);

  /// Assign a local variable to
  /// use as an incrementer for 
  /// the global canvas volume
  /// rotations.
  let theta = map( sin(frameCount*speed),-1,1,-QUARTER_PI,
                  QUARTER_PI);
  
  /// Light the origin from a set direction
  /// inside the volume.
  /// Light from the front center
  /// and back center.
  
  /// Use function variable to
  /// assign lighting values.
  colorer.update();
  let cr = colorer.r;
  let cg = colorer.g;
  let cb = colorer.b;
  directionalLight(0,0,cb,
                  -width/2,-height/2,0);
  directionalLight(255-cr,255-cg,0,
                  -width/2,height/2,0);
  // ambientLight(cr*0.5,cg*0.5,cb*0.5);
  /// Include all material types for ease
  /// of testing outputs.
  /// normal material will reflects colors
  /// that are relative to the x,y,z axis in
  /// a color map of red, green and blue.
  // normalMaterial();
  // ambientMaterial(255,255,255);
  specularMaterial(cr,cg,cb);
  // emissiveMaterial(255,255,255);
  
  /// Rotate along each axis by the 
  /// local variable.  This will turn
  /// the entire volume and everything in
  /// it.  It's also similar to moving the
  /// viewer around the objects.
  rotateX(theta*10);
  rotateY(theta*10);
  rotateZ(theta*10);
  
  part[0].update();
  
  
  /// The default origin is at the 
  /// center of the volume.
  /// Use this translation to change it.
  translate(part[0].posx,
            part[0].posy,
           part[0].posz);
   
  /// Isolate each object in the 
  /// array together.
  push();
  
  /// Loop through the array of objects
  /// and manipulate their rotations.
  for (let i = 0; i < part.length; i++){

    /// Receive new rotation values.
    /// Comment out the function
    /// call when using global
    /// rotation variable.
    /// This will increase performance.
    // part[i].update();
    // translate(part[i].posx,
    //           part[i].posy,
    //           part[i].posz);
    
    /// Assign local variables to the 
    /// return of the x, y, and z ratational
    /// values.  Comment out the assignments
    /// that use method variables to avoid
    /// an error call.
    // let thetax = part[i].thetaX;
    // let thetay = part[i].thetaY;
    // let thetaz = part[i].thetaZ;
    
    /// Perform those rotations.
    /// Use global or method variables.
    rotateX(theta);
    rotateY(theta);
    rotateZ(theta);
    // rotateX(theta*(i+0.25)*10);
    // rotateY(theta*(i+0.25)*10);
    // rotateZ(theta*(i+0.25)*10);
  
    /// Include any objects you
    /// like here to see different
    /// outputs.
    push();
    rotateX(theta*(i+0.25)*10);
    rotateY(theta*(i+0.25)*10);
    rotateZ(theta*(i+0.25)*10);
    // sphere(size*i+size);
    // box(size);
    torus((size*i+size),thick,3,6);
    // plane(size*i+size*4);
    pop();
    
    /// A torus will describe rings.
    /// Multiples of 25px will increase
    /// each ring in size.
    torus((size*i+size)*0.5,thick);
    
    //// Include a torus with side
    //// parameters for making triangular
    //// rings.
    // torus(size*i+size,thick,4,12);
    
    //// Divide the array into two sets
    //// and output alternating geometries.
    // if (i/2 === int(i/2)){
    //   // torus(size*i+size,thick,3,12);
    // torus(size,thick);
    // } else {
    //   // torus(size*i+size,thick,4,12);
    // torus(size,thick,4,12);
    // }
    
  } /// End loop through array
  pop(); /// Close transform isolation.
}

/// Move the angles of rotation in
/// positive or negative directions
/// by random.
/// Receive a value for how frequently
/// the direction might change.
/// Receive a value for the speed
/// of rotation.
function mover(r,s, i){
  /// Assign position variables.
  this.posx = random(-width/2,width/2);
  this.posy = random(-height/2,height/2);
  this.posz = random(-height/2,0);
  
  /// Assign movement values for those
  /// position variables.
  this.xn = 0.001*i+0.001;
  this.yn = 0.001*i+0.001;
  this.zn = 0.001*i+0.001;
  
  /// Instantiate with random angle.
  this.thetaX = random(-PI,PI);
  this.thetaY = random(-PI,PI);
  this.thetaZ = random(-PI,PI);
  /// Assign the speed to an instance
  /// variable for use in update.
  this.thetaxl = s;
  this.thetayl = s;
  this.thetazl = s;
  /// Assign the rate to an instance
  /// variable for use in update.
  this.rate = s;
  
  
  /// Perform the changes in rotation.
  this.update = function(i){
    /// Determine by unit chance
    /// to switch the direction
    /// of rotation.  Check each
    /// axis seperately.
    if (random(1) < this.rate) {
      this.thetaxl *= -1;
    }
    if (random(1) < this.rate) {
      this.thetayl *= -1;
    }
    if (random(1) < this.rate) {
      this.thetazl *= -1;
    }
    
    /// Increment/Decrement by
    /// the relevant rotaional
    /// direction.
    this.thetaX += this.thetaxl;
    this.thetaY += this.thetayl;
    this.thetaZ += this.thetazl;
    
    /// Generate new position.
    this.xn += 0.01;
    this.yn += 0.01;
    this.zn += 0.01;
    this.posx = map( noise(this.xn),0,1,
                    -width*0.6,width*0.6);
    this.posy = map( noise(this.yn),0,1,
                    -height*0.6,height*0.6);
    this.posz = map( noise(this.zn),0,1,
                    -height*0.6,0);

    
  }
}

/// Create values to use as color
/// for lights and materials

function coloring(){
  this.r = random(255);
  this.g = random(255);
  this.b = random(255);
  
  this.rn = random(100);
  this.gn = random(100);
  this.bn = random(100);
  
  this.update = function(){
    this.rn += 0.1;
    this.gn += 0.1;
    this.bn += 0.1;
    
    this.r = map( noise(this.rn),0,1,50,255);
    this.g = map( noise(this.gn),0,1,50,255);
    this.b = map( noise(this.bn),0,1,50,255);
  }
}







//// end of sketch

















