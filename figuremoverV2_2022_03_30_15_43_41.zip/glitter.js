
function glitter(){
  this.pos = [];
  this.vel = [];
  this.acc = [];

  for (let i = 0; i < 25; i++){
  this.pos.push(createVector(random(-5,5),
                         random(-5,5)));
  this.vel.push(p5.Vector.random2D());
  this.vel.x *= random(1,1.5);
  this.acc.push(createVector(0,random(1,2)));

  }
  
  
  this.update = function(x,y){
    for (let i = 0; i < 25; i++) {
    this.vel[i].add(this.acc[i]);
    this.pos[i].add(this.vel[i]);
    
    if (this.pos[i].y > height) {
      this.pos[i] = createVector(random(-5,5),
                              random(-5,5));
      this.vel[i] = p5.Vector.random2D();
      this.vel[i].x *= random(0.5,1.0);
      this.acc[i] = createVector(0,random(0.5,1.5));
    }
    
      push();
      translate(x,y);
      stroke(25,0,random(75,255),25);
      strokeWeight(random(5,15));
      point(this.pos[i].x,this.pos[i].y);
      pop();
    }
  }
}