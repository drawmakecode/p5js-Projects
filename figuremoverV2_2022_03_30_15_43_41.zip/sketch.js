/// Fairy Dancers
/// by Ed Cavett
/// April 2021
///
//// Uses Figure Mover Version 2
//// Adds wings


let guys = [];
let population = 3;
let size = 50;
let explode = false;
let exploding = false;
let howlong = 0;
let grassy;

let glit = [];

function setup() {
  createCanvas(windowWidth,
    windowHeight);
  for (let i = 0; i < population; i++) {

    guys.push(new guy(width / 2, height / 2, 0));
    glit.push(new glitter(guys[i].pos.x,
                          guys[i].pos.y));
  }
  grassy = new yard();
  strokeCap(SQUARE);
}



function draw() {
  background(75,150,125, 255);
  for (let i = 0; i < guys.length; i++) {
    guys[i].update(i + 1);
    // glit[i].update(guys[i].pos.x,
    //                guys[i].pos.y);
  }

  grassy.update();
}






/// Click to Go Fullscreen
function mousePressed() {
  if (mouseX > 0 &&
    mouseX < width &&
    mouseY > height / 2 &&
    mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}


function guy(xpos, ypos, i) {
  this.pos = createVector(xpos, ypos, i);
  this.vel = createVector(0, 0);
  this.size = size;
  this.body = 0;
  this.xoff = random(100); // random(100);
  this.yoff = random(100); // random(100);
  this.raoff1 = random(100);
  this.raoff2 = random(100);
  this.rloff1 = random(100);
  this.rloff2 = random(100);
  this.rftoff = random(100);
  this.laoff1 = random(100);
  this.laoff2 = random(100);
  this.lloff1 = random(100);
  this.lloff2 = random(100);
  this.lftoff = random(100);
  /// body parts array
  /// 0 torso
  /// 1 head
  /// 2 right arm upper
  /// 3 right arm lower
  /// 4 right hand
  /// 5 left arm upper
  /// 6 left arm lower
  /// 7 left hand
  /// 8 right leg upper
  /// 9 right leg lower
  /// 10 left leg upper
  /// 11 left leg lower
  /// 12 right foot
  /// 13 left foot
  this.part = [];
  this.vel = [];
  for (let i = 0; i < 14; i++) {
    this.vel.push(p5.Vector.random2D());
    // this.vel[i].mult(random(2,5));
    this.part.push(createVector(0, 0));
  }
  this.wing1 = random(100);
  this.swing = 0;
  this.wingwave = 0;


  this.update = function(i) {
    if (explode) {
      for (let j = 0; j < this.part.length; j++) {
        this.part[j].add(this.vel[j]);
      }
    }

    /// parts rotations noise offset
    this.raoff1 += 0.021;
    this.raoff2 += 0.021;
    this.rloff1 += 0.021;
    this.rloff2 += 0.021;
    this.rftoff += 0.005;

    this.laoff1 += 0.01;
    this.laoff2 += 0.01;
    this.lloff1 += 0.021;
    this.lloff2 += 0.021;
    this.lftoff += 0.005;

    /// body rotation noise offset
    this.yoff += 0.0081;
    this.xoff += 0.0081;

    this.size = 10 + noise(this.yoff, this.xoff) * 25;
    /// movement modifiers
    let arm1mod = PI*0.5;
    let arm2mod = PI*0.5;
    let leg1mod = PI * 0.5;
    let leg2mod = PI * 0.25;
    let footmod = PI * 0.5;

    /// get noise values for rotation radians 
    this.body = map(noise(this.xoff * 2.25 + i), 0, 1,
      -PI*0.05,PI*0.25);
    let rarm1 = noise(this.raoff1) * arm1mod*2; // upper
    let rarm2 = -noise(this.raoff2) * arm2mod; // lower
    let rleg1 = -noise(this.rloff1) * leg1mod;
    let rleg2 = (PI * 0.10) + noise(this.rloff2) * leg2mod;
    let rfoot = (PI * 0.20) + noise(this.rftoff) * footmod;

    let larm1 = noise(this.laoff1) * arm1mod*2; // upper
    let larm2 = noise(this.laoff2) * arm2mod; // lower
    let lleg1 = -noise(this.lloff1) * leg1mod;
    let lleg2 = (PI * 0.10) + noise(this.lloff2) * leg2mod;
    let lfoot = (PI * 0.20) + noise(this.lftoff) * footmod;

    /// position noise using body rotation offset
    let xn = noise(this.xoff) * width;
    let yn = noise(this.yoff) * height;

    // this.vel = createVector(xn,yn);
    this.pos.set(xn, yn);

    if (this.pos.x < 0) {
      this.pos.x = width;
    }
    if (this.pos.x > width) {
      this.pos.x = 0;
    }
    if (this.pos.y < 0) {
      this.pos.y = height;
    }
    if (this.pos.y > height) {
      this.pos.y = 0;
    }

    let torso = this.size * 0.4;
    let c = 255;//map(i, 0, population - 1, 175, 255);
    let c1 =255;// map(noise(this.xoff*0.25),-1,1,75,255);
    let c2 =255;// 255; //map(this.size, 0, size, 25, 255);

    push();
    /// torso 0
    translate(this.pos.x + this.part[0].x,
    this.pos.y + this.part[0].y);
    this.wings();
    // rotate(noise(this.xoff+i)*TWO_PI);
    rotate(this.body);
    strokeWeight(torso);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, -this.size * 0.75); /// spine
    strokeWeight(torso * 0.25);
    line(-this.size * 0.25, -this.size * 0.75,
      this.size * 0.25, -this.size * 0.75); /// shoulder
    line(-this.size * 0.27, 0,
      this.size * 0.27, 0); /// hips

    /// head 1
    push();
    translate(this.part[1].x,
      -this.size + this.size * 0.1 + this.part[1].y);
    strokeWeight(this.size * 0.35);
    stroke(255-c1, c1, c, c2);
    point(0, -this.size * 0.35 / 2);
    pop();


    //// ARMS AND LEGS ////
    /// right arm upper / index-2
    push();
    strokeCap(ROUND);
    translate(this.size * 0.27 + this.part[2].x,
      -this.size * 0.75 + this.part[2].y);
    rotate(rarm1);
    strokeWeight(torso * 0.5);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, -this.size * 0.33);

    /// right arm lower / index-3
    push();
    translate(this.part[3].x,
      -this.size * 0.33 + this.part[3].y);
    rotate(rarm2);
    strokeWeight(torso * 0.4);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, -this.size * 0.5);

    /// right hand 4 and wand
    push()
    translate(0,-this.size*0.5);
    strokeWeight(this.size * 0.1);
    let wandmove = -noise(this.raoff2) * (PI*0.5);
    rotate(wandmove);
    point(this.part[4].x, -this.size * 0.6 + this.part[4].y);
    line(this.part[4].x, 0,
         this.part[4].x,
         -this.size * 0.6 + this.part[4].y-this.size*0.25);
    // glit[i-1].update(this.part[4].x,
    //                  -this.size * 0.6 + this.part[4].y-this.size*0.25);


    pop();
    pop();

    pop(); /// end right arm upper/lower

    /// left arm upper 5
    push();
    strokeCap(ROUND);
    translate(-this.size * 0.25 + this.part[5].x,
      -this.size * 0.75 + this.part[5].y);
    rotate(larm1);
    strokeWeight(torso * 0.5);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, this.size * 0.33);
    push();

    /// left arm lower
    translate(+this.part[6].x,
      this.size * 0.33 + this.part[6].y);
    rotate(larm2);
    strokeWeight(torso * 0.4);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, this.size * 0.5);
    strokeWeight(this.size * 0.2);

    /// left hand 7
    point(this.part[7].x,
      this.size * 0.6 + this.part[7].y);
    pop();
    pop(); /// end left arm upper/lower

    /// right leg upper
    push();
    strokeCap(ROUND);
    translate(this.size * 0.15 + this.part[8].x,
      this.part[8].y);
    rotate(rleg1);
    strokeWeight(torso * 0.55);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, this.size * 0.50);

    /// right leg lower
    push();
    translate(this.part[9].x,
      this.size * 0.50 + this.part[9].y);
    rotate(rleg2);
    strokeWeight(torso * 0.45);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, this.size * 0.65);

    /// right foot     
    push();
    translate(this.part[10].x,
      this.size * 0.65 + this.part[10].y);
    rotate(rfoot);
    line(-this.size * 0.01, 0,
      this.size * 0.2, 0);
    pop();
    pop();
    pop(); /// end right leg upper/lower


    /// left leg upper
    push();
    strokeCap(ROUND);
    translate(-this.size * 0.15 + this.part[11].x,
      this.part[11].y);
    rotate(lleg1);
    strokeWeight(torso * 0.55);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, this.size * 0.50);

    /// left leg lower
    push();
    translate(this.part[12].x,
      this.size * 0.50 + this.part[12].y);
    rotate(lleg2);
    strokeWeight(torso * 0.45);
    stroke(255-c1, c1, c, c2);
    line(0, 0, 0, this.size * 0.65);

    /// left foot
    push();
    translate(this.part[13].x,
      this.size * 0.65 + this.part[13].y);
    rotate(lfoot);
    line(-this.size * 0.01, 0,
      this.size * 0.2, 0);
    pop();
    pop();
    pop(); /// end right leg upper/lower

    pop(); /// end parent encapsulation



  }

  this.wings = function() {
    /// Top Wings
    push();
    strokeWeight(this.size * 0.30);
    stroke(0, 200, 255, 125);
    rotate(this.body);
    translate(0, -this.size * 0.75);
    // this.wingwave += random(0.01,0.1);
    this.wing1 += random(1, 0.75) * 2.5; // sin(this.wingwave)*1.25;
    this.swing = sin(this.wing1) * (-PI * 0.1);

    push(); /// left wing
    rotate(this.swing);
    line(0, 0,
      -this.size * 1.75, -this.size * 1.25);
    pop();

    push(); /// right wing
    rotate(-this.swing);
    line(0, 0,
      this.size * 1.75, -this.size * 1.25);
    pop();
    pop();

    /// Bottom Wings
    push();
    strokeWeight(this.size * 0.30);
    stroke(0, 200, 255, 125);
    rotate(this.body);
    translate(0, -this.size * 0.55);
    this.swing = sin(this.wing1) * (PI * 0.15);

    push(); /// left wing
    rotate(this.swing);
    line(0, 0,
      -this.size * 1.5, this.size * 1.25);
    pop();

    push(); /// right wing
    rotate(-this.swing);
    line(0, 0,
      this.size * 1.5, this.size * 1.25);
    pop();
    pop();



  }

}








/// end of sketch