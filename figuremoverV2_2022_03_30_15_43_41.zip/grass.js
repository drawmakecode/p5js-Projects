function yard() {
  this.grass = [];
  this.roff = [];
  this.rwave = [];
  this.size = [];
  this.index = 0;
  this.population = 100;

  for (let i = 0; i < width; i += width / this.population) {
    this.index += 1;
    this.grass.push(i);
    this.roff.push(this.index * 0.01);
    this.rwave.push(0);
    this.size.push(random(35, 55));
  }



  this.update = function() {
    for (let i = 0; i < this.index; i++) { // draw many blades

      // draw one blade of grass
      let len = this.size[i];
      push();
      translate(this.grass[i], height);
      stroke(0, 125, 50, 255);

      /// blade noise


      this.blade(len, i);
      pop();
    }
  }

  this.blade = function(len, ind) {
    this.roff[ind] += 0.005;
    let rot = map(noise(this.roff[ind]), 0, 1,
      -QUARTER_PI*0.35, QUARTER_PI*0.35);
    strokeWeight(3+(len*0.15));
    line(0, 0, 0, -len);
    translate(0, -len);
    if (len > 5) {
      rotate(rot);
      this.blade(len * 0.7, ind);
    }
  }
}












///// end of sketch 
