//// Eyeris 
//// Procedural Art
//// for a multi-colored
//// eye.

//// Code, annotations
//// and accompanying video
//// by Ed Cavett
//// July, 2021

//// Free to copy and distribute.
//// To watch the tutorial video that
//// accompanies this program at
//// youtube.com Draw Make Code,
//// use the link or search
//// p5.js Tutorial - How to Make the Iris of an Eyeball
///  https://www.youtube.com/watch?v=cABw_nj-9h8&t=1282s

//// Note: Some additions have been made since
//// the airing of the accompanying vide.

////////////////////////////////////////////////////
//// LET'S GET CODING! :-)


/// Declare a variable to hold
/// the 2D-wave object.
let shape;

function setup() {
  
  /// Set the canvas size to the available 
  /// window width and height.
  /// To "square" or center the output,
  /// use the height dimension as the base
  /// unit for sizing.  Take fractions of the
  /// height to fit the output within the boundaries
  /// of the canvas.  This will create nice-looking
  /// output for most devices viewing in landscape
  /// orientation.
  createCanvas(windowWidth,
               windowHeight);
  
  /// Assign a new instance of the 2D-wave
  /// maker object to the declared variable.
  shape = new waver();
  
  /// Clear the background in setup to
  /// start with the desired canvas color.
  background(0,255);
}

function draw() {
  
  /// Determine to clear the canvas
  /// for a fresh output.
  /// Use the modulus of the frameCount/n
  /// to determine the factor to refresh by.
  /// This is similar to the procedure
  /// > frameCount/n === int(frameCount/n) <
  if (frameCount%2000 === 0) {
    background(0,255);
  }

  /// Call the make() method in the 2D-wave maker
  /// function to access the object's methods.
  shape.make();
  
  /// Isolate the graphic attributes to
  /// output the pupil shape in the center of
  /// the canvas.
  push();
  stroke(25,255);
  strokeWeight(5);
  fill(3,255);
  
  /// Assign a local variable to receive the return
  /// of noise to find a coefficient for the pupil
  /// size adjustment.  Multiplying the coefficient
  /// times the height will result in a fractional
  /// amount of the iris to make the pupil.
  /// This size varies by noise slowly constricting
  /// and dialating it.
  let ps = map(noise(frameCount*0.0005),0,1,0.1,0.5);
  circle(width/2,height/2,height*ps);
  noFill();
  strokeWeight(150);
  stroke(0,0,0,255);
  
  /// Output a thick line around the iris
  /// to clean up the edges at a desired
  /// distance from the center point.
  circle(width/2,height/2,height*1.15);
  pop();
}


/// Create a 2D-line and rotate
/// it around the center of the canvas.
/// The output results in something that
/// looks like the iris of a eye.
function waver(){

  /// Declare positions and assign them
  /// a nominal value.
  this.x = 0;
  this.y = 0;
  
  /// Declare a y-value to use in the 2D-noise
  /// method.
  this.yoff = 0;
  
  /// Declare a size for the height of the wave
  /// and assign it a nominal value.
  this.s = 0;
  
  /// Declare a length to make the wave-line.
  /// This length should be relative to the circle
  /// that masks the outside edge of the iris.
  this.len = height*0.78;
  
  /// Declare an angle value and set it to 0.
  this.theta = 0;
  
  /// Declare a velocity to move through
  /// the radians of TWO_PI.
  this.ts = 0.01;
  
  /// Declare color values for r,g,b color channels.
  this.r = floor(random(255)); /// red
  this.g = floor(random(255)); /// green
  this.b = floor(random(255)); /// blue
  
  
  /// Provide a method to calculate output
  /// and display results.
  this.make = function(){
    
    /// Set the x-value for the noise function to
    /// zero so that the next wave is relational.
    let xoff = 0;
    
    /// Receive the return of the map function and
    /// assign it to the size of the wave height.
    /// The fluctuations are 1D-noise mapped to
    /// a desired range.
    this.s = map(noise(frameCount*0.01),0,1,10,75);
    
    /// Advance the radian for rotating the 
    /// 2D-wave line around the center point.
    this.theta += this.ts;
    
    /// Check for a full rotation and
    /// reset the radian to 0.  Advance
    /// to the next color combination by
    /// calling the colorer() method.
    if (this.theta > 1){
      this.theta = 0;
      this.colorer();
    }
    
    /// Isolate the graphic attributes to
    /// the bottom component.
    push();
    
    /// Set the center point (origin of rotation)
    /// to the center of the canvas.
    translate(width/2,height/2);
    
    /// Spin the coordinates system by the determined
    /// radians and plot the wave-line in 
    /// classic orientation.  The push()pop() will leave
    /// the accumulated output untouched as the 
    /// coordinate systems turns for the isolated
    /// geometries.
    rotate(TWO_PI*this.theta);
    
    /// Output the bottom componet with
    /// the return of the colorer() method's
    /// r, g, b values.
    stroke(this.r,this.g,this.b,75);

    /// Use a heavier stroke for the 
    /// bottom component.
    strokeWeight(7);
    
    /// The beginShape method will treat the
    /// result as a fillable object.  Turn off
    /// the fill to show only the line of the wave.
    /// Turn on the fill to see the positive/negative
    /// planes relative to the average of the 1st
    /// and last locations that make up the line.
    noFill();
    
    /// Generate a wave-shape object made of 2D-noise.
    /// The shapes are relational through rotation.
    /// The first component (shape) is colored.
    beginShape();
    
    /// Use a 1D-noise return to assign the lenth
    /// of the line-wave.  The length is relational
    /// through rotation.
    let sz = map(noise(frameCount*0.1),0,1,10,this.len);
  
    /// Loop through the locations X along the path
    /// of the line to adjust the Y-value by a return
    /// of the noise function.
    /// Use a random value to adjust the stepping
    /// distance between X positions on the line path.
    let rgap = map(noise(frameCount*0.01),0,1,
                  3,15);
    for (let x = 0; x < sz; x += rgap){
      
      /// Use the x,y noise values to return a
      /// relational size for the wave segment.
      this.y = map(noise(xoff,this.yoff),0,1,
                   -this.s,this.s);
      
      /// Register that segment of the line-wave
      /// in the shape object with the vertex method.
      vertex(x,this.y);
      
      /// Advance the x-noise value to return a 
      /// relational segment value from the next
      /// calculation.
      xoff += 0.05;
    }
    /// Declare that the shape object is complete
    /// and ready to output.
    endShape();
    pop(); /// Close the graphic attribute container.
    
    /// Repeat the same output for the top component.
    /// This component is black as a delimiter between
    /// the wave-lines of top component.
    push();
    translate(width/2,height/2);
    
    /// Choose to rotate in the opposite direction
    /// of the bottom component by adding a - to the
    /// parameter.
    rotate(-TWO_PI*this.theta);
    
    /// Assing the color to black or a desired
    /// static color for the top layer wave-lines.
    stroke(0,200);
    
    /// Slim the stroke to leave margins of the 
    /// bottom component.
    /// Repeat the steps for making the shape object
    /// on bottom to create similar output on top.
    strokeWeight(5);
    noFill();
    beginShape();
    for (let x = 0; x < sz; x += rgap){
      this.y = map(noise(xoff,this.yoff),0,1,
                   -this.s,this.s);
      vertex(x,this.y);
      xoff += 0.05;
    }
    
    /// Advance the value the 2nd parameter in the
    /// 2D noise to get a wave height for the next
    /// set of wave-line y-values.
    this.yoff += 0.01;
    
    /// Declare that the shape object is ready to
    /// output.
    endShape();
    
    /// Close the graphics attribute container.
    pop();
  } /// Close the make() method function.
  
  /// Generate colors for the stroke's 
  /// r,g,b values.  This method uses
  /// a procedure that increments through
  /// red until maximum, then green is incremented
  /// and red is reset.  When green is maximum,
  /// it is reset and blue is advanced until maximum,
  /// then it's reset. The order and increment amounts
  /// are arbitrary and can be changed.
  
  /// Use this method to contruct any procedure for
  /// color selection.  Assign the results to the
  /// function variable declared in the function's
  /// global space.  For this code, it's this.r, etc.
  this.colorer = function(){
    this.r += 24;
    if (this.r > 255) {
      this.r = 0;
      this.g += 24;
      if (this.g > 255) {
        this.g = 0;
        this.b += 24;
        if (this.b > 255){
          this.b = 0;          
        }
      }
    }
  }
}

/// Optional method for displaying at 
/// fullscreen when tapped or clicked
/// near the bottom.

/// Click to Go Fullscreen /bottom click
function mousePressed() {
  if (mouseX > 0 &&
      mouseX < width &&
      mouseY > height / 2 &&
      mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}



/// end of sketch