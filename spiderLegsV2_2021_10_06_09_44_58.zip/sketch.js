/// Halloween Spiders
/// Version 2
/// in p5.js
/// by Ed Cavett
/// October 2021

//////////////////////
/// Fixed or Enhanced:
/// 1. enhanced leg movements
/// 2. fixed assignment conjugation between arm and i 
//////////////////////


//// LET'S START
/// Declare global variables to hold:
/// 1) the spider-making object
/// 2) the timing for the dropping down part
/// 3) the number of spider objects

let spider = [];
let shigh;
let quant = 13;

function setup() {
  createCanvas(windowWidth,900);
  /// Loop through the number of objects.
  /// Assign a new object and store it in the 
  /// object array variable.
  for (let i = 0; i < quant; i++) {
    spider.push(new spiderMaker(i+1));
  }
  background(255,255);
}

function draw() {
  /// Set local variables to gradually change the 
  /// background color over time.  Fix change to 
  /// sin,cos in the red,green channels with a small
  /// amount in the blue channel.
  let bcolr = map(cos(frameCount*0.001),-1,1,
                  0,255);
  let bcolg = map(sin(frameCount*0.001),-1,1,
                  255,0);
  background(bcolr,bcolg,75,255);
  
  /// Loop through the spider objects.
  /// Locate position, execute spider legs animation,
  /// draw web-line, draw spider's body.
  for (let i = 0; i < spider.length; i++) {
    
    /// Assign to the global variable the movement
    /// for a rising/descending spider.  Translate
    /// the spider to that position and draw the
    /// web-line from that origin to the "bottom" of
    /// the canvas (less 15%).  When the canvas is
    /// flipped, the spiders will look like they are
    /// attached to the top of the canvas.
    shigh = map(sin(spider[i].dropRate*
                    (frameCount*0.0025)),
                -1,1,-height*0.09,height*0.85);
    /// Check spider's position and reset location
    /// and size when it's above the canvas.
    if (shigh < -(spider[i].scale*2)) {
      spider[i].x = random(width);
      spider[i].scale = height*random(0.01,0.03);
    }
    
    /// Contain any changes to the graphics
    /// attributes that get changed while
    /// making the spider and its legs.
    /// Rotate the canvase to turn the spider into
    /// a downward-facing position.
    push();
    
    /// Temporarily set the origin to the current
    /// spider's position on the canvas.
    translate(spider[i].x,shigh);
    
    /// Each spider is built facing upward.  Rotate
    /// the spider to make it look like it's facing
    /// down.
    rotate(PI); /// Flip 180-degrees 
    
    /// Make web-line, then execute spider-maker.
    /// Send into the function the index value for
    /// the current spider particle object.
    stroke(175,255);
    strokeWeight(height*0.0025); /// web-line thickness.
    line(0,0,0,height*0.85); /// web line output
    
    /// Execute the method for making a spider object.
    spider[i].update(i); /// Generate the spider's
                         /// legs and animate them.
                         /// Output the legs before
                         /// outputting the body.
    
    /// Execute the method for making a spider's body,
    /// abdomen, eyes and fangs.  Layer this output
    /// over the legs animation output.
    spider[i].spiderBody(i);
  }
}


function spiderMaker(i) {
  /// Set up the variables that will operate in
  /// this function.  Give them intitial values.
  this.x = random(width); /// each spider get own spot
  this.y = 0; /// start at top (bottom actually)
  this.scale = height*random(0.01,0.03); /// how big?
  this.len = this.scale; /// legs size
  this.sw = this.scale*0.2; /// legs thickness
  this.drop = random(height*0.1); /// starting drop
  this.dropRate = random(2,16); /// dropping speed
  
  /// Align the leg segmnet's origin.
  /// Recursively adjust the lengths to make
  /// increasingly-smaller leg segments.
  /// Do this for each side (right/left).
  /// Make the front and back set move differently.
  this.update = function(i){
    this.drop += this.dropRate; /// lower/raise spider
    
    /// Right Side Legs
    push();
    stroke(0,255);
    strokeWeight(this.sw);
    
    /// Front set of legs origin set
    translate(0,0);
    
    /// Send into the legs method the leg number to
    /// offset the noise for varied movement;
    /// the direction of rotation so back legs move
    /// backward and front legs move forward;
    /// a scaling factor for the length of each
    /// leg segment, so the segments get smaller and
    /// thinner toward the end of the leg.
    this.legsR(1,-PI,1); /// execute leg animation
    translate(0,this.scale*0.01); /// move to next leg
    this.legsR(2,-PI,1); /// execute next leg animation.
    
    /// Back set of legs origin set
    translate(0,this.scale*0.01);
    this.legsR(3,PI*0.75,1.25);
    translate(0,this.scale*0.01);
    this.legsR(4,PI*0.75,1.25);
    pop();
    
    /// Left Side Legs
    push();
    stroke(0,255);
    strokeWeight(this.sw);
    /// Front set origin set
    translate(0,0);
    this.legsL(1,PI,1);
    translate(0,this.scale*0.01);
    this.legsL(2,PI,1);
    
    /// Back set origin set 
    translate(0,this.scale*0.01);
    this.legsL(3,-PI*0.75,1.25);
    translate(0,this.scale*0.01);
    this.legsL(4,-PI*0.75,1.25);
    pop();
  }

  
  /// Right Set Legs Animation:
  /// Locate, rotate by perlin noise.
  this.legsR = function(arm,pi,ln) {

    /// Assign a local variable to hold the
    /// incrementer for perlin noise.  Offset
    /// each spider's count to get unique movements.
    /// Add 'arm' (the index value) to one side of the
    /// legs while subtracting 'arm' from the other.
    /// This will produce varying movements for 
    /// the legs on each side of the spider.
    let fc = (frameCount+arm)*0.025;
    
    /// Get a return from perlin noise.  Interpolate
    /// the return to a range of angles that will
    /// either by forward or backward moving.
    /// Adjust the range to get more dramatic moves
    /// to different sets of the legs.  The front
    /// pair move closer to the mouth than any other
    /// set of legs.  Adjust these angles to customize
    /// movement more or less.
    let r = map(
              noise( (arm*0.75),
                     (arm+1)+fc),
              0,1,
              -pi*0.1,pi*0.45);
    
    /// Set a local variable to hold the scale size
    /// of the current spider.
    this.len = this.scale;
    
    /// Contain any changes to the graphics attributes
    /// while making leg segments.
    push();
    
    /// Move the origin to the beginning of the leg
    /// segment.  Rotate that segment and output
    /// the line.
    translate(0,0);
    rotate(r);
    line(0,0,this.len,0);
    
    /// Move the origin to the end of the previous
    /// leg segment.  This is the beginning of the
    /// next segment.  Rotate that segment and output
    /// a line with a thinner stroke.
    translate(this.len,0); /// move to end of leg
    rotate(r*1.1);
    this.len *= 0.8;
    strokeWeight(this.sw*0.75); /// reduce thickness
    line(0,0,this.len*ln,0);
    
    /// Repeat this process for as many segments as
    /// the length recursion will allow.  Three to
    /// four segments is plenty.  This example uses
    /// three segments.
    translate(this.len,0); /// move to end of leg
    rotate(r*1.5);
    this.len *= 0.8;
    strokeWeight(this.sw*0.5);
    line(0,0,this.len*ln,0);
    pop(); /// Close the graphics attributes container.
  }
  
  /// Repeat the same procedures for the opposite side.
  /// Reverse the polarity of x values by adding a - 
  /// token to the front of position variables.
  /// Subtract the index value from the frameCount
  /// to get movement that is different than
  /// the legs on the other side.
  this.legsL = function(arm,pi,ln) {
    let fc = (frameCount-arm)*0.025;
    let r = map(
              noise( (arm*0.75),
                     (arm+1)+fc),
              0,1,
              -pi*0.1,pi*0.45);
    this.len = this.scale;
    push();
    translate(0,0);
    rotate(r);
    line(0,0,-this.len,0); /// Use a -x length.
    translate(-this.len,0); /// move to end of leg
    rotate(r*1.1);
    this.len *= 0.8;
    strokeWeight(this.sw*0.75); /// reduce thickness
    line(0,0,-this.len*ln,0); /// Use -x length.
    translate(-this.len,0); /// move to end of leg
    rotate(r*1.5);
    this.len *= 0.8;
    strokeWeight(this.sw*0.5);
    line(0,0,-this.len*ln,0); /// Use -x length.
    pop();
  }
  
  /// Make the body of the spider to go over
  /// the top of the legs.  Put the eyes and 
  /// fangs on the body of the spider.
  this.spiderBody = function(i) {
    
    /// Set a local variable to hold the current
    /// spider's scale size.  This will make the
    /// code easier to read.
    let size = spider[i].scale;
    
    /// Draw spider's body, abdomen,eyes and fangs.
    /// Order the output to layer each part.
    /// Set scale factors to local variables.
   
    push(); /// Contain any changes to the graphics
            /// attributes while making the spider's
            /// legs and animating their movement.
    
    /// Use two ellipses: one for the body,
    /// and one for the abdomen.
    /// Fill with black and outline in dark grey.
    
    /// Assign to local variables the scaling factors
    /// for the spider's shape and proportions.
    let bodyD1 = 0.5; /// Wide
    let bodyD2 = 1.25;  /// Tall
    let bodyD3 = 1.5; /// Extra Tall
    fill(0,255);
    strokeWeight(1);
    stroke(50,255);
    //// Make the BODY of the spider (cephalothorax).
    ellipse(0,0,
            size*bodyD1,
            size*bodyD2);
    //// Made the ABDOMEN of the spider.
    ellipse(0,size*bodyD2,
            size*bodyD2,
            size*bodyD3);
    
    //// Use two scaled-lines to make fangs.
    //// Set to local variable the scaling factors
    //// for the fangs' length and position.
    let fangD1 = 0.8; // left/right position
    let fangD2 = 0.18; // bottom position
    let fangD3 = 0.355; // top position
    stroke(0,255);
    strokeWeight(size*0.1);
    /// Make the spider's FANGS (left, then right).
    line(-size*fangD2,
          -size*fangD3,
         -size*fangD2,
         -size*fangD1);
    line(size*fangD2,
          -size*fangD3,
         size*fangD2,
         -size*fangD1);
    
    /// Use some points to make eyes.
    /// These spiders only have 4 eyes.
    /// Scale the strokeWeight to keep eyes
    /// proportional.
    let eyeD1 = 0.1; /// left 
    let eyeD2 = 0.18; /// right 
    let eyeD3 = 0.35; /// bottom row 
    let eyeD4 = 0.4; /// top row 
    strokeWeight(height*0.0028);
    stroke(255,255);
    point(-size*eyeD2,
          -size*eyeD3);
    point(size*eyeD2,
          -size*eyeD3);
    point(-size*eyeD1,
          -size*eyeD4);
    point(size*eyeD1,
          -size*eyeD4);
    
    pop(); /// Close eyes container
    pop(); /// Close spider object container
  }
}


/// Allow the user to view in fullscreen
/// by clicking or tapping the top-half of 
/// the canvas.
function mousePressed() {
  if (mouseX > 0 && mouseX < width &&
    mouseY > 0 && mouseY < height/2) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}




