/*

Frogger JS
by Ed Cavett
(c) 2026

Frogger JS is a fan-based, non-commercial use derivative
of the popular 80's coin-operated video game, Frogger.
Frogger is trademarked and the intellectual property of
KONAMI DIGITAL ENTERTAINMENT CO., LTD, 2013, and
distributed by Sega.  All Rights Reserved by their 
respective copyright and trademark owner(s).

NOT FOR COMMERCIAL DISTRIBUTION OR PROFIT.
Derivitive and transformative contributions are the
intellectual propety of Ed Cavett, Jr., 2026.
All Rights Reserved Where Applicable.

Keybord Controls:
Arrow keys to move.
R start game.
F free play.
G godlike.
T no time limit.
Q quit game.
P pause game.

Tap Controls:
Top-half of screen - Show/Hide Buttons
Bottom-half of screen - Fullscreen On/Off

Free Play - Turns on invulnerability (edges still kills frog).
Start - Begins or restarts new game.
Timer - Stops timer.
Left, Right, Up, Down - Move frog.
Note: Diagonal movement is activated in this version.

(needs implimented)
C computer player.
Z sound on/off.

(needs coded)
Hiscore updated with player's scores
Level Up advances vehicle and float speeds

*/


let gameOver = 1;
let pauseOn = 0;
let freePlay = 0;
let godLike;

let level = 1;
let score = 0;
let hiscore = 0;
let levelUP;
let unit;

let player;
let road = [];
let water = [];
let fly;
let gator;
let snake;
let snakeLog;

let img = [];
let car = [];
let carCar = [];
let logs = [];
let turtle = [];
let grass = [];
let home = [];
let snakeImg = [];
let lillyImg = [];
let inWater;
let numOfLanes = 5;
let deadFrog;
let friend;

let timer;
let timeLimit;
let timerOff = 0;

let showGrid = 0;
let floatCount;

let back1;
let homeBay;

let showBill;
let showSwitch;
let showState;
let showTime = [];
let gameEndLane;

let showButtons = 0;
let gatorImg = [];
let flyImg;
let deadBackGround = 1;
let tfont;

let buttonUp;
let buttonDown;
let buttonLeft;
let buttonRight;
let buttonStart;

let pointImg = [];
let showScores;

function preload() {  /// 62 graphic elements
  img[0] = loadImage("frog00.png");
  img[1] = loadImage("frog01.png");
  img[2] = loadImage("frogDead02.png");
  img[3] = loadImage("frogDead01.png");
  img[4] = loadImage("frog02.png");
  car[0] = loadImage("car1.png");
  car[1] = loadImage("car2.png");
  car[2] = loadImage("car3.png");
  car[3] = loadImage("car4.png");
  car[4] = loadImage("car5.png");
  car[5] = loadImage("car6.png");
  car[6] = loadImage("car7.png");
  car[7] = loadImage("car8.png");
  car[8] = loadImage("car9.png");
  car[9] = loadImage("car10.png");
  car[10] = loadImage("car11.png");
  car[11] = loadImage("car12.png");
  car[12] = loadImage("car13.png");
  car[13] = loadImage("car14.png");
  car[14] = loadImage("car15.png");
  car[15] = loadImage("car16.png");
  car[16] = loadImage("car17.png");
  car[17] = loadImage("car18.png");
  car[18] = loadImage("car19.png");
  car[19] = loadImage("car20.png");
  car[20] = loadImage("car21.png");
  car[21] = loadImage("car22.png");
  car[22] = loadImage("car23.png");
  car[23] = loadImage("car24.png");
  carCar[0] = loadImage("car25.png");
  carCar[1] = loadImage("car26.png");
  logs[0] = loadImage("log00.png");
  logs[1] = loadImage("log01.png");
  logs[2] = loadImage("log02.png");
  turtle[0] = loadImage("turtle00.png");
  turtle[1] = loadImage("turtle00.png");
  turtle[2] = loadImage("turtle01.png");
  turtle[3] = loadImage("turtle02.png");
  turtle[4] = loadImage("turtle03.png");
  turtle[5] = loadImage("triturtle00.png");
  turtle[6] = loadImage("triturtle00.png");
  turtle[7] = loadImage("triturtle01.png");
  turtle[8] = loadImage("triturtle02.png");
  turtle[9] = loadImage("triturtle03.png");
  grass[0] = loadImage("midway.png");
  grass[1] = loadImage("safetyZone.png");
  home[0] = loadImage("home00.png");
  home[1] = loadImage("home01.png");
  home[2] = loadImage("home02.png");
  lillyImg[0] = loadImage("lilly00.png");
  snakeImg[0] = loadImage("snake00.png");
  snakeImg[1] = loadImage("snake01.png");
  snakeImg[2] = loadImage("snake02.png");
  snakeImg[3] = loadImage("snake03.png");
  gatorImg[0] = loadImage("gator03.png");
  gatorImg[1] = loadImage("gator02.png");
  gatorImg[2] = loadImage("gator01.png");
  gatorImg[3] = loadImage("gator00.png");
  gatorImg[4] = loadImage("gator04.png");
  gatorImg[5] = loadImage("gator05.png");
  flyImg = loadImage("fly00.png");
  tFont = loadFont("Retroica.ttf");
  pointImg[0] = loadImage('pointTable.png');
}
function setup() {
  frameRate(30);
  createCanvas(960, 960);
  imageMode(CENTER);
  rectMode(CENTER);
  strokeCap(SQUARE);
  textFont(tFont);
  textAlign(CENTER);
  textSize(50);
  unit = 60;
  timeLimit = 60;
  timer = timeLimit;
  inWater = 0;
  godLike = 0;
  pauseOn = 0;
  floatCount = 0;
  gameEndLane = 4;
  showSwitch = 300;
  showState = 0;
  showTime[0] = 750;
  showTime[1] = 1300;
  showScores = new scoreMaker();

  showBill = new pointTable();
  homeBay = new homeBayMaker();
  fly = new flyInBay();
  gator = new gatorInBay();
  for (let n = 0; n < numOfLanes; n++) {
    road[n] = new roadMaker(n);
    water[n] = new waterMaker(n);
  }
  player = new playerMaker();
  deadFrog = new deadFrogMaker();
  snake = new snakeMaker();
  snakeLog = new snakeOnLog();
  levelUp = new levelUpMaker();
  friend = new frogFriend();
  
  background(0, 255);
  back1 = createGraphics(960, 960);
  gridMaker();
  buttonMaker();
}
function reset() {
  unit = 60;
  timeLimit = 50;
  timer = timeLimit;
  showGrid = 1;
  player.spot = player.home.copy();
  player.pos = player.home.copy();
  player.bayFilled[0] = 0;
  player.bayFilled[1] = 0;
  player.bayFilled[2] = 0;
  player.bayFilled[3] = 0;
  player.bayFilled[4] = 0;
  player.fillQuant = 0;
}

function draw() {
  background(0, 255);
  if (!gameOver && !pauseOn) {
    generatrix();
  } else {
    if (gameOver) {
      gameEnd();
    }
    if (pauseOn) {
      image(back2, width / 2, height / 2);
      image(pointImg[0],width/2,height/2);
      push();
      textSize(60);
      textAlign(CENTER, CENTER);
      stroke(0, 32, 0, 255);
      strokeWeight(5);
      text("GAME PAUSED", width / 2, height * 0.4);
      noStroke();
      fill(200, 200, 64, 255);
      text("GAME PAUSED", width / 2, height * 0.4);
      pop();
    }
  }
  if (deadFrog.showDead && !gameOver) {
    for (let n = 0; n < numOfLanes; n++) {
      road[n].update(n);
      water[n].update(n);
    }
    push();
    strokeWeight(unit / 2);
    stroke(0, 255);
    line(unit / 4, 0, unit / 4, height);
    line(width - unit / 4, 0, width - unit / 4, height);
    pop();
    deadFrog.update();
  }
}
function generatrix() {
  if (!pauseOn && !deadFrog.showDead &&
     !levelUp.countOn) {
    if (!timerOff) {
      timer -= 0.05;
    }
    if (timer < 0) {
      timer = timeLimit;
      if (!godLike) {
        player.lives -= 1;
      }
      if (player.lives < 0) {
        gameOver = 1;
        player.lives = 0;
        timer = 0;
      }
      if (!godLike) {
        deadFrog.pos = player.pos.copy();
        deadFrog.showDead = 1;
        player.pos = player.home.copy();
        player.spot = player.pos.copy();
      }
    }
    
    /// kill activity output when frog dies
    if (!deadFrog.showDead) {
      if (!godLike) {
        image(back1, width / 2, height / 2);
      } else {
        image(back2, width/2, height/2);
      }
    }
    
    /// frog is in Water or Jumps into bay
    if (player.pos.y < 8 * unit && !player.jumping) {
      floatCount = 0;
      if (player.pos.y < 3*unit && !player.jumping) {
        floatCount = 1;  /// 0 = player dies at any spot
        player.checkBays();
                         /// 1 = player lives at any spot
      }
      if (floatCount > 0 && player.y < 3*unit) {
        player.pos = player.home.copy();
        player.spot = player.pos.copy();
        player.jumping = 1;
      }
    }

    /// Display the homebays
    for (let  n=0; n < homeBay.posX.length; n++){
      push();
      image(home[player.bayFilled[n]],homeBay.posX[n],2*unit);
      pop();
    }
    
    /// fly appearance
    if (random() < 0.0005 && !fly.flyCountOn && !gator.gatorCountOn) {
      fly.flyCountOn = 1;
    }
    if (fly.flyCountOn) {
      fly.update();
    }
    
    /// gator in bay appearance
    if (random() < 0.0005 && !gator.gatorCountOn) {
      fly.flyCountOn = 0;
      fly.flyCount = 0;
      gator.gatorCountOn = 1;
      gator.gatorCount = 0;
      gator.pickSpot();
    }
    if (gator.gatorCountOn) {
      gator.update();
    }
    
    /// Road & Water Lanes Updated
    for (let n = 0; n < numOfLanes; n++) {
      road[n].update(n);
      water[n].update(n);
    }
    
    /// Snakes in Midzone and on Log
    snake.update();
    snakeLog.onLogCount +=1;
    if (snakeLog.onLogCount > snakeLog.timeFrame) {
      snakeLog.update();
    }
    
    /// Friend Frog appearance
    if (random() < 0.005 && !friend.countOn &&
       level > 1) {
      friend.countOn = 1;
    }
    if (friend.countOn && !friend.caught) {
      friend.count += 1;
      if (friend.count > friend.countLimit) {
        friend.count = 0;
        friend.countOn = 0;
      }
    }
    if (friend.countOn) {
      /// Frog Friend Show
      friend.update();
      /// Frog Friend Carried?
      friend.checkPos();
    }
    if (friend.caught) {
      friend.update();
      friend.checkPos();
    }
    
    /// Frog has drowned or been bitten?
    if (floatCount === 0 && !player.jumping && !godLike) {
      deadFrog.showDead = 1;
      deadFrog.pos = player.spot.copy();
      player.pos = player.home.copy();
      player.spot = player.pos.copy();
    }
    
    /// Masking lines for edges
    push();
    strokeWeight(unit / 2);
    stroke(0, 255);
    line(unit / 4, 0, unit / 4, height);
    line(width - unit / 4, 0, width - unit / 4, height);
    pop();
    
    /// Update player with environment changes
    player.update();
    
  }
  /// Show LevelUp, if needed
  if (levelUp.countOn) {
    levelUp.update();
  }
  
  
  /// Display over the top of all other layers.
  playerStats();
  
}
function deadFrogMaker() {
  this.pos = createVector(player.pos.x, player.pos.y);
  this.timeDead = 0;
  this.showDead = 0;
  this.spinRate = 0.25;
  this.timeLimit = 100;
  this.cycle = 0;
  
  this.update = function () {
    this.cycle += 1;
    this.timeDead += 1;
    if (this.timeDead > this.timeLimit) {
      this.timeDead = 0;
      this.showDead = 0;
      timer = timeLimit;
      player.lives -= 1;
      player.jumpFacing = 0;
      friend.caught = 0;
      friend.count =0;
      friend.countOn =0;
      friend.pos = createVector(water[3].pos[2].x,
                                water[3].pos[2].y);
      if (player.lives < 0) {
        gameOver = 1;
        player.lives = 0;
      }
    }
    if (this.pos.y < 8 * unit) {
      this.spinRate = 0.1;
    } else {
      this.spinRate = 0.25;
    }
    image(back2, width / 2, height / 2);
    /// Road & Water Lanes Updated - Frozen
    for (let n = 0; n < numOfLanes; n++) {
      road[n].update(n);
      water[n].update(n);
    }
    snake.update();
    snakeLog.update();
    push();
    strokeWeight(unit / 2);
    stroke(0, 255);
    line(unit / 4, 0, unit / 4, height);
    line(width - unit / 4, 0, width - unit / 4, height);
    pop();
    player.update();
    push();
    translate(this.pos.x, this.pos.y);
    image(
      img[3],
      (unit / 2) * sin(this.cycle * 0.1),
      -unit - this.timeDead * 1.5
    );
    rotate(this.cycle * this.spinRate);
    image(img[2], 0, 0);
    pop();
  };
}

function playerMaker() {
  this.size = unit;
  this.home = createVector(8 * unit, 14 * unit);
  this.pos = this.home.copy();
  this.spot = this.pos.copy();
  this.jumpRate = 0.5;
  this.jumping = 0;
  this.jumpFacing = 0;
  this.lives = 4;
  this.inBay = 0; /// valid jump into bays booleen
  this.bayFilled = []; /// array of open or filled bays
  this.fillQuant = 0; /// how many bays are filled
  this.bayFilled[0] = 0;
  this.bayFilled[1] = 0;
  this.bayFilled[2] = 0;
  this.bayFilled[3] = 0;
  this.bayFilled[4] = 0;
  
  this.update = function () {
    let gap = dist(this.pos.x, this.pos.y, this.spot.x, this.spot.y);
    if (gap < 2) {
      this.pos.x = this.spot.x;
      this.pos.y = this.spot.y;
      this.jumping = 0;
    } else {
      this.jumping = 1;
      this.pos.x = lerp(this.pos.x, this.spot.x, this.jumpRate);
      this.pos.y = lerp(this.pos.y, this.spot.y, this.jumpRate);
    }
    push();
    translate(this.pos.x, this.pos.y);
    if (this.jumpFacing === 1) {
      rotate(HALF_PI);
    }
    if (this.jumpFacing === 2) {
      rotate(PI);
    }
    if (this.jumpFacing === 3) {
      rotate(-HALF_PI);
    }
    if (!deadFrog.showDead ||
       floatCount === 0) {
      if (godLike) {
        stroke(255, 255);
        strokeWeight(3);
        noFill();
        if (floatCount === 0) {
          fill(100, 100, 255, 255);
        } else {
          fill(100, 255, 100, 255);
        }
        if (friend.caught) {
          fill(255,200,200,255);
        }
        circle(0, 0, unit);
      }
      image(img[this.jumping], 0, 0);
    }
    pop();
    if (friend.countOn && !deadFrog.showDead) {
      push();
      if (!friend.caught) {
        friend.pos = createVector(water[3].pos[2].x,
                                  water[3].pos[2].y);
        translate(friend.pos.x,friend.pos.y);
      } else {
        translate(this.spot.x,this.spot.y);
      }
      rotate(frameCount*0.01);
      image(img[4],0,0);
      pop();
    }
  };
  
  this.checkBays = function () {
    this.inBay = 0;
    for (let n = 0; n < homeBay.posX.length; n++) {
      let bayLeft = homeBay.posX[n] - unit/2;
      let bayRight = homeBay.posX[n] + unit/2;
      if (this.pos.x > bayLeft && this.pos.x < bayRight && !this.bayFilled[n]) {
        this.inBay = 1;
        this.bayFilled[n] = 1;
        this.fillQuant += 1;
        gator.bayCheck = n;
        fly.bayCheck = n;  /// holds the bay the player is in
        // gator.bayCheck = n; /// can use to compare fly or gator pos
      }
    }
    if (this.inBay) {
      this.pos = this.home.copy();
      this.spot = this.pos.copy();
      fly.checkPos();
      gator.checkPos();
        if (friend.caught) {
         friend.caught = 0;
          score += level*1000;
        }
        score += floor(timer*10);
        timer = timeLimit;
        if (this.fillQuant === 5) {
          score += 1000;
          level += 1;
          levelUp.countOn = 1;
          reset(); 
        }
    }
    if (!this.inBay) {
      floatCount = 0;
    }
  };
  
}
function roadMaker(i) {
  this.pos = [];
  this.vel = [];
  this.dir = [];
  this.car = [];
  this.wide = [];
  this.tall = [];
  this.start = [];
  this.quant = 3;
  this.spacing = 1;
  /// create 5 hazards on the roadway
  /// assign lane-specific dimensions and spacing
  /// i = current lane of cars
  for (let n = 0; n < this.quant; n++) {
    this.car[n] = floor(random(8));
    this.wide[n] = unit;
    this.tall[n] = unit;
    let x = (n + 1) * ((i + 2) * unit);
    if (i === 0) {
      this.wide[n] = 3 * unit;
      x = (n + 1) * (6 * unit);
    }
    if (i === 1) {
      x = (n + 1) * (6 * unit);
    }
    this.pos[n] = createVector(x, 8 * unit + (i + 1) * unit);
    this.vel[n] = i + 1;
    if (i === 1) {
      this.vel[n] = i + 8;
    }
    this.dir[n] = 1;
    if (i % 2 === 0) {
      this.dir[n] = -1;
    }
  }

  this.update = function (ii) {
    for (let n = 0; n < this.pos.length; n++) {
     if (!deadFrog.showDead) { 
        this.pos[n].x += this.vel[n] * this.dir[n];
        if (
          abs(this.pos[0].x - this.pos[this.pos.length - 1].x) <
          this.wide[n] * 2
        ) {
          this.pos[0].x += this.wide[n];
        }
        if (this.pos[n].x > width + this.wide[n] && ii % 2 != 0) {
          this.pos[n].x = -this.wide[n];
          this.car[n] = floor(random(8));
        }
        if (this.pos[n].x < -this.wide[n] && ii % 2 === 0) {
          this.pos[n].x = width + this.wide[n];
          this.car[n] = floor(random(8));
        }
    }
      push();
      noFill();
      /// check for collisions with cars
      let frogX = player.spot.x;
      let frogY = player.spot.y;
      let carX = this.pos[n].x;
      let carY = this.pos[n].y;
      let touchX = dist(frogX, 0, carX, 0);
      let touchY = dist(0, frogY, 0, carY);
      let bodiesX = this.wide[n] * 0.4 + player.size * 0.4;
      let bodiesY = this.tall[n] * 0.4 + player.size * 0.4;
      if (touchX < bodiesX && touchY < bodiesY && !godLike) {
        deadFrog.showDead = 1;
        deadFrog.pos = player.spot.copy();
        player.pos = player.home.copy();
        player.spot = player.pos.copy();
      }
      translate(this.pos[n].x, this.pos[n].y);
      if (this.dir[n] === -1) {
        rotate(-PI);
      }
      if (ii > 1 && ii != 2 && this.car[n] != 7 && this.car[n] !=6) {
        image(car[this.car[n]], 0, 0);
      }
      if (ii === 0 && this.car[n] != 7 && this.car[n] !=6) {
        rotate(PI);
        image(car[this.car[n] + 8], 0, 0);
      }
      if (ii === 1 && this.car[n] !=7 && this.car[n] !=6) {
        image(car[this.car[n] + 16], 0, 0);
      }
      if (ii === 2 && this.car[n] != 7 && this.car[n] !=6) {
        image(car[this.car[n]],0,0);
      }
      if (this.car[n] === 7) {
        image(carCar[1],0,0);
      }
      if (this.car[n] === 6) {
        image(carCar[0],0,0);
      }
      pop();
    } /// end of loop
  };
}
function waterMaker(i) {
  this.pos = [];
  this.vel = [];
  this.dir = [];
  this.turtle = [];
  this.wide = [];
  this.tall = [];
  this.start = [];
  this.quant = 1;
  this.spacing = 1;
  this.sinking = 0;
  this.sinkPic = 0;


  /// create 5 hazards in waterway
  /// assign lane-specific dimensions and spacing
  /// i = current path in waterway
  if (i === 0) {
    this.quant = 9;
  }
  if (i === 1) {
    this.quant = 9;
  }
  if (i === 2) {
    this.quant = 10;
  }
  if (i === 3) {
    this.quant = 9;
  }
  if (i === 4) {
    this.quant = 8;
  }
  
  // this.quant = 8;
  for (let n = 0; n < this.quant; n++) {
    let x = (n+1)*(6*unit)-(width*1.5);
    if (i%2 === 0) {
      x = (n+1)*(6*unit)-(width);
    }
    this.turtle[n] = 0;
    if (i === 0) {  /// logs long
      this.wide[n] = logs[2].width;
      this.tall[n] = unit;
    }
    if (i === 1) { /// double turtle
      this.wide[n] = 3 * unit;
      this.tall[n] = unit;
    }
    if (i === 2) { /// log short
      this.wide[n] = unit;
      this.tall[n] = unit;
        /// gator check assignment is i = 2, n = 0  row, log element
      if (n === 0) {
        this.wide[n] = gatorImg[4].width; /// gator size
        this.tall[n] = unit;
      }
    }
    if (i === 3) { /// log long
      this.wide[n] = 2 * unit;
      this.tall[n] = unit;
    }
    if (i === 4) { /// triple turtle
      this.wide[n] = 3 * unit;
      this.tall[n] = unit;
    }
   
    this.pos[n] = createVector(x, 2 * unit + (i + 1) * unit);
    this.vel[n] = i + 2;
    if (i === 0) {
      this.vel[n] = 3;
    }
    this.dir[n] = 1;
    if (i % 2 === 0) {
      this.dir[n] = -1;
    }
  }
  this.cycle = 0;

  this.update = function (ii) {
    this.cycle += 1;
    for (let n = 0; n < this.pos.length; n++) {
      
      if (!deadFrog.showDead){
        this.sinking = sin(n * 10 + ii * 10 + this.cycle * 0.032);
        this.sinkPic = floor(map(this.sinking, -1, 1, 0, 5));
        this.pos[n].x += this.vel[n] * this.dir[n];
        let dbetween = dist(this.pos[0].x,0,
                            this.pos[2].x,0);
        if (dbetween < this.wide[0] && ii === 0) {
          this.pos[0].x = this.pos[2].x + this.wide[0];
        }
        dbetween = dist(this.pos[0].x,0,
                            this.pos[1].x,0);
        if (dbetween < this.wide[0] && ii === 2) {
          this.pos[0].x = this.pos[1].x - this.wide[0];
        }
        
        if (this.pos[n].x > width*1.8 && ii % 2 != 0) {
          this.pos[n].x = -width*1.8;
          this.turtle[n] = 0;
          if (ii === gameEndLane && n === 0) {
              gameEndLane -= 1;
              if (gameEndLane < 0) {
                gameEndLane = 4;
              }
          } 
        }
        if (this.pos[n].x < -width*1.8 && ii % 2 === 0) {
          this.pos[n].x = width*1.8;
          this.turtle[n] = 0;
          if (ii === gameEndLane && n === 0) {
              gameEndLane -= 1;
              if (gameEndLane < 0) {
                gameEndLane = 4;
              }
          } 
        }
      }
      push();
      stroke(255);
      noFill();
      
      /// check for sinking in water
      /// or riding floating objects
      let frogX = player.pos.x;
      let frogY = player.pos.y;
      let turtleX = this.pos[n].x;
      let turtleY = this.pos[n].y;
      let touchX = dist(frogX, 0, turtleX, 0);
      let touchY = dist(0, frogY, 0, turtleY);
      let bodiesX = this.wide[n] * 0.4 + player.size * 0.4;
      let bodiesY = this.tall[n] * 0.4 + player.size * 0.4;

      /// jump onto Object
      if (touchX < bodiesX && touchY < bodiesY && !player.jumping) {
        player.spot.x += this.vel[n] * this.dir[n];
        player.pos.x = player.spot.x;
        floatCount += 1;
        
        //// Gator swimming with logs in 3rd row
        /// on gator's head
        if (ii === 2 && n === 0 && !godLike) {
          if (frogX < turtleX) {
              deadFrog.showDead = 1;
              deadFrog.pos = player.spot.copy();
              player.pos = player.home.copy();
              player.spot = player.pos.copy();
          }
        }

        /// triple turtle row
        if (this.sinkPic === 0 && ii === 4) {
          if (!godLike && ii != 1 && n != 0) {
            deadFrog.showDead = 1;
            deadFrog.pos = player.spot.copy();
            player.pos = player.home.copy();
            player.spot = player.pos.copy();
          }else {
            floatCount = 0;
          }
        }
        
        /// double turtle row
        if (this.sinkPic === 4 && ii === 1) {
          if (!godLike && ii != 4 && n != 2) {
            deadFrog.showDead = 1;
            deadFrog.pos = player.spot.copy();
            player.pos = player.home.copy();
            player.spot = player.pos.copy();
          } else {
            floatCount = 0;
          }
        }
      }
      
      /// carried past the edge
      if (frogX < unit * 0.5 || frogX > width - unit * 0.5) {
        deadFrog.showDead = 1;
        deadFrog.pos = player.spot.copy();
        player.pos = player.home.copy();
        player.spot = player.pos.copy();
      }
      
      translate(this.pos[n].x, this.pos[n].y);
      if (this.dir[n] === -1) {
        rotate(-PI);
      }
      if (ii === 1) {
          rotate(-PI);
          image(turtle[this.sinkPic], 0, 0);
      }
      if (ii === 2) {
        if (n != 0) {
        rotate(PI);
        image(logs[0], 0, 0);
        }  else {
          rotate(-PI);
          let gatorMouth = floor(abs(cos(frameCount*0.05)*2));
          image(gatorImg[4+gatorMouth],0,0);
        }
      }
      if (ii === 3) {
        image(logs[1], 0, 0);
      }
      if (ii === 4) {
          rotate(-PI);
          image(turtle[9 - this.sinkPic], 0, 0);
      }
      if (ii === 0) {
        rotate(PI);
        image(logs[2], 0, 0);
      }
      
      pop();
    } /// end of loop
    if (player.pos.y > 7 * unit) {
      floatCount = 1;
    }
  };
}

function snakeMaker() {
  this.pos = createVector(-2*unit,8*unit);
  this.vel = 3;
  this.dir = 1;
  this.snakeCount = 0;
  this.size = unit*2;
  
  this.update = function() {
    if (!deadFrog.showDead){
      this.pos.x += this.vel*this.dir;
      this.snakeCount += 0.25;
      if (this.pos.x > width+this.size) {
        this.pos.x = width+this.size;
        this.dir = -1;
      }
      if (this.pos.x < -this.size) {
        this.pos.x = -this.size;
        this.dir = 1;
      }
    }
    let whichOne = floor(abs(sin(this.snakeCount)*2));
    push();
    translate(this.pos.x,this.pos.y);
    if (this.dir === 1) {
      image(snakeImg[whichOne],0,0);
    } else {
      image(snakeImg[whichOne+2],0,0);    
    }
    pop();
    let snakeLeft = this.pos.x-this.size/2;
    let snakeRight = this.pos.x+this.size/2;
    let frogX = player.pos.x;
    let frogY = player.pos.y;
    if (frogX > snakeLeft &&
        frogX < snakeRight &&
       frogY === 8*unit &&
       !godLike) {
          deadFrog.showDead = 1;
          deadFrog.pos = player.spot.copy();
          player.pos = player.home.copy();
          player.spot = player.pos.copy();
    }
  }
  
}
function snakeOnLog() {
  this.pos = createVector(water[0].pos[0].x,water[0].pos[0].y);
  this.vel = 4;
  this.dir = 1;
  this.snakeCount = 0;
  this.size = unit*2;
  this.wide = water[0].wide[0];
  this.tall = water[0].tall[0];
  this.onLogCount = 0;
  this.timeFrame = 300;
  this.update = function(){

      if (this.onLogCount > this.timeFrame+500 &&
         !levelUp.countOn) {
        this.onLogCount = 0;
      }

      let homeX = water[0].pos[0].x;
      let homeY = water[0].pos[0].y;
      let logLeft = homeX-unit*1.5;
      let logRight = homeX+unit*1.5;

  if (!deadFrog.showDead){
      this.pos.x += this.vel*this.dir;
      this.snakeCount += 0.25;
      if (this.pos.x > logRight) {
        this.pos.x = logRight;
        this.dir = -1;
      }
      if (this.pos.x < logLeft) {
        this.pos.x = logLeft;
        this.dir = 1;
      }
  }
    let whichOne = floor(abs(sin(this.snakeCount)*2));
    
    push();
    translate(this.pos.x,this.pos.y);
    if (this.dir === 1) {
      image(snakeImg[whichOne],0,0);
    } else {
      image(snakeImg[whichOne+2],0,0);    
    }
    pop();
    
    let snakeLeft = this.pos.x-this.size/2;
    let snakeRight = this.pos.x+this.size/2;
    let frogX = player.pos.x;
    let frogY = player.pos.y;
    if (frogX > snakeLeft &&
        frogX < snakeRight &&
       frogY === 3*unit &&
       !godLike) {
          deadFrog.showDead = 1;
          deadFrog.pos = player.spot.copy();
          player.pos = player.home.copy();
          player.spot = player.pos.copy();
    }
    
  }
}
function gatorInBay() {
  this.pos = [];
  this.posY = 2*unit+unit*0.25;
  this.alive = [];
  this.gatorCount = 0;
  this.gatorCountLimit = 200;
  this.gatorCountOn = 0;
  this.pos[0] = homeBay.posX[0]; 
  this.pos[1] = homeBay.posX[1]; 
  this.pos[2] = homeBay.posX[2]; 
  this.pos[3] = homeBay.posX[3]; 
  this.pos[4] = homeBay.posX[4]; 
  for (let n = 0; n < 5; n++) {
    this.alive[n] = 0;
  }
  this.pick = 0;
  this.bayCheck = 0;
  this.whichOne = 0;
  
  this.update = function() {
    this.gatorCount += 1;
    if (this.gatorCount > this.gatorCountLimit) {
      this.gatorCount = 0;
      this.alive[this.pick] = 0;
      this.gatorCountOn = 0;
    }
    if (this.gatorCount%50 === 0) {
      this.whichOne += 1;
      if (this.whichOne > 3) {
        this.whichOne = 0;
      }
    }
    push();
      translate(this.pos[this.pick],
               this.posY);
      if (this.whichOne > 1) {
        image(gatorImg[this.whichOne],0,0);
      }
      pop();
      if (this.whichOne < 2) {
        image(gatorImg[this.whichOne],this.pos[this.pick],2*unit);
        image(home[0],this.pos[this.pick],2*unit);
      }
  }
  
  this.pickSpot = function() {
    this.pick = floor(random(5));
    this.whichOne = 0;
    if (player.bayFilled[this.pick]) {
      this.gatorCountOn = 0;
    } else {
      this.alive[this.pick] = 1;
    }
  }
  
  this.checkPos = function() {
    if (this.bayCheck === this.pick &&
        this.alive[this.pick]) {
      if (this.whichOne > 1) { 
        deadFrog.showDead = 1;
        deadFrog.pos.x = this.pos[this.pick];
        deadFrog.pos.y = this.posY;
        player.fillQuant -= 1;
        player.bayFilled[this.pick] = 0;
        player.pos = player.home.copy();
        player.spot = player.pos.copy();
      } else {
        this.gatorCount = 0;
        this.gatorCountOn = 0;
        this.alive[this.pick] = 0;
      }
    }
  }
}
function flyInBay() {
  this.pos = [];
  this.posY = 2 * unit;
  this.alive = [];
  this.flyCount = 0;
  this.flyCountLimit = 150;
  this.flyCountOn = 0;
  this.pos[0] = homeBay.posX[0]; 
  this.pos[1] = homeBay.posX[1]; 
  this.pos[2] = homeBay.posX[2]; 
  this.pos[3] = homeBay.posX[3]; 
  this.pos[4] = homeBay.posX[4]; 
  for (let n = 0; n < 5; n++) {
    this.alive[n] = 0;
  }
  this.pick = 3;
  this.bayCheck = -1;
  
  this.update = function() {
    if (this.flyCount === 0) {
      this.pick = floor(random(5));
      for (let n = 0; n < homeBay.posX.length; n++) {
        if (player.bayFilled[this.pick] === 1) {
          this.flyCount = -1;
        }
      }
      if (this.flyCount === 0) {
        this.alive[this.pick] = 1;
      }
    }
    this.flyCount += 1;
    if (this.flyCount > this.flyCountLimit) {
      this.flyCount = 0;
      this.alive[this.pick] = 0;
      this.flyCountOn = 0;
    }
    if (this.flyCount > 0) {
      push();
      translate(this.pos[this.pick],
               this.posY);
      image(flyImg,0,0);
      pop();
    }
  }
  
  this.checkPos = function() {
    if (this.bayCheck === this.pick && this.alive[this.pick]) {
      score += floor(level * 1000);
      this.flyCount = 0;
      this.alive[this.pick] = 0;
      this.flyCountOn = 0;
      player.bayFilled[fly.backCheck] = 1;
    }
  }
}
function frogFriend() {
  this.pos = createVector(water[3].pos[2].x,
                          water[3].pos[2].y);
  this.alive = 0;
  this.count = 0;
  this.countOn = 0;
  this.caught = 0;
  this.countLimit = 175;
  
  this.update = function() {
    if (!this.caught) {
      this.pos = createVector(water[3].pos[2].x,
                            water[3].pos[2].y);
    } else {
      this.pos = createVector(player.pos.x,
                              player.pos.y);
    }
    /// see playerMaker for friend output
  } 
  
  this.checkPos = function() {
    let frogX = player.pos.x;
    let frogY = player.pos.y;
    let friendX = this.pos.x;
    let friendY = this.pos.y;
    let friendLeft = friendX-unit*0.8;
    let friendRight = friendX+unit*0.8;
    if (frogX > friendLeft && frogX < friendRight &&
       frogY > friendY-unit/2 &&
       frogY < friendY+unit/2) {
      this.caught = 1;
    } else {
      this.caught = 0;
    }
    if (friendX > width-unit) {
     this.count = 0;
     this.countOn = 0;
     this.caught = 0;  
    }
  }
}

function gameEnd() {
  image(back1, width / 2, height / 2);
  playerStats();
  for (let n = 0; n < numOfLanes; n++) {
    road[n].update(n);
    water[n].update(n);
  }
  push();
  strokeWeight(unit / 2);
  stroke(0, 255);
  line(unit / 4, 0, unit / 4, height);
  line(width - unit / 4, 0, width - unit / 4, height);
  pop();
  if (deadFrog.showDead && !godLike) {
    deadFrog.update();
  }
  push();
  strokeCap(ROUND);
  textAlign(CENTER);
  textSize(75);
  stroke(200,128,0, 255);
  strokeWeight(8);
  push();
  translate(water[gameEndLane].pos[0].x,
            water[gameEndLane].pos[0].y);
  text("GAME OVER", 0, 0);
  noStroke();
  textSize(75);
  fill(0,255);
  text("GAME OVER", 0, 0);
  pop();
  
  textSize(50);
 
  push();
  translate(road[gameEndLane].pos[0].x,
           road[gameEndLane].pos[0].y);
  stroke(200,128,0, 255);
  strokeWeight(8);
  text("Press r to reset or start.", 0, unit);
  textSize(50);
  noStroke();
  fill(0,255);
  text("Press r to reset or start.", 0, unit);
  pop();
  pop();
  
  //// points table animation
    showSwitch += 1;
  if (showSwitch > showTime[showState]) {
    if (!showState) {
      showState = 1;
    } else {
      showState = 0;
      showSwitch = 0;
      showBill.reset();
      // showBill.demo = -1;
    }
  }
  if (showSwitch > 500 &&
      showSwitch < 750) {
    showScores.update();
  }
  if (showState) {
    showBill.update();
  }
}
function levelUpMaker() {
  this.countOn = 1;
  this.timer = 0;
  this.timeLimit = 50;
  
  this.update = function() {
    this.timer += 1;
    if (this.timer > this.timeLimit) {
      this.timer = 0;
      this.countOn = 0;
    }
    image(back1,width/2,height/2);
    for (let  n=0; n < homeBay.posX.length; n++){
      let spin = map(this.timer,0,this.timeLimit,
                     0,TAU);
      push();
      translate(homeBay.posX[n],2*unit);
      image(home[0],0,0);
      rotate(spin);
      image(home[2],0,0);
      pop();
    }
   
    push();
    textSize(65);
    textAlign(CENTER,CENTER);
    stroke(0,255);
    strokeWeight(3);
    text('LEVEL '+level,width/2,height/2);
    noStroke();
    fill(255,255);
    text('LEVEL '+level,width/2,height/2);
    pop();
  }
}

function keyPressed() {
  if (
    keyCode === LEFT_ARROW &&
    !player.jumping &&
    !gameOver &&
    !deadFrog.showDead
  ) {
    player.jumpFacing = 3;
    player.spot.x -= unit;
    if (player.spot.x < unit) {
      player.spot.x = unit;
    }
  }

  if (
    keyCode === RIGHT_ARROW &&
    !player.jumping &&
    !gameOver &&
    !deadFrog.showDead
  ) {
    player.jumpFacing = 1;
    player.spot.x += unit;
    if (player.spot.x > 900) {
      player.spot.x = 900;
    }
  }

  if (
    keyCode === UP_ARROW &&
    !player.jumping &&
    !gameOver &&
    !deadFrog.showDead
  ) {
    score += 10;
    player.jumpFacing = 0;
    player.spot.y -= unit;
    if (player.spot.y < 2 * unit) {
      player.spot.y = 2 * unit;
    }
  }

  if (
    keyCode === DOWN_ARROW &&
    !player.jumping &&
    !gameOver &&
    !deadFrog.showDead
  ) {
    player.jumpFacing = 2;
    player.spot.y += unit;
    if (player.spot.y > 840) {
      player.spot.y = 840;
    }
  }
  if (key === "f" || key === "F") {
    if (!freePlay) {
      freePlay = 1;
    } else {
      freePlay = 0;
    }
  }
  if (key === "r" || key === "R") {
    gameOver = 0;
    deadFrog.timeDead = 0;
    deadFrog.showDead = 0;
    timer = deadFrog.timeLimit;
    player.lives = 4;
    score = 0;
    levelUp.countOn = 1;
    reset();
  }
  if (key === "t" || key === "T") {
    if (!timerOff) {
      timerOff = 1;
    } else {
      timerOff = 0;
    }
  }
  if (key === "g" || key === "G") {
    if (!godLike) {
      godLike = 1;
    } else {
      godLike = 0;
    }
  }
  if (key === "q" || key === "Q") {
    gameOver = 1;
  }
  if (key === "p" || key === "P") {
    if (!pauseOn) {
      pauseOn = 1;
    } else {
      pauseOn = 0;
    }
  }
}


function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > height/2 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height/2) {
    if (!showButtons) {
      showButtons = 1;
      buttonUp.show();
      buttonDown.show();
      buttonLeft.show();
      buttonRight.show();
      buttonStart.show();
      buttonFree.show();
      buttonTimer.show();
    } else {
      showButtons = 0;
      buttonUp.hide();
      buttonDown.hide();
      buttonLeft.hide();
      buttonRight.hide();
      buttonStart.hide();
      buttonFree.hide();
      buttonTimer.hide();
    }
  }
}

function gridMaker() {
  back1.rectMode(CENTER);
  back1.imageMode(CENTER);
  back1.strokeCap(SQUARE);
  for (let x = 60; x < 960; x += 60) {
    for (let y = 60; y < 960; y += 60) {
      back1.push();
      back1.strokeWeight(1);
      back1.stroke(255, 255);
      if (!showGrid) {
        back1.noStroke();
      }
      back1.noFill();
      if (y > 120 && y < 480) {
        back1.fill(32, 64, 200, 255);
      }
      if (y > 480 && y < 840) {
        back1.fill(50, 50, 80, 255);
      }
      if (y === 480 || y === 840) {
        back1.fill(64, 0, 64, 255);
      }
      if (y < 180 && y > 60) {
        back1.fill(0, 64, 0, 255);
      }
      back1.rect(x, y, 60, 60);
      if (y > 480 && y < 840) {
      }
      back1.pop();
    }
  }
  back1.push();
  back1.image(grass[1], width / 2, 2 * unit);
  back1.image(grass[0], width / 2, 8 * unit);
  back1.image(grass[0], width / 2, 14 * unit);
  back1.pop();
  homeBay.showBays();
  back2 = back1.get(0,0,width,height);
  if (deadBackGround) {
    back2.filter(GRAY);
  } else {
    back2.filter(INVERT);
  }
}
function homeBayMaker() {
  this.posX = [];
  this.posY = 2 * unit;
  let count = 0;
  for (let x = 1; x < 15; x += 3) {
    this.posX[count] = x * unit + unit;
    count += 1;
  }

  this.showBays = function () {
    for (let n = 0; n < homeBay.posX.length; n++) {
      back1.push();
      back1.translate(homeBay.posX[n], this.posY);
      back1.noStroke();
      back1.fill(16, 32, 128, 255);
      back1.rect(0, 0, unit, unit);
      back1.image(home[0], 0, 0);
      back1.pop();
    }
  };
}

function playerStats() {
  if (score > hiscore) {
    hiscore = score;
  }
  push();
  textAlign(CENTER, CENTER);
  textSize(30);
  fill(32, 255, 32, 255);
  strokeWeight(1);
  stroke(0, 255);
  text("1-UP", 3 * unit, unit / 2);
  text("HI-SCORE", 7 * unit, unit / 2);
  if (score < hiscore) {
    text(nfc(hiscore), 7 * unit, unit);
  } else {
    text(nfc(hiscore), 7 * unit, unit);
  }
  text("LEVEL ",6*unit,15*unit);
  text(level,6*unit,15.5*unit);
  text("PLAYER SCORE", 12 * unit, unit / 2);
  text(nfc(score), 12 * unit, unit);
  textAlign(RIGHT);
  text("TIME", 15 * unit, 930);
  let timeLine = map(timer, 0, timeLimit, 810, 420);
  stroke(16, 32, 16, 255);
  strokeWeight(22);
  line(810, 927, 420, 927);
  stroke(32, 200, 32, 255);
  strokeWeight(20);
  line(810, 927, timeLine, 927);
  pop();
  for (let n = 1; n < player.lives+1; n++) {
    push();
    translate(unit * n, 925);
    image(img[0], 0, 0);
    pop();
  }
}
function pointTable() {
  this.pos = createVector(width/2,height/2);
  this.show = 0.001;
  this.vel = 0.01;
  this.dir = 1;
  
  this.update = function() {
    this.show += this.vel*this.dir;
    if (this.show > 1) {
      this.show = 1;
    }
    if (showSwitch === 1200) {
      this.dir = -1;
    }
    if (this.show < 0.001) {
      this.show = 0.001;
    }
    let posAdj = map(this.show,0.001,1,width/2,0);
    push();
    // translate(width/2,height/2);
    scale(1,this.show);
    image(pointImg[0],width/2,this.pos.y+posAdj);
    pop();
  }
  
  this.reset = function() {
    this.show = 0.001; 
    this.dir = 1;
  }
  
}
function scoreMaker() {
  this.score = [];
  this.quant = 10;
  this.name = [];
  this.level = [];
  let levelCounter = 1;
  this.score[9] = floor(random(200,3500));
  for (let n = this.quant-1; n > -1; n--) {
    if (n < 9) {
      this.score[n] = floor(this.score[n+1]+random(200,3500));
    } 
     
    if (random() > 0.75) {
      this.level[n] = levelCounter;
    }
    hiscore = this.score[0];
  }
  this.name[0] = "ACE";
  this.name[1] = "ACE";
  this.name[2] = "DIK";
  this.name[3] = "NEO";
  this.name[4] = "LUV";
  this.name[5] = "JKR";
  this.name[6] = "LIP";
  this.name[7] = "PEE";
  this.name[8] = "NUB";
  this.name[9] = "GEO";
  this.y = height*0.05;
  
  
  this.update = function() {
    push();
    translate(width/2,height/2);
    stroke(0,100,0,255);
    strokeWeight(5);
    fill(255,175);
    rect(0,0,width*0.6,height*0.65,80);
    pop();
    push();
    textAlign(CENTER,CENTER);
    textSize(40);
    stroke(0,255)
    strokeWeight(6);
    text("TOP 10 HIGHEST SCORES",width/2,height*0.25)
    stroke(255,255);
    strokeWeight(2);
    noFill();
    text("TOP 10 HIGHEST SCORES",width/2,height*0.25)
    noStroke();
    fill(0,255);
    text("TOP 10 HIGHEST SCORES",width/2,height*0.25)
    pop();
    for (let n = 0; n < this.name.length; n++) {
      push();
      textSize(35);
      translate(width/2,this.y*(n+1)+height*0.28);
      stroke(255,255);
      strokeWeight(2);
      noFill();
      textAlign(LEFT);
      text(this.name[n],-width*0.25,0);
      textAlign(RIGHT);
      text(nfc(this.score[n]), width*0.25,0);
      noStroke();
      fill(0,255);
      textAlign(LEFT);
      text(this.name[n],-width*0.25,0);
      textAlign(RIGHT);
      text(nfc(this.score[n]), width*0.25,0);
      pop();
    }
  } 
}

function buttonMaker(){
    buttonUp = createButton("UP");
    buttonDown = createButton("DOWN");
    buttonLeft = createButton("LEFT");
    buttonRight = createButton("RIGHT");
    buttonStart = createButton("START");
    buttonFree = createButton("FREE PLAY");
    buttonTimer = createButton("TIMER");
    buttonUp.position(width / 2-100, height * 1.6);
    buttonDown.position(width / 2-100, height * 1.6 + 300);
    buttonLeft.position(width / 2 - 300, height * 1.6 + 150);
    buttonRight.position(width / 2 + 100, height * 1.6 + 150);
    buttonStart.position(width / 2 -100, 200);
    buttonFree.position(width / 2 -300, 200);
    buttonTimer.position(width / 2 +100, 200);
    buttonUp.size(200,200);
    buttonDown.size(200,200);
    buttonLeft.size(200,200);
    buttonRight.size(200,200);
    buttonStart.size(200,200);
    buttonFree.size(200,200);
    buttonTimer.size(200,200);
    buttonUp.mousePressed(tapUp);
    buttonDown.mousePressed(tapDown);
    buttonLeft.mousePressed(tapLeft);
    buttonRight.mousePressed(tapRight);
    buttonStart.mousePressed(tapStart);
    buttonFree.mousePressed(tapFree);
    buttonTimer.mousePressed(tapTimer);
}
function tapUp() {
  if (!player.jumping && !gameOver && !deadFrog.showDead) {
    score += 10;
    player.jumpFacing = 0;
    player.spot.y -= unit;
    if (player.spot.y < 2 * unit) {
      player.spot.y = 2 * unit;
    }
  }
}
function tapDown() {
  if (!player.jumping && !gameOver && !deadFrog.showDead) {
    player.jumpFacing = 2;
    player.spot.y += unit;
    if (player.spot.y > 840) {
      player.spot.y = 840;
    }
  }
}
function tapLeft() {
  if (!player.jumping && !gameOver && !deadFrog.showDead) {
    player.jumpFacing = 3;
    player.spot.x -= unit;
    if (player.spot.x < unit) {
      player.spot.x = unit;
    }
  }
}
function tapRight() {
  if (!player.jumping && !gameOver && !deadFrog.showDead) {
    player.jumpFacing = 1;
    player.spot.x += unit;
    if (player.spot.x > 900) {
      player.spot.x = 900;
    }
  }
}
function tapStart() {
  gameOver = 0;
  deadFrog.timeDead = 0;
  deadFrog.showDead = 0;
  timer = deadFrog.timeLimit;
  player.lives = 4;
  reset();
}
function tapFree() {
  if (!godLike) {
    godLike = 1;
  } else {
    godLike = 0;
  }
}
function tapTimer() {
  if (!timerOff) {
    timerOff = 1;
  } else {
    timerOff = 0;
  }
}
