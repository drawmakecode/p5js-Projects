//// Budding Spring
//// by Ed Cavett
//// March 2023
//// fxHash Compliant NFT

let minLen;
let maxLen;
let bud;
let colMin;
let colMax;
let backSet;
let sky;
let colSelect;
let mt;
let fminLen;
let fmaxLen;
let img;
let colR;
let colG;
let colB;
let birds;
let pineHSet;
let backRND;
let fog;

function preload() {
  img = loadImage("buddingSpringCard04.jpg");
}

function setup() {
  createCanvas(2400, 1200);
  let hashGen = fxrand() * 10000;
  randomSeed(hashGen);
  noiseSeed(hashGen);
  
  maxLen = height * 0.24;
  backRND = random();
  pineHSet = 0.00035;
  if (backRND < 0.5) {
    pineHset = 0.00016;
    createCanvas(1200, 2400);
    maxLen = width * 0.24;
  }
  textAlign(CENTER);

  push();
  background(random(100), random(75), 0, 255);
  for (let y = 0; y < height; y++) {
    let alph = map(y, 0, height, 128, -64);
    stroke(0, random(50, 100), random(50, 125), alph);
    strokeWeight(5);
    line(0, y, width, y);
  }
  for (let r = img.width * 0.8; r < img.width * 1.01; r++) {
    let alph = map(r, img.width * 0.8, img.width * 1.01, 255, 20);
    push();
    rectMode(CENTER);
    noFill();
    strokeWeight(2);
    stroke(0, alph);
    rect(width * 0.5 + 10, height * 0.5 + 10, r, r);
    pop();
  }
  translate(width * 0.5 - img.width * 0.5, height * 0.5 - img.height * 0.5);

  image(img, 0, 0);
  pop();

  fmaxLen = height * 0.08;
  fminLen = maxLen * 0.1;
  minLen = maxLen * 0.1;
  swMax = maxLen * 0.1;
  swMin = swMax * 0.1;
  colR = random(200, 225);
  colG = random(150, 200);
  colB = random(200, 225);
  if (backRND < 0.5) {
    colR = random(175, 200);
    colG = random(200, 225);
    colB = random(225, 255);
  }
  colSelect = floor(random(2));
}

function draw() {
  frameRate(3);
  if (frameCount > 10 && frameCount < 17) {
    generatrix();
  }

  if (frameCount === 18) {
    fxpreview();
    console.log("Budding Spring");
    console.log("by Ed Cavett (c) 2023");
    noLoop();
  }

  if (frameCount === 17) {
    push();
    translate(-width * 0.1, height * 0.42);
    rotate(HALF_PI);
    colMin = 225;
    colMax = 25;
    if (random() < 0.5) {
      treeMaker(maxLen);
    }
    translate(height * 0.1, 0);
    if (random() < 0.5) {
      treeMaker(maxLen * random(0.6, 1.1));
    }
    pop();
    push();
    translate(width * 1.1, height * 0.58);
    rotate(-HALF_PI);
    colMin = 25;
    colMax = 225;
    if (random() < 0.5) {
      treeMaker(maxLen);
    }
    translate(-height * 0.1, 0);
    if (random() < 0.5) {
      treeMaker(maxLen * random(0.6, 1.1));
    }
    pop();
  }
}

function generatrix() {
  bud = new budMaker();
  birds = new birdMaker();
  mt = new mtMaker();
  sky = new skyMaker();
  backSet = new backMaker();
  fog = new fogMaker();

  if (frameCount === 11) {
    if (random() < 0.5) {
      background(0, colG, colB, 255);
    } else {
      background(colR, 0, colB, 255);
    }
    cloudMaker();
    background(255, random(16, 32));
  }

  if (frameCount === 12) {
    for (let ypos = height * 0.32; ypos < height * 0.76; ypos += 3) {
      push();
      translate(0, ypos);
      mt.make(ypos);
      pop();
      push();
      textSize(50);
      stroke(0, 255);
      strokeWeight(1);
      fill(0, 255);
      text(
        "Rendering can take up to 2 minutes.",
        width * 0.5,
        height * 0.9
      );
      text(
        "Please wait...",
        width * 0.5,
        height * 0.95
      );
      
      pop();
    }
    let fogPos = createVector(random(width*0.25,width*0.75),height*0.45);
    for (let n = 0; n < 18; n ++) {
   push();
      translate(fogPos.x,fogPos.y);
      fog.make();
   pop();
    }
    background(255, random(16, 32));
  }

  if (frameCount === 13) {
    for (let j = 0; j < 3; j++) {
      for (let t = 0; t < 2; t++) {
        push();
        translate(sky.gapX * 0.5 * t, 0);
        sky.update(); /// Midground
        pop();
      }
      background(colR, colG, colB, random(32, 64));
      push();
      translate(
        random(width * 0.4, width * 0.6),
        random(height * 0.2, height * 0.32)
      );
      birds.make();
      pop();
    }
  }
  if (frameCount === 14) {
    backSet.ground();
    backSet.grass();
    background(colR, colG, colB, 36);
  }
}

function fogMaker() {
  this.xoff = [];
  this.yoff = [];
  this.pos = [];
  this.size = [];
  this.quant = floor(50,100);
  let xRnd = random(10000);
  let yRnd = random(10000);
  if (backRND < 0.5) {
    this.layout = width;
    this.stepX = 64;
    this.stepY = 32;
  } else {
    this.layout = height;
    this.stepX = 32;
    this.stepY = 16;
  }
  for (let n = 0; n < this.quant; n++) {
    let vec = p5.Vector.random2D();
    vec.x *= random(1, 16);
    vec = vec.mult(50);
    this.pos.push(vec);
    this.xoff.push((n + xRnd) * 0.1);
    this.yoff.push((n + yRnd) * 0.1);
    this.size.push(this.layout * random(0.1, 0.16));
  }
  
  this.make = function () {
    // for (let t = 0; t < 300; t ++) {
    for (let i = 0; i < this.pos.length; i++) {
      let x = map(
        noise((i + this.xoff[i]) * 0.05, frameCount * 0.05),
        0,
        1,
        -this.stepX,
        this.stepX
      );
      let y = map(
        noise((i + this.yoff[i]) * 0.05, frameCount * 0.05),
        0,
        1,
        -this.stepY,
        this.stepY
      );
      this.pos[i].x += x;
      this.pos[i].y += y;
    }
    // }
    for (let i = 0; i < this.pos.length; i++) {
      push();
      if (backRND < 0.5) {
        stroke(200, 175, 200, 4);
      } else {
        stroke(175, 200, 175, 4);
      }
      strokeWeight(this.size[i]);
      point(this.pos[i].x, this.pos[i].y);
      for (let p = 0; p < 25; p++) {
        let subCloud = p5.Vector.random2D();
        subCloud = subCloud.mult(random(this.size[i] * 0.75));
        push();
        translate(this.pos[i].x, this.pos[i].y);
        noStroke();
        if (backRND < 0.5) {
          fill(200, 175, 200, 8); // magenta
        } else {
          fill(175, 200, 175, 8); // grenn
        }

        let cloudZ = random(this.size[i] * 0.5);
        ellipse(subCloud.x, subCloud.y, cloudZ, cloudZ * random(0.36, 1));
        pop();
      }
      pop();
    }
  };
}

function birdMaker() {
  this.xoff = [];
  this.yoff = [];
  this.pos = [];
  this.quant = floor(random(16, 24));
  let xRnd = random(10000);
  let yRnd = random(10000);
  for (let n = 0; n < this.quant; n++) {
    let vec = p5.Vector.random2D();
    vec.x *= random(1, 10);
    vec = vec.mult(50);
    this.pos.push(vec);
    this.xoff.push((n + xRnd) * 0.1);
    this.yoff.push((n + yRnd) * 0.1);
  }

  this.make = function () {
    for (let t = 0; t < 300; t++) {
      for (let i = 0; i < this.pos.length; i++) {
        let x = map(noise((i + this.xoff[i]) * 0.01, t * 0.01), 0, 1, -1, 1);
        let y = map(noise((i + this.yoff[i]) * 0.01, t * 0.01), 0, 1, -1, 1);
        this.pos[i].x += x;
        this.pos[i].y += y;
      }
    }
    for (let i = 0; i < this.pos.length; i++) {
      push();
      stroke(50, 50, 75, 255);
      strokeWeight(random(2, 4));
      point(this.pos[i].x, this.pos[i].y);
      pop();
    }
  };
}

/// Creates the radial-gradiant background sky
function cloudMaker() {
  let size = 0;
  if (width < height) {
    size = height;
  } else {
    size = width;
  }
  push();
  for (let r = 1; r < size; r += 2) {
    let fade = map(r, 1, size, 300, 0);
    noFill();
    stroke(255, 200, 0, fade);
    strokeWeight(2);
    circle(width * 0.5, height * 0.5, r);
  }
  pop();
}

/// Foreground Budding Trees
function treeMaker(len) {
  this.gap = 2;
  push();
  translate(0, 0);
  let rotSet = map(len, minLen, maxLen, PI * 0.1, PI * 0.24);
  rotate(random(-rotSet * 0.5, 0));
  if (len === maxLen) {
    rotate(0);
  }
  let sw = map(len, minLen, maxLen, swMin, swMax);

  /// underlay
  push();
  beginShape();
  vertex(-sw * 0.5, 0);
  vertex(-sw * 0.8 * 0.5, -len);
  vertex(sw * 0.8 * 0.5, -len);
  vertex(sw * 0.5, 0);
  noStroke();
  fill(0, 255);
  endShape(CLOSE);
  pop();

  /// first branch
  for (let y = -len; y < 0; y += this.gap) {
    for (let x = -sw * 0.5; x < sw * 0.5; x += this.gap) {
      let posMod = createVector(random(-this.gap, this.gap));
      push();
      translate(x + posMod.x, y + posMod.y);
      rotate(random(TAU));
      stroke(map(x, -sw * 0.5, sw * 0.5, colMin, colMax), 200);
      strokeWeight(1);
      line(-sw * 0.1, 0, sw * 0.1, 0);
      if (random() < 0.005) {
        strokeWeight(sw * 0.2);
        for (let stx = 0; stx < sw * 2; stx += 1) {
          let sty = map(
            noise(len * 0.01, stx * 0.05),
            0,
            1,
            -sw * 0.5,
            sw * 0.5
          );
          stroke(random(50), 255);
          point(stx, sty);
        }
        push();
        translate(sw * 2, 0);
        bud.make();
        pop();
      }
      pop();
    }
  }
  translate(0, -len);
  if (len > minLen) {
    treeMaker(len * 0.8);
  } else {
    if (random() < 0.5) {
      bud.make();
    }
  }

  pop();

  /// Second Branch
  if (random() < 0.25) {
    push();
    translate(0, 0);
    rotSet = map(len, minLen, maxLen, PI * 0.1, PI * 0.24);
    rotate(random(-rotSet, rotSet));
    if (len === maxLen) {
      rotate(0);
    }
    sw = map(len, minLen, maxLen, swMin, swMax);
    push();
    beginShape();
    vertex(-sw * 0.5, 0);
    vertex(-sw * 0.7 * 0.5, -len);
    vertex(sw * 0.7 * 0.5, -len);
    vertex(sw * 0.5, 0);
    noStroke();
    fill(0, 255);
    endShape(CLOSE);
    pop();

    for (let y = -len; y < 0; y += this.gap) {
      for (let x = -sw * 0.5; x < sw * 0.5; x += this.gap) {
        let posMod = createVector(random(-this.gap, this.gap));
        push();
        if (random() < 0.005) {
          strokeWeight(sw * 0.2);
          stroke(random(50), 255);
          // line(0, 0, sw * 2, 0);
          for (let stx = 0; stx < sw * 2; stx += 1) {
            let sty = map(
              noise(len * 0.01, stx * 0.05),
              0,
              1,
              -sw * 0.5,
              sw * 0.5
            );
            stroke(random(50), 255);
            point(stx, sty);
          }
          push();
          translate(sw * 2, 0);
          bud.make();
          pop();
        }

        translate(x + posMod.x, y + posMod.y);
        rotate(random(TAU));
        stroke(map(x, -sw * 0.5, sw * 0.5, colMin, colMax), 200);
        strokeWeight(1);
        line(-sw * 0.1, 0, sw * 0.1, 0);
        pop();
      }
    }
    translate(0, -len);
    if (len > minLen * 1.1) {
      treeMaker(len * 0.8);
    } else {
      if (random() < 0.5) {
        bud.make();
      }
    }

    pop();
  }

  /// Third Branch
  if (random() < 0.25) {
    push();
    translate(0, 0);
    rotSet = map(len, minLen, maxLen, PI * 0.16, PI * 0.32);
    rotate(random(-rotSet, rotSet));
    if (len === maxLen) {
      rotate(0);
    }
    sw = map(len, minLen, maxLen, swMin, swMax);
    push();
    beginShape();
    vertex(-sw * 0.5, 0);
    vertex(-sw * 0.6 * 0.5, -len);
    vertex(sw * 0.6 * 0.5, -len);
    vertex(sw * 0.5, 0);
    noStroke();
    fill(0, 255);
    endShape(CLOSE);
    pop();

    for (let y = -len; y < 0; y += this.gap) {
      for (let x = -sw * 0.5; x < sw * 0.5; x += this.gap) {
        let posMod = createVector(random(-this.gap, this.gap));
        push();
        translate(x + posMod.x, y + posMod.y);
        rotate(random(TAU));
        stroke(map(x, -sw * 0.5, sw * 0.5, colMin, colMax), 200);
        strokeWeight(1);
        line(-sw * 0.1, 0, sw * 0.1, 0);
        if (random() < 0.005) {
          strokeWeight(sw * 0.2);
          stroke(random(50), 255);
          for (let stx = 0; stx < sw * 2; stx += 1) {
            let sty = map(
              noise(len * 0.01, stx * 0.05),
              0,
              1,
              -sw * 0.5,
              sw * 0.5
            );
            stroke(random(50), 255);
            point(stx, sty);
          }
          push();
          translate(sw * 2, 0);
          bud.make();
          pop();
        }

        pop();
      }
    }
    translate(0, -len);
    if (len > minLen) {
      treeMaker(len * 0.6);
    } else {
      if (random() < 0.5) {
        bud.make();
      }
    }
    pop();
  }
}

function budMaker() {
  this.offx = random(10000);
  this.offy = random(10000);
  this.size = minLen * 0.5;

  this.make = function () {
    push();
    beginShape();
    for (let r = 0; r < TAU; r += PI * 0.1) {
      let x = cos(r) * this.size;
      let y = sin(r) * this.size;
      let xMod = map(
        noise(this.offx, frameCount * 0.01, r),
        0,
        1,
        -this.size * 0.5,
        this.size * 0.5
      );
      let yMod = map(
        noise(this.offy, frameCount * 0.01, r),
        0,
        1,
        -this.size * 0.5,
        this.size * 0.5
      );
      vertex(x + xMod, y + yMod);
      if (random() < 0.32) {
        vertex(0, 0);
      }
    }
    fill(random(50, 175), 0, 0, 255);
    stroke(random(25, 50), 255);
    strokeWeight(1);
    endShape();
    pop();
  };
}

/// Midground Trees, Bushes, Grass
function backMaker() {
  this.startY = height * 0.75;
  this.endY = height * 1.1;
  this.len = height * 0.05;
  this.bmaxLen = height * 0.05;
  this.bminLen = this.bmaxLen * 0.5;
  this.pathRotOff = random(PI);

  this.tree = function (len) {
    push();
    translate(0, 0);
    if (len < this.bmaxLen) {
      rotate(random(-PI * 0.21, PI * 0.21));
    }
    let sw = map(len, this.bminLen, this.bmaxLen, 1, 5);
    strokeWeight(sw);
    let colSet = random(0, 20);
    stroke(colSet, colSet * 0.9, colSet * 0.85, 255);
    if (len < this.bminLen * 2.2) {
      line(0, 0, 0, -len);
    }
    translate(0, -len);
    if (random() < 0.5) {
      this.smallBuds(len * 0.25);
    }
    if (len > this.bminLen) {
      backSet.tree(len * 0.8);
    }
    pop();

    if (random() < 0.5) {
      push();
      translate(0, 0);
      if (len < this.bmaxLen) {
        rotate(random(-PI * 0.21, PI * 0.21));
      }
      sw = map(len, this.bminLen, this.bmaxLen, 1, 5);
      strokeWeight(sw);
      colSet = random(0, 20);
      stroke(colSet, colSet * 0.9, colSet * 0.85, 255);
      if (len < this.bminLen * 2.2) {
        line(0, 0, 0, -len);
      }
      translate(0, -len);
      if (random() < 0.5) {
        this.smallBuds(len * 0.25);
      }
      if (len > this.bminLen) {
        colSelect = floor(random(2));
        backSet.tree(len * 0.7);
      }
      pop();
    }

    if (random() < 0.5) {
      push();
      translate(0, 0);
      if (len < this.bmaxLen) {
        rotate(random(-PI * 0.21, PI * 0.21));
      }
      sw = map(len, this.bminLen, this.bmaxLen, 1, 5);
      strokeWeight(sw);
      colSet = random(0, 20);
      stroke(colSet, colSet * 0.9, colSet * 0.85, 255);
      if (len < this.bminLen * 2.2) {
        line(0, 0, 0, -len);
      }
      translate(0, -len);
      if (random() < 0.5) {
        this.smallBuds(len * 0.25);
      }
      if (len > this.bminLen) {
        colSelect = floor(random(2));
        backSet.tree(len * 0.7);
      }
      pop();
    }
  };

  this.smallBuds = function (len) {
    let quant = floor(random(5, 8));
    for (let n = 0; n < quant; n++) {
      let pos = createVector(random(-len, len), random(-len, len));
      push();
      stroke(random(25, 75), 0, 0, 255);
      if (colSelect) {
        stroke(random(125, 200), 225);
      }
      strokeWeight(random(2, 5));
      point(pos.x, pos.y);
      pop();
    }
  };

  this.ground = function () {
    let yCount = 0;
    for (let y = this.startY; y < this.endY + this.len; y += this.len * 0.25) {
      yCount += 0.1;
      let gap = map(y, this.startY, this.endY, 25, 50);
      for (let x = -width * 0.1; x < width * 1.1; x += gap) {
        let xMod = random(-this.len * 0.15, this.len * 0.15);
        let yMod = random(-this.len * 0.2, this.len * 0.2);
        push();
        strokeWeight(random(2, 5) * (gap * random(0.1, 0.2)));
        let colSet = random(50, 100);
        stroke(colSet * 0.8, colSet * 0.8 * random(0.6, 1), colSet * 0.2, 255);
        let xr = random(-width * 0.1, width * 1.1);
        // line(xr + xMod, y + yMod, xr + xMod + this.len, y + yMod);
        noStroke();
        fill(colSet, colSet * random(0.6, 1.6), colSet * 0.8, 255);
        let eyRnd = random(0.1, 0.25);
        ellipse(
          xr + xMod,
          y + yMod,
          xr + xMod + this.len,
          random(2, 5) * (gap * random(0.2, 0.4))
        );

        if (random() < 0.05 && yCount < 2) {
          push();
          translate(xr + xMod, y + yMod);
          this.tree(this.bmaxLen * random(yCount * 1, yCount * 1.1));
          pop();
        }
        pop();
      }
    }
  };

  this.grass = function () {
    for (let y = this.startY; y < this.endY; y += this.len * 0.25) {
      let makePost = 0;
      let gap = map(y, this.startY, this.endY, 2, 5);
      let walkMod = map(y, this.startY, this.endY, width * 0.01, width * 0.1);
      for (let x = -width * 0.1; x < width * 1.1; x += gap) {
        let xMod = random(-this.len * 0.2, this.len * 0.2);
        let yMod = random(-this.len * 0.1, this.len * 0.2);
        push();
        translate(x + xMod, y + yMod);
        let walkC =
          width * 0.5 - cos(this.pathRotOff + y * 0.006) * (width * 0.5);
        rotate(map(noise(y * 0.05, x * 0.05), 0, 1, -PI * 0.2, PI * 0.2));
        let sw = map(y, this.startY, this.endY, 1, 5);
        let lenMod = map(noise((x + y) * 0.01), 0, 1, 0.1, 1);
        strokeWeight(sw);
        let colSet = random(75, 125);
        let topBright = map(y, this.startY, this.endY, 150, 75);

        /// Decide to make a fence post
        if (x + xMod > walkC && makePost === 0 && y < height * 0.85) {
          makePost = 1;
          if (random() < 0.25) {
            push();
            strokeCap(SQUARE);
            translate(0, 0);
            rotate(-map(noise(y * 0.05, x * 0.05), 0, 1, -PI * 0.2, PI * 0.2));
            stroke(random(0, 15), random(0, 20), 0, 255);
            strokeWeight(sw * 10);
            let postLen = map(
              y,
              this.startY,
              this.endY,
              this.len * 1.5,
              this.len * 3.5
            );
            line(0, 0, 0, -postLen);
            strokeWeight(sw);
            stroke(125, 255);
            line(-sw * 5, 0, -sw * 5, -postLen);
            pop();
          }
        }

        if (x + xMod < walkC - walkMod || x + xMod > walkC + walkMod) {
          stroke(0, 175);
          if (random() < 0.2) {
            stroke(0, random(25, topBright), 50, 150);
          }

          line(sw * 0.5, 0, sw * 0.5, -this.len * lenMod);
          stroke(random(25, 50), random(75, 125), random(10, 25), 175);
          if (noise(y * 0.1, x * 0.1) < 0.5) {
            stroke(colSet, colSet * 0.7, colSet * 0.2, 175);
            if (colSelect) {
              stroke(0, random(25, topBright), 50, 175);
            }
          }
          if (noise(y * 0.05, x * 0.01) < 0.5) {
            line(0, 0, 0, -this.len * lenMod);
          }

          /// Decide to Make a Pine Tree
          if (random() < pineHSet) {
            let treeNum = floor(random(1, 4));
            push();
            for (let ti = 0; ti < treeNum; ti++) {
              translate(random(-width * 0.1, width * 0.1), 0);
              for (let fi = 0; fi < 3; fi++) {
                push();
                translate(0, 0);
                rotate(
                  -map(noise(y * 0.05, x * 0.05), 0, 1, -PI * 0.2, PI * 0.2)
                );
                pineTreeMaker(fmaxLen * random(0.5, 1.2));
                pop();
              }
            }
            pop();
          }
        }
        pop();
      }
    }
  };
}

function skyMaker() { /// mid-space flora 
  this.gapX = width * 0.05;
  this.gapY = height * 0.05;
  this.offX = random(10000);
  this.offY = random(10000);
  this.pos = [];
  let count = 0;
  let tall = random(0.3, 0.5);
  for (let y = this.gapY; y < height * 0.76; y += this.gapY) {
    count = 0;
    for (let x = -width * 0.1; x < width * 1.1; x += this.gapX) {
      count += 0.01;
      let hillMod = map(
        noise(x * 0.05, count),
        0,
        1,
        height * tall,
        height * 0.7
      );
      if (hillMod < y) {
        this.pos.push(createVector(x, y));
      }
    }
  }

  this.update = function () {
    for (let i = 0; i < this.pos.length; i++) {
      let xMod = map(
        noise(frameCount * 0.05, (this.offX + i) * 0.05, this.pos[i].x * 0.01),
        0,
        1,
        -this.gapX * 3,
        this.gapX * 3
      );
      let yMod = map(
        noise(frameCount * 0.05, (this.offY + i) * 0.05, this.pos[i].y * 0.01),
        0,
        1,
        -this.gapY * 3,
        this.gapY * 3
      );
      let sizeMod = random(0.1, 1);
      push();
      beginShape();
      let posX = this.pos[i].x;
      let posY = this.pos[i].y;
      for (let r = 0; r < TAU; r += TAU * 0.05) {
        let xcir = cos(r) * this.gapX * sizeMod;
        let ycir = sin(r) * this.gapY * sizeMod;
        let cirModx = map(
          noise(frameCount * 0.1, (this.offY + i) * 0.05, r),
          0,
          1,
          -this.gapX * sizeMod * 0.3,
          this.gapX * sizeMod * 0.35
        );
        let cirMody = map(
          noise(frameCount * 0.1, (this.offY + i) * 0.05, r),
          0,
          1,
          -this.gapY * sizeMod * random(0.5, 0.8),
          this.gapY * sizeMod * random(0.5, 0.8)
        );
        curveVertex(posX + xcir + cirModx, posY + ycir + cirMody);
        vertex(
          posX + random(-this.gapX, this.gapX),
          posY + random(-this.gapY, this.gapY)
        );
      }
      stroke(0, 3);
      if (random() < 0.1) {
        stroke(random(50, 100), 96);
      }
      strokeWeight(random(1, 8));
      let colRnd = random(25, 100);
      fill(colRnd * 0.2, colRnd, colRnd * 0.05, 150);
      if (random() < 0.4) {
        fill(colRnd, colRnd * 0.8, colRnd * 0.1, 150);
      }
      endShape(CLOSE);
      pop();
    }
  };
}

function mtMaker() {
  this.xoff = random(1000);
  this.gap = width * 0.1;

  this.make = function (n) {
    this.yoff = 0;
    beginShape();
    for (let x = -width * 0.1; x < width * 1.1; x += this.gap) {
      let y = map(
        noise((this.xoff + x) * 0.01, this.yoff, n * 0.01),
        0,
        1,
        -this.gap * 0.2,
        this.gap
      );
      curveVertex(x, y);
      this.yoff += 0.05;
    }
    vertex(width * 1.1, 0);
    vertex(width * 1.1, height * 0.76);
    vertex(-width * 0.1, height * 0.76);
    noFill();
    stroke(0, random(50, 125), 0, 96);
    strokeWeight(2);
    fill(0, random(50, 125), 0, 96);
    if (colSelect) {
      fill(random(50, 125), random(25, 75), 0, 96);
    }
    endShape(CLOSE);
  };
}

function pineTreeMaker(len) {
  push();
  translate(0, 0);
  rotate(random(-PI * 0.01, PI * 0.01));
  let sw = map(len, fminLen, fmaxLen, 1, 10);
  strokeWeight(sw * 1.1);
  stroke(0, 255);
  line(0, 0, 0, -len);
  push();
  for (let y = 0; y < len; y++) {
    let dense = floor(random(5, 10));
    let lenMod = len * random(0.5, 1.1);
    let needleCol = 0;
    let deadNeedle = 0;

    if (random() < 0.5 && random() < 0.3) {
      for (let x = 0; x < lenMod; x++) {
        let ymod = map(noise(y * 0.1, x * 0.05), 0, 1, -len * 0.1, len * 0.1);
        strokeWeight(sw * ((len - x) * 0.01));
        stroke(random(0, 20), 255);
        point(-x, -y + ymod);
        if (random() < 0.1) {
          deadNeedle = random();
          for (let n = 0; n < dense; n++) {
            push();
            translate(-x, -y + ymod);
            rotate(QUARTER_PI + random(-PI * 1.2, -PI * 0.8));
            strokeWeight(1);
            needleCol = random(60, 110);
            stroke(needleCol * 0.1, needleCol, needleCol * 0.8, 255);
            if (deadNeedle < 0.2) {
              stroke(random(75, 125), random(25, 50), 0, 255);
            }

            line(0, 0, 0, -fmaxLen * 0.1);
            pop();
          }
        }
      }
    }

    if (random() < 0.5 && random() < 0.3) {
      let lenMod = len * random(0.5, 1.1);
      for (let x = 0; x < lenMod; x++) {
        let ymod = map(noise(y * 0.1, x * 0.05), 0, 1, -len * 0.1, len * 0.1);
        strokeWeight(sw * ((len - x) * 0.01));
        stroke(random(0, 20), 255);
        point(x, -y + ymod);
        if (random() < 0.1) {
          deadNeedle = random();
          for (let n = 0; n < dense; n++) {
            push();
            translate(x, -y + ymod);
            rotate(-QUARTER_PI + random(-PI * 0.2, PI * 0.2));
            strokeWeight(1);
            needleCol = random(50, 100);
            stroke(needleCol * 0.1, needleCol, needleCol * 0.8, 255);
            if (deadNeedle < 0.2) {
              stroke(random(75, 125), random(25, 50), 0, 255);
            }
            line(0, 0, 0, fmaxLen * 0.1);
            pop();
          }
        }
      }
    }
  }
  pop();
  translate(0, -len);
  if (len > fminLen) {
    pineTreeMaker(len * 0.8);
  }
  pop();
}

function mousePressed() {
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let fs = fullscreen();
    fullscreen(!fs);
  }
}

function keyPressed() {
  if (keyCode === DOWN_ARROW) {
    saveCanvas("ed_cavett_BuddingSpring", "png");
  }
}
